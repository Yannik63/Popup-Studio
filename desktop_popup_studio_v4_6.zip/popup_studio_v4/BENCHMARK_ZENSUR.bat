@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Bitte zuerst START_POPUP_STUDIO.bat einmal ausfuehren.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" popup_studio.py --benchmark
pause
endlocal
