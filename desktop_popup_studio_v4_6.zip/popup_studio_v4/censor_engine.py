"""Live-Zensur für den ganzen Bildschirm (läuft als eigener Prozess).

Ablauf:  Bildschirm aufnehmen -> NudeNet (ONNX) erkennt Körperregionen
         -> Boxen glätten/halten und an das jeweilige FENSTER binden
         -> durchklickbares Overlay zeichnet die Zensur nur dort, wo dieses Fenster sichtbar ist.

Das Overlay ist per SetWindowDisplayAffinity(WDA_EXCLUDEFROMCAPTURE) für die Aufnahme
unsichtbar, dadurch gibt es keine Rückkopplung (Balken -> nichts erkannt -> Balken weg ...).

Start:  popup_studio.py --censor <config.json>
Tests:  popup_studio.py --benchmark | --diagnose
"""
import os
import sys
import json
import time
import random
import threading
from pathlib import Path

MODELS_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "PopupStudio" / "models"

# NudeNet-v3-Klassen in der Reihenfolge des Modells
LABELS = [
    "FEMALE_GENITALIA_COVERED", "FACE_FEMALE", "BUTTOCKS_EXPOSED", "FEMALE_BREAST_EXPOSED",
    "FEMALE_GENITALIA_EXPOSED", "MALE_BREAST_EXPOSED", "ANUS_EXPOSED", "FEET_EXPOSED",
    "BELLY_COVERED", "FEET_COVERED", "ARMPITS_COVERED", "ARMPITS_EXPOSED", "FACE_MALE",
    "BELLY_EXPOSED", "MALE_GENITALIA_EXPOSED", "ANUS_COVERED", "FEMALE_BREAST_COVERED",
    "BUTTOCKS_COVERED",
]

# (Name, Klassen, standardmäßig an, Mindest-Sicherheit %, Rand %)
# Männer: nur Genitalien. Das Modell unterscheidet das Geschlecht nur bei Brust, Gesicht und Genitalien;
# Gesäß, Bauch, Füße usw. gelten für alle Personen.
GROUP_DEFS = [
    ("Brüste (frei)", ["FEMALE_BREAST_EXPOSED"], True, 25, 25),
    ("Brüste (bedeckt)", ["FEMALE_BREAST_COVERED"], False, 35, 15),
    ("Vulva / Genitalien weiblich (frei)", ["FEMALE_GENITALIA_EXPOSED"], True, 15, 35),
    ("Genitalien weiblich (bedeckt)", ["FEMALE_GENITALIA_COVERED"], False, 30, 25),
    ("Genitalien männlich (frei)", ["MALE_GENITALIA_EXPOSED"], True, 15, 35),
    ("Gesäß (frei)", ["BUTTOCKS_EXPOSED"], True, 25, 20),
    ("Gesäß (bedeckt)", ["BUTTOCKS_COVERED"], False, 35, 15),
    ("After (frei)", ["ANUS_EXPOSED"], True, 20, 40),
    ("After (bedeckt)", ["ANUS_COVERED"], False, 35, 25),
    ("Bauch (frei)", ["BELLY_EXPOSED"], False, 35, 10),
    ("Bauch (bedeckt)", ["BELLY_COVERED"], False, 40, 10),
    ("Achseln (frei)", ["ARMPITS_EXPOSED"], False, 35, 20),
    ("Achseln (bedeckt)", ["ARMPITS_COVERED"], False, 40, 20),
    ("Füße (frei)", ["FEET_EXPOSED"], False, 35, 10),
    ("Füße (bedeckt)", ["FEET_COVERED"], False, 40, 10),
    ("Augen (weiblich)", ["FACE_FEMALE"], False, 45, 15),     # Augenbalken, aus dem Gesichtsfeld abgeleitet
]
# Das Modell kennt keine "Augen"-Klasse: Der Augenbereich wird aus der erkannten weiblichen Gesichtsbox geschnitten
# (Anteile der Gesichtsbox: links, oben, rechts, unten).
GROUP_TRANSFORM = {"Augen (weiblich)": (0.0, -0.04, 1.0, 0.27)}
# Geschlechts-Gegenprobe: Eine "weibliche" Erkennung wird verworfen, wenn an derselben Stelle die männliche Klasse
# mindestens genauso sicher ist (das Modell rät das Geschlecht und verwechselt gern).
VETO = {"FACE_FEMALE": "FACE_MALE", "FEMALE_BREAST_EXPOSED": "MALE_BREAST_EXPOSED"}
GROUPS = {n: c for n, c, *_ in GROUP_DEFS}
CLASS_TO_GROUP = {c: n for n, cl, *_ in GROUP_DEFS for c in cl}
EFFECTS = ["Schwarzer Balken", "Farbfläche", "Schwarze Ellipse", "Verpixeln", "Verpixeln (grob)",
           "Weichzeichnen", "Invertieren", "Rauschen", "Warnstreifen", "Text", "Emoji", "Eigenes Bild"]
PIXEL_EFFECTS = {"Verpixeln", "Verpixeln (grob)", "Weichzeichnen", "Invertieren", "Rauschen"}
STICKER_MODES = ["Füllen", "Einpassen", "Zuschneiden"]
ACCURACY = ["Schnell", "Standard", "Genau", "Maximal"]
MODEL_CHOICES = ["320n (schnell)", "640m (genauer)"]

DEFAULT_CONFIG = {
    "groups": {n: {"on": on, "effect": "Standard", "thr": thr, "pad": pad} for n, _, on, thr, pad in GROUP_DEFS},
    "effect": "Schwarzer Balken",        # Standard-Effekt
    "thr_shift": 0,                      # verschiebt ALLE Schwellen (negativ = zensiert mehr)
    "hold_ms": 150,                      # Zensur bleibt so lange nach dem letzten Treffer
    "smoothing": 20,                     # 0 = Boxen springen, 90 = sehr träge
    "confirm_hits": 1,                   # 1 = sofort zeigen
    "max_fps": 60,                       # Erkennungen pro Sekunde (Obergrenze)
    "accuracy": "Standard",              # Schnell | Standard | Genau | Maximal
    "model": MODEL_CHOICES[0],
    "model_path": "",                    # eigenes Modell (überschreibt alles)
    "use_gpu": True,
    "monitor": 0,
    "skip_static": True,
    "window_bind": True,                 # Zensur nur im betroffenen Fenster
    "pixel_block": 16,
    "blur_radius": 30,
    "color": "#000000",
    "text": "ZENSIERT",
    "text_color": "#ffffff",
    "font": "Impact",
    "emoji": "🙈",
    "border": True,
    "apps_mode": "Überall",              # Überall | Nur in diesen Apps | Überall außer in diesen
    "apps_list": "chrome.exe, firefox.exe, msedge.exe",
    "panic_full_screen": False,
    "panic_min_boxes": 3,
    "show_badge": True,
    "stickers": [],
    "sticker_mode": "Füllen",
    "sticker_backdrop": True,
}


# ---------------------------------------------------------------------------
# Konfiguration / Modelle
# ---------------------------------------------------------------------------
def merge_config(data):
    """Legt gespeicherte Werte über die Standardwerte (unbekannte Schlüssel werden ignoriert)."""
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if isinstance(data, dict):
        for k, v in data.items():
            if k == "groups" and isinstance(v, dict):
                for g, gv in v.items():
                    if g in cfg["groups"] and isinstance(gv, dict):
                        cfg["groups"][g].update(gv)
            elif k in DEFAULT_CONFIG:
                cfg[k] = v
    return cfg


def load_config(path):
    try:
        return merge_config(json.loads(Path(path).read_text(encoding="utf-8")))
    except Exception:
        return merge_config({})


def class_thresholds(cfg):
    """Schwelle je Modell-Klasse (0..1). Nicht aktive Klassen bekommen 9 = nie."""
    import numpy as np
    thr = np.full(len(LABELS), 9.0, dtype=np.float32)
    shift = float(cfg.get("thr_shift", 0))
    for name, conf in cfg["groups"].items():
        if name in GROUPS and conf.get("on"):
            t = min(0.95, max(0.05, (float(conf.get("thr", 30)) + shift) / 100.0))
            for c in GROUPS[name]:
                thr[LABELS.index(c)] = t
    for female, male in VETO.items():                 # männliche Gegenklasse nur zum Aussortieren mitlaufen lassen
        if thr[LABELS.index(female)] < 1:
            i = LABELS.index(male)
            thr[i] = min(thr[i], 0.2)
    return thr


def _builtin_320n():
    cands = []
    if getattr(sys, "frozen", False):
        cands.append(os.path.join(getattr(sys, "_MEIPASS", ""), "nudenet", "320n.onnx"))
    try:
        import importlib.util
        spec = importlib.util.find_spec("nudenet")
        if spec and spec.submodule_search_locations:
            cands.append(os.path.join(list(spec.submodule_search_locations)[0], "320n.onnx"))
    except Exception:
        pass
    cands.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "320n.onnx"))
    for c in cands:
        if c and os.path.isfile(c):
            return c
    raise FileNotFoundError("Modell 320n.onnx nicht gefunden. START_POPUP_STUDIO.bat installiert es (pip install nudenet).")


def model_640m_path():
    for c in (MODELS_DIR / "640m.onnx", Path(os.path.dirname(os.path.abspath(__file__))) / "models" / "640m.onnx"):
        if c.is_file() and c.stat().st_size > 20_000_000:
            return str(c)
    return ""


def resolve_model(cfg):
    """Gibt (Pfad, Hinweis) zurück."""
    p = cfg.get("model_path") or ""
    if p and os.path.isfile(p):
        return p, ""
    if str(cfg.get("model", "")).startswith("640m"):
        m = model_640m_path()
        if m:
            return m, ""
        return _builtin_320n(), "640m nicht gefunden -> 320n wird benutzt (Download-Knopf unter Genauigkeit & Tempo)"
    return _builtin_320n(), ""


def find_model(cfg):
    return resolve_model(cfg)[0]


MODEL_640M_SHA256 = "04fe3d77980780c1f8297dc6d7f942fd5b3abe6942a188f742a85241e4f634eb"
MODEL_640M_SIZE = 103538690
MODEL_640M_URLS = [
    "https://huggingface.co/ServiceStack/comfy-gateway/resolve/main/640m.onnx",
    "https://huggingface.co/spaces/Nymbo/Nudity-Censor/resolve/main/640m.onnx",
    "https://github.com/notAI-tech/NudeNet/releases/download/v3.4-weights/640m.onnx",
]


def download_model(dest=None, progress=None, urls=None):
    """Lädt das 640m-Modell von mehreren Quellen und prüft SHA-256. Wirft RuntimeError mit allen Fehlern."""
    import urllib.request
    import hashlib
    dest = Path(dest or (MODELS_DIR / "640m.onnx"))
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".part")
    errors = []
    for url in (urls or MODEL_640M_URLS):
        host = url.split("/")[2]
        try:
            h = hashlib.sha256()
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 PopupStudio"})
            with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
                total = int(r.headers.get("Content-Length") or MODEL_640M_SIZE)
                got = 0
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    f.write(chunk)
                    h.update(chunk)
                    got += len(chunk)
                    if progress:
                        progress(got, total)
            if got < 20_000_000:
                raise RuntimeError(f"nur {got} Bytes erhalten (keine Modelldatei)")
            if h.hexdigest() != MODEL_640M_SHA256:
                raise RuntimeError("Prüfsumme stimmt nicht (Datei beschädigt oder verändert)")
            import onnxruntime as ort
            ort.InferenceSession(str(tmp), providers=["CPUExecutionProvider"])
            tmp.replace(dest)
            return str(dest)
        except Exception as e:
            errors.append(f"{host}: {type(e).__name__}: {e}")
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
    raise RuntimeError(" | ".join(errors))


# ---------------------------------------------------------------------------
# Detektor
# ---------------------------------------------------------------------------
class Detector:
    """NudeNet-ONNX. Das 320n-Modell hat dynamische Eingabegröße: Wir füttern es mit dem
    Bildschirmformat (z. B. 640x352) statt mit einem gepolsterten Quadrat -> feinere Auflösung
    bei geringen Kosten. Mehrere Durchläufe/Kacheln werden zusammengeführt."""

    PASSES_DYNAMIC = {
        "Schnell": [(320, 1, 1)],
        "Standard": [(320, 1, 1), (640, 1, 1)],
        "Genau": [(320, 1, 1), (640, 1, 1), (640, 2, 1)],
        "Maximal": [(320, 1, 1), (640, 1, 1), (640, 2, 2)],
    }

    def __init__(self, model_path, use_gpu=True, accuracy="Standard", fixed_shapes=False):
        import onnxruntime as ort
        import cv2
        import numpy as np
        self.ort, self.cv2, self.np = ort, cv2, np
        self.model_path = model_path
        self.fixed_shapes = fixed_shapes          # True: immer quadratische Eingabe -> wenige, gleichbleibende Formen (für Bilder)
        self.accuracy = accuracy if accuracy in ACCURACY else "Standard"
        avail = ort.get_available_providers()
        self.providers = []
        if use_gpu:
            self.providers += [p for p in ("CUDAExecutionProvider", "DmlExecutionProvider") if p in avail]
        self.providers.append("CPUExecutionProvider")
        self.note = ""
        probe = ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
        inp = probe.get_inputs()[0]
        self.input_name = inp.name
        shp = inp.shape                                   # z. B. ['batch', 3, 'height', 'width'] oder [1, 3, 640, 640]
        self.dynamic = not (isinstance(shp[2], int) and isinstance(shp[3], int))
        self.dim_names = [d if isinstance(d, str) else None for d in shp]
        self.fixed_res = int(shp[2]) if not self.dynamic else 0
        self.train_res = 640 if (self.fixed_res == 640 or os.path.getsize(model_path) > 50_000_000) else 320
        self.sessions = {}
        self._verified = not (self.providers[0] != "CPUExecutionProvider")
        self.provider = self.providers[0]

    # --- Sessions: je Eingabeform eine feste Session (DirectML mag keine wechselnden Formen)
    def _make(self, providers, b, h, w):
        ort = self.ort
        so = ort.SessionOptions()
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        if "DmlExecutionProvider" in providers:
            so.enable_mem_pattern = False
            so.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        if self.dynamic and providers[0] != "CPUExecutionProvider":     # GPU: je Form eine feste Session
            for nm, val in zip((self.dim_names[0], self.dim_names[2], self.dim_names[3]), (b, h, w)):
                if nm:
                    so.add_free_dimension_override_by_name(nm, int(val))
        if providers[0] == "CPUExecutionProvider":
            so.enable_cpu_mem_arena = False                            # keine riesigen Zwischenspeicher behalten
            so.enable_mem_pattern = False
        return ort.InferenceSession(self.model_path, so, providers=providers)

    MAX_SESSIONS = 6

    def _session(self, b, h, w):
        on_gpu = self.providers[0] != "CPUExecutionProvider" and self.dynamic
        key = (b, h, w) if on_gpu else "cpu"                              # CPU: EINE Session für alle Formen
        if key in self.sessions:
            return self.sessions[key]
        np = self.np
        sess = None
        if self.providers[0] != "CPUExecutionProvider":
            try:
                sess = self._make(self.providers, b, h, w)
                if not self._verified:               # GPU nur nehmen, wenn Ergebnis = CPU-Ergebnis
                    test = np.random.RandomState(1).rand(b, 3, h, w).astype(np.float32)
                    a = sess.run(None, {self.input_name: test})[0]
                    c = self._make(["CPUExecutionProvider"], b, h, w).run(None, {self.input_name: test})[0]
                    if a.shape != c.shape or float(np.abs(a[:, 4:] - c[:, 4:]).max()) > 0.1:
                        self.note = "GPU lieferte abweichende Ergebnisse -> CPU wird benutzt"
                        self.providers = ["CPUExecutionProvider"]
                        sess = None
                    self._verified = True
            except Exception as e:
                self.note = f"GPU-Start fehlgeschlagen ({type(e).__name__}) -> CPU wird benutzt"
                self.providers = ["CPUExecutionProvider"]
                sess = None
        if sess is None:
            sess = self._make(["CPUExecutionProvider"], b, h, w)
        self.provider = sess.get_providers()[0]
        if sess.get_providers()[0] == "CPUExecutionProvider":
            key = "cpu"
        self.sessions[key] = sess
        while len(self.sessions) > self.MAX_SESSIONS:                     # Obergrenze: älteste Sessions freigeben
            self.sessions.pop(next(iter(self.sessions)))
        return sess

    def passes(self):
        if self.dynamic:
            if self.train_res == 640:                      # 640m: auf 640 trainiert -> Stufen entsprechend höher
                return {"Schnell": [(640, 1, 1)], "Standard": [(640, 1, 1), (960, 1, 1)],
                        "Genau": [(640, 1, 1), (960, 1, 1), (960, 2, 1)],
                        "Maximal": [(640, 1, 1), (960, 1, 1), (960, 2, 2)]}[self.accuracy]
            return self.PASSES_DYNAMIC[self.accuracy]
        r = self.fixed_res
        return {"Schnell": [(r, 1, 1)], "Standard": [(r, 1, 1)], "Genau": [(r, 1, 1), (r, 2, 1)],
                "Maximal": [(r, 1, 1), (r, 2, 2)]}[self.accuracy]

    @staticmethod
    def tile_rects(w, h, nx, ny):
        if nx == 1 and ny == 1:
            return [(0, 0, w, h)]
        ov = 0.15                                          # Überlappung, damit an Kachelrändern nichts verloren geht
        tw, th = w / nx, h / ny
        rects = []
        for j in range(ny):
            for i in range(nx):
                x0 = max(0, int(i * tw - ov * tw)); x1 = min(w, int((i + 1) * tw + ov * tw))
                y0 = max(0, int(j * th - ov * th)); y1 = min(h, int((j + 1) * th + ov * th))
                rects.append((x0, y0, x1 - x0, y1 - y0))
        return rects

    def _blob(self, imgs, long_side):
        cv2, np = self.cv2, self.np
        sized, ks = [], []
        for im in imgs:
            h, w = im.shape[:2]
            k = long_side / max(h, w)
            nw, nh = max(1, round(w * k)), max(1, round(h * k))
            sized.append(cv2.resize(im, (nw, nh), interpolation=cv2.INTER_AREA if k < 1 else cv2.INTER_LINEAR))
            ks.append(k)
        if self.dynamic and not self.fixed_shapes:
            H = max(-(-s.shape[0] // 32) * 32 for s in sized)
            W = max(-(-s.shape[1] // 32) * 32 for s in sized)
        else:
            H = W = long_side
        blobs = []
        for s in sized:
            canvas = np.zeros((H, W, 3), np.uint8)
            canvas[:s.shape[0], :s.shape[1]] = s
            blobs.append(cv2.dnn.blobFromImage(canvas, 1 / 255.0, (W, H), (0, 0, 0), swapRB=True, crop=False))
        return np.concatenate(blobs, axis=0), ks

    def _run(self, blob):
        np = self.np
        b, _, h, w = blob.shape
        if not self.dynamic and b > 1:
            return np.concatenate([self._run(blob[i:i + 1]) for i in range(b)], axis=0)
        return self._session(b, h, w).run(None, {self.input_name: blob})[0]

    def detect(self, frame, thr_vec):
        """frame: BGR. Rückgabe: [(klasse_idx, score, x, y, w, h)] in Bildpixeln."""
        cv2, np = self.cv2, self.np
        if float(thr_vec.min()) >= 1.0:
            return []
        H, W = frame.shape[:2]
        B, S, C = [], [], []
        for (long_side, nx, ny) in self.passes():
            rects = self.tile_rects(W, H, nx, ny)
            imgs = [frame[y:y + h, x:x + w] for (x, y, w, h) in rects]
            blob, ks = self._blob(imgs, long_side)
            out = self._run(blob)
            for i, (x0, y0, _, _) in enumerate(rects):
                arr = out[i].T                              # (N, 4 + Klassen)
                sc = arr[:, 4:]
                ai, ci = np.nonzero(sc >= thr_vec[None, :])  # Mehrfach-Labels: auch zweitbeste Klasse zählt
                if ai.size == 0:
                    continue
                k = ks[i]
                cx, cy, bw, bh = (arr[ai, 0] / k, arr[ai, 1] / k, arr[ai, 2] / k, arr[ai, 3] / k)
                B.append(np.stack([cx - bw / 2 + x0, cy - bh / 2 + y0, bw, bh], axis=1))
                S.append(sc[ai, ci])
                C.append(ci)
        if not B:
            return []
        boxes, scores, cls = np.concatenate(B), np.concatenate(S), np.concatenate(C)
        idx = cv2.dnn.NMSBoxesBatched(boxes.tolist(), scores.tolist(), cls.tolist(), 0.0, 0.5)   # NMS je Klasse
        res = []
        for i in np.array(idx).flatten():
            x, y, w, h = boxes[i]
            x1, y1 = max(0.0, float(x)), max(0.0, float(y))
            x2, y2 = min(float(W), float(x + w)), min(float(H), float(y + h))
            if x2 - x1 > 1 and y2 - y1 > 1:
                res.append((int(cls[i]), float(scores[i]), x1, y1, x2 - x1, y2 - y1))
        return res


def _iou_xywh(a, b):
    ax2, ay2, bx2, by2 = a[0] + a[2], a[1] + a[3], b[0] + b[2], b[1] + b[3]
    iw, ih = min(ax2, bx2) - max(a[0], b[0]), min(ay2, by2) - max(a[1], b[1])
    if iw <= 0 or ih <= 0:
        return 0.0
    inter = iw * ih
    return inter / (a[2] * a[3] + b[2] * b[3] - inter)


def arbitrate(raw):
    """Wirft 'weibliche' Treffer weg, wenn die männliche Gegenklasse an der Stelle gleich sicher oder sicherer ist."""
    male_by_class = {}
    for (c, s, x, y, bw, bh) in raw:
        for female, male in VETO.items():
            if LABELS[c] == male:
                male_by_class.setdefault(female, []).append((s, (x, y, bw, bh)))
    if not male_by_class:
        return raw
    keep = []
    for det in raw:
        c, s, x, y, bw, bh = det
        vetoed = False
        for ms, mbox in male_by_class.get(LABELS[c], []):
            if ms >= s - 0.05 and _iou_xywh((x, y, bw, bh), mbox) > 0.3:
                vetoed = True
                break
        if not vetoed:
            keep.append(det)
    return keep


def dets_from_raw(raw, cfg, w, h):
    """Rohdetektionen -> [(klassenname, gruppe, score, (x1,y1,x2,y2) inkl. Rand)] mit Gruppen-Rand."""
    out = []
    for (c, s, x, y, bw, bh) in arbitrate(raw):
        name = LABELS[c]
        group = CLASS_TO_GROUP.get(name)
        gc = cfg["groups"].get(group) if group else None
        if not gc or not gc.get("on"):
            continue
        tf = GROUP_TRANSFORM.get(group)
        if tf:                                          # z. B. Augenbereich aus der Gesichtsbox
            x, y, bw, bh = x + tf[0] * bw, y + tf[1] * bh, (tf[2] - tf[0]) * bw, (tf[3] - tf[1]) * bh
        pad = float(gc.get("pad", 20)) / 100.0
        px, py = bw * pad / 2, bh * pad / 2
        out.append((name, group, s, (max(0, x - px), max(0, y - py), min(w, x + bw + px), min(h, y + bh + py))))
    return out


# ---------------------------------------------------------------------------
# Tracker + Fensterbindung
# ---------------------------------------------------------------------------
def _iou(a, b):
    iw = min(a[2], b[2]) - max(a[0], b[0])
    ih = min(a[3], b[3]) - max(a[1], b[1])
    if iw <= 0 or ih <= 0:
        return 0.0
    inter = iw * ih
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


class Track:
    __slots__ = ("cls", "group", "box", "score", "hits", "last_seen", "sid", "hwnd", "origin", "sig")

    def __init__(self, cls, group, box, score, now, hwnd=None, origin=None):
        self.cls, self.group, self.box, self.score = cls, group, list(box), score
        self.hits, self.last_seen = 1, now
        self.sid = random.getrandbits(16)
        self.hwnd, self.origin = hwnd, origin
        self.sig = None


def signature(frame, box):
    """Winziger Bildabdruck der Region unter der Box (zum Erkennen von Seitenwechsel/Scrollen)."""
    import cv2
    h, w = frame.shape[:2]
    x1, y1, x2, y2 = max(0, int(box[0])), max(0, int(box[1])), min(w, int(box[2])), min(h, int(box[3]))
    if x2 - x1 < 2 or y2 - y1 < 2:
        return None
    return cv2.resize(frame[y1:y2, x1:x2], (10, 10), interpolation=cv2.INTER_AREA).astype("int16")


class Tracker:
    def __init__(self):
        self.tracks = []

    def update(self, dets, now, smoothing, hold_s):
        """dets: [(cls_name, group, score, box, hwnd, origin)]"""
        a = 1.0 - min(0.95, max(0.0, smoothing))
        used = set()
        for t in self.tracks:
            best, best_iou = None, 0.15
            for i, d in enumerate(dets):
                if i in used or d[1] != t.group:
                    continue
                v = _iou(t.box, d[3])
                if v > best_iou:
                    best, best_iou = i, v
            if best is not None:
                used.add(best)
                d = dets[best]
                k = 1.0 if best_iou < 0.5 else a
                t.box = [t.box[j] * (1 - k) + d[3][j] * k for j in range(4)]
                t.score, t.last_seen = d[2], now
                t.hwnd, t.origin = d[4], d[5]
                t.hits += 1
        for i, d in enumerate(dets):
            if i not in used:
                self.tracks.append(Track(d[0], d[1], d[3], d[2], now, d[4], d[5]))
        self.tracks = [t for t in self.tracks if now - t.last_seen <= hold_s]

    def refresh(self, now):
        for t in self.tracks:
            t.last_seen = now

    def visible(self, confirm_hits):
        return [t for t in self.tracks if t.hits >= confirm_hits]


def owner_of(wins, cx, cy):
    """Oberstes Fenster an Bildschirmposition (cx, cy) -> (hwnd, (links, oben)) oder (0, None)."""
    for (h, l, t, r, b) in wins:
        if l <= cx < r and t <= cy < b:
            return h, (l, t)
    return 0, None


def bind_tracks(tracks, wins, origin):
    """Schiebt Boxen mit ihrem Fenster mit und liefert Tracks, deren Fenster weg ist (minimiert/geschlossen)."""
    index = {w[0]: w for w in wins}
    drop = []
    for t in tracks:
        if not t.hwnd:
            continue
        w = index.get(t.hwnd)
        if w is None:
            drop.append(t)
            continue
        if t.origin is not None:
            dx, dy = w[1] - t.origin[0], w[2] - t.origin[1]
            if dx or dy:
                t.box = [t.box[0] + dx, t.box[1] + dy, t.box[2] + dx, t.box[3] + dy]
        t.origin = (w[1], w[2])
    return drop


def visible_region(box, hwnd, wins, origin):
    """Sichtbarer Teil der Box: auf das eigene Fenster begrenzt, Fenster darüber werden abgezogen.
    Ergebnis in Frame-Pixeln (QRegion)."""
    from PySide6.QtCore import QRect
    from PySide6.QtGui import QRegion
    ox, oy = origin
    x1, y1, x2, y2 = (int(box[0]), int(box[1]), int(box[2]), int(box[3]))
    base = QRect(x1 + ox, y1 + oy, max(1, x2 - x1), max(1, y2 - y1))
    pos = None
    for i, w in enumerate(wins):
        if w[0] == hwnd:
            pos = i
            break
    if hwnd and pos is not None:
        w = wins[pos]
        reg = QRegion(base.intersected(QRect(w[1], w[2], w[3] - w[1], w[4] - w[2])))
        above = wins[:pos]
    else:
        reg = QRegion(base)
        above = wins
    for w in above:
        r = QRect(w[1], w[2], w[3] - w[1], w[4] - w[2])
        if base.intersects(r):
            reg = reg.subtracted(QRegion(r))
            if reg.isEmpty():
                break
    reg.translate(-ox, -oy)
    return reg


# ---------------------------------------------------------------------------
# Bildschirmaufnahme
# ---------------------------------------------------------------------------
class Grabber:
    """dxcam.grab() liefert None, wenn sich der Bildschirm nicht geändert hat."""

    def __init__(self, monitor=0):
        self.kind, self.cam, self.sct, self.why = None, None, None, ""
        try:
            import dxcam
            self.cam = dxcam.create(output_idx=monitor, output_color="BGR")
            self.kind = "dxcam"
        except Exception as e:
            self.cam = None
            self.why = f"dxcam nicht nutzbar ({type(e).__name__}: {e})"
        if self.cam is None:
            import mss
            self.sct = mss.mss()
            mons = self.sct.monitors
            self.mon = mons[min(len(mons) - 1, monitor + 1)]
            self.kind = "mss"

    def grab(self):
        import numpy as np
        if self.kind == "dxcam":
            return self.cam.grab()
        import cv2
        return cv2.cvtColor(np.asarray(self.sct.grab(self.mon)), cv2.COLOR_BGRA2BGR)

    def close(self):
        try:
            if self.cam is not None:
                self.cam.release()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Hintergrund-Thread: aufnehmen -> erkennen -> tracken
# ---------------------------------------------------------------------------
class Worker(threading.Thread):
    def __init__(self, cfg_path):
        super().__init__(daemon=True)
        self.cfg_path = cfg_path
        self.cfg = load_config(cfg_path)
        self.cfg_mtime = 0
        self.lock = threading.Lock()
        self.tracker = Tracker()
        self.frame, self.frame_size, self.frame_id = None, (1, 1), 0
        self.origin = (0, 0)
        self.stop_flag, self.paused, self.error = False, False, ""
        self.stats = {"fps": 0.0, "detect_ms": 0.0, "provider": "-", "capture": "-", "boxes": 0, "note": ""}
        self.panic_active = False

    def reload_if_changed(self):
        try:
            m = os.path.getmtime(self.cfg_path)
            if m != self.cfg_mtime:
                self.cfg_mtime = m
                self.cfg = load_config(self.cfg_path)
                return True
        except Exception:
            pass
        return False

    def app_allowed(self):
        mode = self.cfg.get("apps_mode", "Überall")
        if mode == "Überall":
            return True
        names = {n.strip().lower() for n in self.cfg.get("apps_list", "").split(",") if n.strip()}
        from winutil import foreground_process_name
        fg = foreground_process_name()
        if not fg:
            return True
        return (fg in names) if mode == "Nur in diesen Apps" else (fg not in names)

    def run(self):
        try:
            self._loop()
        except Exception as e:
            import traceback
            self.error = f"{type(e).__name__}: {e}"
            try:
                sys.stderr.write(traceback.format_exc())
            except Exception:
                pass

    def _bind_dets(self, dets, wins_cap, wins_now):
        """Ordnet Treffer dem Fenster zu, in dem sie aufgenommen wurden, und rechnet sie auf die
        aktuelle Fensterposition um (Fenster kann seit der Aufnahme weitergewandert sein)."""
        ox, oy = self.origin
        now_map = {w[0]: w for w in wins_now} if wins_now is not None else None
        out = []
        for (name, group, score, box) in dets:
            cx, cy = (box[0] + box[2]) / 2 + ox, (box[1] + box[3]) / 2 + oy
            hwnd, org = owner_of(wins_cap, cx, cy)
            if hwnd and now_map is not None:
                cur = now_map.get(hwnd)
                if cur is None:
                    continue                                # Fenster inzwischen weg
                dx, dy = cur[1] - org[0], cur[2] - org[1]
                box = (box[0] + dx, box[1] + dy, box[2] + dx, box[3] + dy)
                org = (cur[1], cur[2])
            out.append((name, group, score, box, hwnd, org))
        return out

    def _loop(self):
        import cv2
        import numpy as np
        import winutil
        self.reload_if_changed()
        det_key, detector, grabber = None, None, None
        prev_small, last_detect = None, 0.0
        fps_hist, thr_vec, n = [], None, 0
        pid = os.getpid()
        try:
            while not self.stop_flag:
                t0 = time.perf_counter()
                changed = self.reload_if_changed()
                if changed or detector is None:
                    path, note = resolve_model(self.cfg)
                    key = (path, self.cfg["use_gpu"], self.cfg["accuracy"])
                    if key != det_key:
                        detector = Detector(*key)
                        det_key = key
                        self.stats["provider"] = detector.provider.replace("ExecutionProvider", "")
                        self.stats["model"] = os.path.basename(path)
                    self.stats["note"] = note
                    thr_vec = class_thresholds(self.cfg)
                    if grabber is None:
                        grabber = Grabber(self.cfg["monitor"])
                        self.stats["capture"] = grabber.kind
                        if grabber.why:
                            self.stats["note"] = (self.stats["note"] + " " + grabber.why).strip()
                cfg = self.cfg
                if self.paused or not allowed_check(self, t0):
                    with self.lock:
                        self.tracker.tracks = []
                    time.sleep(0.12)
                    continue
                frame = grabber.grab()
                now = time.monotonic()
                unchanged = frame is None
                if unchanged:
                    frame = self.frame
                    if frame is None:
                        time.sleep(0.01)
                        continue
                else:
                    with self.lock:
                        self.frame, self.frame_id = frame, self.frame_id + 1
                h, w = frame.shape[:2]
                self.frame_size = (w, h)

                small = cv2.resize(frame, (96, 54), interpolation=cv2.INTER_AREA).astype(np.int16)
                static = unchanged or (prev_small is not None and float(np.abs(small - prev_small).mean()) < 0.6)
                prev_small = small
                if static and (cfg["skip_static"] or unchanged) and now - last_detect < 0.4:
                    time.sleep(0.015)           # Boxen bleiben stehen, werden aber NICHT als "bestätigt" markiert
                    continue
                if not unchanged and self.tracker.tracks:
                    # Hat sich der Inhalt unter einer Box stark verändert (Seitenwechsel, Scrollen), muss die nächste
                    # Erkennung sie schnell neu bestätigen - sonst verschwindet sie.
                    grace = max(0.06, 1.5 * float(self.stats.get("detect_ms", 0)) / 1000.0)
                    hold_s = float(cfg["hold_ms"]) / 1000.0
                    with self.lock:
                        for t in self.tracker.tracks:
                            if t.sig is not None:
                                cur = signature(frame, t.box)
                                if cur is not None and float(np.abs(cur - t.sig).mean()) > 28:
                                    t.last_seen = min(t.last_seen, now - hold_s + grace)

                bind = bool(cfg.get("window_bind", True))
                wins_cap = winutil.enumerate_windows(pid) if bind else None
                t1 = time.perf_counter()
                raw = detector.detect(frame, thr_vec)
                det_ms = (time.perf_counter() - t1) * 1000
                last_detect = now
                dets = dets_from_raw(raw, cfg, w, h)
                if wins_cap is not None:
                    dets = self._bind_dets(dets, wins_cap, winutil.enumerate_windows(pid))
                else:
                    dets = [(a, b, c, d, None, None) for (a, b, c, d) in dets]
                with self.lock:
                    self.tracker.update(dets, now, float(cfg["smoothing"]) / 100.0, float(cfg["hold_ms"]) / 1000.0)
                    for t in self.tracker.tracks:
                        if t.last_seen == now:
                            t.sig = signature(frame, t.box)
                    n = len(self.tracker.visible(int(cfg["confirm_hits"])))
                    self.panic_active = bool(cfg["panic_full_screen"]) and n >= int(cfg["panic_min_boxes"])

                dt = time.perf_counter() - t0
                fps_hist = (fps_hist + [dt])[-20:]
                self.stats.update(detect_ms=round(det_ms, 1), boxes=n,
                                  fps=round(1.0 / (sum(fps_hist) / len(fps_hist)), 1),
                                  provider=detector.provider.replace("ExecutionProvider", ""))
                if detector.note and detector.note not in self.stats["note"]:
                    self.stats["note"] = (self.stats["note"] + " " + detector.note).strip()
                wait = 1.0 / max(1, int(cfg["max_fps"])) - dt
                if wait > 0:
                    time.sleep(wait)
        finally:
            if grabber:
                grabber.close()


def allowed_check(worker, t0):
    """Pro-App-Regel, höchstens alle 0.5 s neu geprüft."""
    last, val = getattr(worker, "_app_chk", (0.0, True))
    if t0 - last > 0.5:
        val = worker.app_allowed()
        worker._app_chk = (t0, val)
    return val


# ---------------------------------------------------------------------------
# Zeichnen (Overlay UND Popup-Bilder benutzen dieselbe Funktion)
# ---------------------------------------------------------------------------
def draw_sticker(painter, rect, img, mode, bg_color, backdrop=True):
    """Zeichnet ein eigenes (PNG-)Bild in rect. rect: QRectF, img: QImage."""
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QColor
    if img is None or img.isNull() or rect.width() < 1 or rect.height() < 1:
        painter.fillRect(rect, QColor(bg_color))
        return
    iw, ih = img.width(), img.height()
    if backdrop:
        painter.fillRect(rect, QColor(bg_color))
    if mode == "Füllen":
        painter.drawImage(rect, img)
    elif mode == "Zuschneiden":
        k = max(rect.width() / iw, rect.height() / ih)
        sw, sh = rect.width() / k, rect.height() / k
        painter.drawImage(rect, img, QRectF((iw - sw) / 2, (ih - sh) / 2, sw, sh))
    else:
        if not backdrop:
            painter.fillRect(rect, QColor(bg_color))
        k = min(rect.width() / iw, rect.height() / ih)
        w, h = iw * k, ih * k
        painter.drawImage(QRectF(rect.x() + (rect.width() - w) / 2, rect.y() + (rect.height() - h) / 2, w, h), img)


def sticker_for(cfg, sid, cache):
    from PySide6.QtGui import QImage
    paths = [p for p in cfg.get("stickers", []) if p]
    if not paths:
        return None
    path = paths[sid % len(paths)]
    if path not in cache:
        cache[path] = QImage(path)
    return cache[path]


def draw_effect(p, cfg, eff, frame, box, sid, cache):
    """Zeichnet EINEN Zensureffekt. box in Frame-Pixeln; frame = BGR-Array (für Pixel-Effekte)."""
    import cv2
    import numpy as np
    from PySide6.QtCore import Qt, QRectF
    from PySide6.QtGui import QColor, QFont, QImage, QPen
    x1, y1 = max(0, int(box[0])), max(0, int(box[1]))
    x2, y2 = int(box[2]), int(box[3])
    if frame is not None:
        x2, y2 = min(x2, frame.shape[1]), min(y2, frame.shape[0])
    if x2 - x1 < 2 or y2 - y1 < 2:
        return
    r = QRectF(x1, y1, x2 - x1, y2 - y1)
    cw, ch = x2 - x1, y2 - y1
    color = QColor(cfg["color"])
    if eff in PIXEL_EFFECTS and frame is not None:
        crop = frame[y1:y2, x1:x2]
        if eff in ("Verpixeln", "Verpixeln (grob)"):
            blk = max(2, int(cfg["pixel_block"])) * (2 if eff.endswith("(grob)") else 1)
            small = cv2.resize(crop, (max(1, cw // blk), max(1, ch // blk)), interpolation=cv2.INTER_AREA)
            out = cv2.resize(small, (cw, ch), interpolation=cv2.INTER_NEAREST)
        elif eff == "Weichzeichnen":
            k = max(1, int(cfg["blur_radius"]) // 4)
            small = cv2.resize(crop, (max(2, cw // 4), max(2, ch // 4)), interpolation=cv2.INTER_AREA)
            out = cv2.resize(cv2.GaussianBlur(small, (0, 0), k), (cw, ch), interpolation=cv2.INTER_LINEAR)
        elif eff == "Invertieren":
            out = 255 - crop
        else:
            noise = np.random.randint(0, 256, (max(1, ch // 6), max(1, cw // 6), 3), dtype=np.uint8)
            out = cv2.resize(noise, (cw, ch), interpolation=cv2.INTER_NEAREST)
        out = np.ascontiguousarray(out)
        p.drawImage(r, QImage(out.data, cw, ch, out.strides[0], QImage.Format_BGR888))
    elif eff == "Farbfläche":
        p.fillRect(r, color)
    elif eff == "Schwarze Ellipse":
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#000000"))
        p.drawEllipse(r)
    elif eff == "Warnstreifen":
        p.save()
        p.setClipRect(r, Qt.IntersectClip)
        p.fillRect(r, QColor("#ffd400"))
        step = max(14, int(min(cw, ch) / 4))
        p.setPen(QPen(QColor("#111111"), step / 2))
        for k in range(-ch, cw, step):
            p.drawLine(x1 + k, y2, x1 + k + ch, y1)
        p.restore()
    elif eff == "Eigenes Bild":
        draw_sticker(p, r, sticker_for(cfg, sid, cache), cfg.get("sticker_mode", "Füllen"), cfg["color"],
                     cfg.get("sticker_backdrop", True))
    else:                                                   # Schwarzer Balken / Text / Emoji / Fallback
        p.fillRect(r, QColor("#000000"))
        if eff == "Text":
            f = QFont(cfg["font"])
            f.setPixelSize(max(8, int(min(r.height() * 0.45, r.width() / max(3, len(cfg["text"])) * 1.6))))
            p.setFont(f)
            p.setPen(QColor(cfg["text_color"]))
            p.drawText(r, Qt.AlignCenter, cfg["text"])
        elif eff == "Emoji":
            f = QFont("Segoe UI Emoji")
            f.setPixelSize(max(8, int(min(r.height(), r.width()) * 0.7)))
            p.setFont(f)
            p.drawText(r, Qt.AlignCenter, cfg["emoji"])
    if cfg.get("border") and eff not in PIXEL_EFFECTS:
        p.setPen(QPen(QColor(255, 255, 255, 70), 1))
        p.setBrush(Qt.NoBrush)
        p.drawRect(r)


def pick_effect(cfg, group):
    eff = cfg["groups"].get(group, {}).get("effect", "Standard")
    return cfg["effect"] if (eff == "Standard" or eff not in EFFECTS) else eff


# ---------------------------------------------------------------------------
# Overlay (Qt)
# ---------------------------------------------------------------------------
def run_censor(cfg_path, status_path=None):
    from PySide6.QtCore import Qt, QTimer, QRect
    from PySide6.QtGui import QPainter, QColor, QFont, QGuiApplication, QRegion
    from PySide6.QtWidgets import QApplication, QWidget
    import winutil

    app = QApplication(sys.argv)
    worker = Worker(cfg_path)
    pid = os.getpid()

    class Overlay(QWidget):
        def __init__(self):
            super().__init__()
            self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool |
                                Qt.WindowTransparentForInput | Qt.WindowDoesNotAcceptFocus)
            self.setAttribute(Qt.WA_TranslucentBackground, True)
            self.setAttribute(Qt.WA_ShowWithoutActivating, True)
            screens = QGuiApplication.screens()
            scr = screens[min(len(screens) - 1, int(worker.cfg.get("monitor", 0)))]
            self.setGeometry(scr.geometry())
            worker.origin = (scr.geometry().x(), scr.geometry().y())
            self.excluded = False
            self.cache = {}
            self.items, self.sig, self.fid = [], None, -1
            self.rects = []
            self.badge_state = None

        def showEvent(self, e):
            super().showEvent(e)
            hwnd = int(self.winId())
            self.excluded = winutil.exclude_from_capture(hwnd)
            winutil.bring_topmost(hwnd)

        def scale(self):
            fw, fh = worker.frame_size
            return self.width() / max(1, fw), self.height() / max(1, fh)

        def tick(self):
            cfg = worker.cfg
            with worker.lock:
                vis = worker.tracker.visible(int(cfg["confirm_hits"]))
                frame, fid, panic = worker.frame, worker.frame_id, worker.panic_active
            wins = None
            if cfg.get("window_bind", True) and vis:
                wins = winutil.enumerate_windows(pid)
            fw, fh = worker.frame_size
            items = []
            with worker.lock:
                if wins is not None:
                    drop = bind_tracks(vis, wins, worker.origin)       # minimiertes/geschlossenes Fenster -> weg
                    if drop:
                        worker.tracker.tracks = [t for t in worker.tracker.tracks if t not in drop]
                        vis = [t for t in vis if t not in drop]
                snap = [(t.group, tuple(t.box), t.sid, t.hwnd) for t in vis]
            if panic and frame is not None:
                items.append(("Verpixeln", "", (0, 0, fw, fh), 0, QRegion(QRect(0, 0, fw, fh))))
            else:
                for group, box, sid, hwnd in snap:
                    if wins is not None and hwnd is not None:
                        reg = visible_region(box, hwnd, wins, worker.origin)
                    else:
                        reg = QRegion(QRect(int(box[0]), int(box[1]), int(box[2] - box[0]), int(box[3] - box[1])))
                    if not reg.isEmpty():
                        items.append((pick_effect(cfg, group), group, box, sid, reg))
            sig = tuple((e, g, tuple(int(v) for v in b), s, reg.boundingRect().getRect()) for e, g, b, s, reg in items)
            dep = any(e in PIXEL_EFFECTS for e, *_ in items)
            badge = (worker.paused, self.excluded, bool(cfg.get("show_badge")))
            if sig == self.sig and not (dep and fid != self.fid) and badge == self.badge_state:
                return
            sx, sy = self.scale()
            dirty = QRegion()
            for rc in self.rects:
                dirty += rc
            new_rects = []
            for e, g, b, s, reg in items:
                br = reg.boundingRect()
                rc = QRect(int(br.x() * sx) - 3, int(br.y() * sy) - 3, int(br.width() * sx) + 6, int(br.height() * sy) + 6)
                new_rects.append(rc)
                dirty += rc
            if badge != self.badge_state:
                dirty += QRect(0, 0, 460, 34)
            self.items, self.sig, self.fid, self.rects, self.badge_state = items, sig, fid, new_rects, badge
            self.update(dirty)

        def paintEvent(self, e):
            with worker.lock:
                frame = worker.frame
            cfg = worker.cfg
            p = QPainter(self)
            p.setRenderHint(QPainter.Antialiasing, False)
            sx, sy = self.scale()
            for eff, group, box, sid, reg in self.items:
                p.save()
                p.scale(sx, sy)
                p.setClipRegion(reg)
                draw_effect(p, cfg, eff, frame, box, sid, self.cache)
                p.restore()
            if cfg.get("show_badge"):
                p.setPen(QColor(255, 255, 255, 190))
                p.setBrush(QColor(0, 0, 0, 120))
                p.setFont(QFont("Segoe UI", 8))
                msg = "● Zensur aktiv" if not worker.paused else "❚❚ Zensur pausiert"
                if not self.excluded:
                    msg += "  (Overlay NICHT aus Aufnahme ausgeschlossen!)"
                p.drawRect(6, 6, 250 if self.excluded else 420, 18)
                p.drawText(12, 19, msg)
            p.end()

    overlay = Overlay()
    overlay.show()

    hk = winutil.make_hotkey_filter()
    if hk is not None:
        app.installNativeEventFilter(hk)
        hk.register(1, winutil.MOD_CONTROL | winutil.MOD_ALT, winutil.VK_F11,
                    lambda: setattr(worker, "paused", not worker.paused))
        hk.register(2, winutil.MOD_CONTROL | winutil.MOD_ALT, 0x79, app.quit)     # Strg+Alt+F10

    def write_status():
        if not status_path:
            return
        try:
            d = dict(worker.stats)
            d.update(running=True, paused=worker.paused, error=worker.error,
                     excluded=overlay.excluded, ts=time.time())
            Path(status_path).write_text(json.dumps(d), encoding="utf-8")
        except Exception:
            pass

    t_tick = QTimer()
    t_tick.timeout.connect(overlay.tick)
    t_tick.start(8)                    # Bindung ans Fenster/Z-Reihenfolge ~120x pro Sekunde, gezeichnet wird nur bei Änderung
    t_status = QTimer()
    t_status.timeout.connect(write_status)
    t_status.start(1000)
    worker.start()
    code = app.exec()
    worker.stop_flag = True
    worker.join(timeout=3)
    if hk is not None:
        hk.unregister_all()
    try:
        if status_path:
            Path(status_path).write_text(json.dumps({"running": False}), encoding="utf-8")
    except Exception:
        pass
    return code


# ---------------------------------------------------------------------------
# Diagnose und Benchmark
# ---------------------------------------------------------------------------
def run_diagnose(cfg_path=None):
    import platform
    print("=== Diagnose Live-Zensur ===")
    print("Python:", sys.version.split()[0], platform.platform())
    try:
        from importlib import metadata as md
    except Exception:
        md = None
    for pkg in ("onnxruntime", "onnxruntime-directml", "onnxruntime-gpu", "opencv-python-headless",
                "opencv-python", "numpy", "nudenet", "dxcam", "comtypes", "mss", "PySide6"):
        try:
            print(f"  {pkg:<24} {md.version(pkg)}")
        except Exception:
            print(f"  {pkg:<24} -")
    ok = True
    try:
        import onnxruntime as ort
        print("ONNX-Provider verfügbar:", ort.get_available_providers())
    except Exception as e:
        print("!! onnxruntime lässt sich nicht laden:", e)
        return
    import numpy as np
    cfg = load_config(cfg_path) if cfg_path else json.loads(json.dumps(DEFAULT_CONFIG))
    thr = class_thresholds(cfg)
    print("Aktive Klassen:", [LABELS[i] for i in range(len(LABELS)) if thr[i] < 1],
          "\nSchwellen:", {LABELS[i]: round(float(thr[i]), 2) for i in range(len(LABELS)) if thr[i] < 1})
    try:
        model, note = resolve_model(cfg)
        print("Modell:", model, note)
        print("640m vorhanden:", model_640m_path() or "nein")
    except Exception as e:
        print("!! Modell nicht gefunden:", e)
        return
    frame = (np.random.rand(1080, 1920, 3) * 255).astype("uint8")
    for gpu in (True, False):
        for acc in ACCURACY:
            try:
                d = Detector(model, gpu, acc)
                d.detect(frame, thr)
                t = time.perf_counter()
                for _ in range(5):
                    d.detect(frame, thr)
                ms = (time.perf_counter() - t) / 5 * 1000
                print(f"gpu={gpu!s:<5} {acc:<9}: {d.provider.replace('ExecutionProvider', ''):<9} {ms:6.1f} ms {d.note}")
            except Exception as e:
                ok = False
                print(f"!! gpu={gpu} {acc} fehlgeschlagen: {type(e).__name__}: {e}")
    try:
        import dxcam
        cam = dxcam.create(output_color="BGR")
        fr, t = None, time.perf_counter()
        while fr is None and time.perf_counter() - t < 1.5:
            fr = cam.grab()
        print("dxcam Aufnahme:", "OK " + str(fr.shape) if fr is not None else "kein Bild (Bildschirm unverändert?)")
        cam.release()
    except Exception as e:
        print("dxcam nicht nutzbar:", type(e).__name__, e)
        try:
            import mss
            with mss.mss() as sct:
                print("mss Aufnahme: OK", sct.grab(sct.monitors[1]).size)
        except Exception as e2:
            ok = False
            print("!! auch mss schlägt fehl:", e2)
    try:
        import winutil
        w = winutil.enumerate_windows(os.getpid())
        print("Fensterliste:", "nur unter Windows" if w is None else f"{len(w)} sichtbare Fenster erkannt")
    except Exception as e:
        print("Fensterliste Fehler:", e)
    print("\n=> " + ("Alles bereit." if ok else "Es gibt Probleme (siehe '!!' oben) - schick mir diesen Text."))


def run_benchmark(cfg_path=None):
    import numpy as np
    cfg = load_config(cfg_path) if cfg_path else json.loads(json.dumps(DEFAULT_CONFIG))
    thr = class_thresholds(cfg)
    frame = (np.random.rand(1080, 1920, 3) * 255).astype("uint8")
    models = [("320n", _builtin_320n())]
    if model_640m_path():
        models.append(("640m", model_640m_path()))
    for label, model in models:
        print("Modell:", label, model)
        for gpu in (False, True):
            for acc in ACCURACY:
                try:
                    d = Detector(model, gpu, acc)
                except Exception as e:
                    print(f"  gpu={gpu} {acc}: Fehler {e}")
                    continue
                if gpu and d.providers[0] == "CPUExecutionProvider":
                    continue
                for _ in range(3):
                    d.detect(frame, thr)
                t = time.perf_counter()
                n = 20
                for _ in range(n):
                    d.detect(frame, thr)
                ms = (time.perf_counter() - t) / n * 1000
                print(f"  {d.provider.replace('ExecutionProvider', ''):<9} {acc:<9}: {ms:6.1f} ms/Bild  (~{1000/ms:5.1f}/s) {d.note}")
