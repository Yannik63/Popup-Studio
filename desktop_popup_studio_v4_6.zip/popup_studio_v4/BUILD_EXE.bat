@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Bitte zuerst START_POPUP_STUDIO.bat einmal ausfuehren.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install pyinstaller
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --name DesktopPopupStudio ^
  --collect-data nudenet --collect-all onnxruntime --collect-submodules dxcam ^
  --hidden-import comtypes --hidden-import mss popup_studio.py
if errorlevel 1 (
  echo EXE-Build fehlgeschlagen. Nutze solange START_POPUP_STUDIO.bat.
  pause
  exit /b 1
)
echo.
echo Fertig: dist\DesktopPopupStudio\DesktopPopupStudio.exe  ^(ganzen Ordner behalten^)
pause
endlocal
