"""Kleine Windows-Helfer (ctypes, keine Extra-Pakete).

Alles hier ist defensiv geschrieben: Wenn etwas nicht klappt (z. B. andere
Windows-Version), geben die Funktionen False/None zurück und das Programm
läuft trotzdem weiter.
"""
import os
import sys
import ctypes
from ctypes import wintypes

IS_WIN = sys.platform == "win32"

MOD_ALT, MOD_CONTROL, MOD_SHIFT, MOD_NOREPEAT = 0x1, 0x2, 0x4, 0x4000
VK_F11, VK_F12 = 0x7A, 0x7B
WM_HOTKEY = 0x0312


# --------------------------------------------------------------------------
# Eigene Taskleisten-Gruppe pro Fenster (AppUserModelID per Fenster)
# --------------------------------------------------------------------------
class _GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_ulong), ("Data2", ctypes.c_ushort),
                ("Data3", ctypes.c_ushort), ("Data4", ctypes.c_ubyte * 8)]


class _PROPERTYKEY(ctypes.Structure):
    _fields_ = [("fmtid", _GUID), ("pid", wintypes.DWORD)]


class _PROPVARIANT(ctypes.Structure):
    _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort),
                ("r2", ctypes.c_ushort), ("r3", ctypes.c_ushort),
                ("p", ctypes.c_void_p), ("pad", ctypes.c_void_p)]


def _guid(text):
    import uuid
    u = uuid.UUID(text)
    g = _GUID()
    g.Data1, g.Data2, g.Data3 = u.time_low, u.time_mid, u.time_hi_version
    g.Data4 = (ctypes.c_ubyte * 8)(*u.bytes[8:])
    return g


last_error = ""


def set_window_appid(hwnd, appid):
    """Gibt dem Fenster eine eigene AppUserModelID.

    Windows zeigt Fenster mit unterschiedlicher ID als getrennte Taskleisten-
    Schaltflächen/Gruppen an, selbst wenn sie vom selben Programm stammen.
    """
    global last_error
    if not IS_WIN:
        last_error = "kein Windows"
        return False
    try:
        shell32 = ctypes.windll.shell32
        propsys = ctypes.windll.propsys
        ole32 = ctypes.windll.ole32
        iid = _guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99")  # IPropertyStore
        key = _PROPERTYKEY(_guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), 5)
        store = ctypes.c_void_p()
        shell32.SHGetPropertyStoreForWindow.argtypes = [
            wintypes.HWND, ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)]
        shell32.SHGetPropertyStoreForWindow.restype = ctypes.c_long
        hr = shell32.SHGetPropertyStoreForWindow(hwnd, ctypes.byref(iid), ctypes.byref(store))
        if hr != 0 or not store.value:
            last_error = f"SHGetPropertyStoreForWindow HRESULT={hr & 0xFFFFFFFF:#x}"
            return False
        vtbl = ctypes.cast(store, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
        SetValue = ctypes.WINFUNCTYPE(
            ctypes.c_long, ctypes.c_void_p, ctypes.POINTER(_PROPERTYKEY),
            ctypes.POINTER(_PROPVARIANT))(vtbl[6])
        Commit = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)(vtbl[7])
        Release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtbl[2])
        pv = _PROPVARIANT()
        propsys.InitPropVariantFromString.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(_PROPVARIANT)]
        propsys.InitPropVariantFromString(appid, ctypes.byref(pv))
        hr2 = SetValue(store, ctypes.byref(key), ctypes.byref(pv))
        ok = hr2 == 0
        if not ok:
            last_error = f"SetValue HRESULT={hr2 & 0xFFFFFFFF:#x}"
        Commit(store)
        ole32.PropVariantClear(ctypes.byref(pv))
        Release(store)
        return ok
    except Exception as e:
        last_error = f"{type(e).__name__}: {e}"
        return False


# --------------------------------------------------------------------------
# Fenster-Eigenschaften
# --------------------------------------------------------------------------
def exclude_from_capture(hwnd):
    """Fenster ist für Screenshots/Bildschirmaufnahme unsichtbar (Win10 2004+)."""
    if not IS_WIN:
        return False
    try:
        return bool(ctypes.windll.user32.SetWindowDisplayAffinity(wintypes.HWND(hwnd), 0x11))
    except Exception:
        return False


def bring_topmost(hwnd):
    if not IS_WIN:
        return
    try:
        HWND_TOPMOST = wintypes.HWND(-1)
        # SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW
        ctypes.windll.user32.SetWindowPos(wintypes.HWND(hwnd), HWND_TOPMOST, 0, 0, 0, 0,
                                          0x0002 | 0x0001 | 0x0010 | 0x0040)
    except Exception:
        pass


_enum_ready = False


# --------------------------------------------------------------------------
# Prozess-Werkzeuge (für Wächter und Prioritäten)
# --------------------------------------------------------------------------
def process_alive(pid):
    """True, solange der Prozess läuft (auch wenn er hängt)."""
    if not IS_WIN:
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    try:
        k = ctypes.windll.kernel32
        k.OpenProcess.restype = wintypes.HANDLE
        h = k.OpenProcess(0x1000, False, pid)            # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        try:
            code = wintypes.DWORD()
            k.GetExitCodeProcess(h, ctypes.byref(code))
            return code.value == 259                     # STILL_ACTIVE
        finally:
            k.CloseHandle(h)
    except Exception:
        return False


def kill_process(pid):
    """Beendet NUR diesen Prozess sofort und hart (wie 'Task beenden' im Task-Manager) – Kindprozesse bleiben."""
    if not IS_WIN:
        try:
            os.kill(pid, 9)
            return True
        except OSError:
            return False
    try:
        k = ctypes.windll.kernel32
        k.OpenProcess.restype = wintypes.HANDLE
        h = k.OpenProcess(0x0001, False, pid)            # PROCESS_TERMINATE
        if h:
            try:
                if k.TerminateProcess(h, 1):
                    return True
            finally:
                k.CloseHandle(h)
    except Exception:
        pass
    try:                                                 # Rückfall: taskkill ohne /T
        import subprocess
        subprocess.run(["taskkill", "/PID", str(pid), "/F"], creationflags=0x08000000, timeout=5,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return not process_alive(pid)
    except Exception:
        return False


def memory_mb(pid):
    """Arbeitsspeicher (Working Set) des Prozesses in MB, 0 bei Fehler."""
    if not IS_WIN:
        return 0.0
    try:
        class PMC(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
        k = ctypes.windll.kernel32
        k.OpenProcess.restype = wintypes.HANDLE
        h = k.OpenProcess(0x1010, False, pid)            # QUERY_LIMITED_INFORMATION | VM_READ
        if not h:
            return 0.0
        try:
            c = PMC()
            c.cb = ctypes.sizeof(c)
            ok = ctypes.windll.psapi.GetProcessMemoryInfo(h, ctypes.byref(c), c.cb)
            return c.WorkingSetSize / 1048576.0 if ok else 0.0
        finally:
            k.CloseHandle(h)
    except Exception:
        return 0.0


def count_windows(pid):
    """Anzahl sichtbarer Top-Level-Fenster dieses Prozesses (zählt auch minimierte)."""
    if not IS_WIN:
        return 0
    try:
        u = ctypes.windll.user32
        n = [0]
        ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def cb(hwnd, _lp):
            try:
                if u.IsWindowVisible(hwnd):
                    p = wintypes.DWORD(0)
                    u.GetWindowThreadProcessId(hwnd, ctypes.byref(p))
                    if p.value == pid:
                        n[0] += 1
            except Exception:
                pass
            return True
        u.EnumWindows(ENUMPROC(cb), 0)
        return n[0]
    except Exception:
        return 0


def set_priority(below=False, above=False):
    """Prozess-Priorität: 'below' für das Hauptprogramm (hält Windows/Task-Manager flüssig), 'above' für den Wächter."""
    if not IS_WIN:
        return
    try:
        k = ctypes.windll.kernel32
        k.GetCurrentProcess.restype = wintypes.HANDLE
        k.SetPriorityClass(k.GetCurrentProcess(), 0x00004000 if below else 0x00008000 if above else 0x20)
    except Exception:
        pass


_mutex_handles = []


def single_instance(name):
    """False, wenn schon eine Instanz mit diesem Namen läuft."""
    if not IS_WIN:
        return True
    try:
        k = ctypes.windll.kernel32
        k.CreateMutexW.restype = wintypes.HANDLE
        h = k.CreateMutexW(None, False, "Local\\" + name)
        err = k.GetLastError()
        _mutex_handles.append(h)
        return err != 183                                  # ERROR_ALREADY_EXISTS
    except Exception:
        return True


def enumerate_windows(exclude_pid=0):
    """Sichtbare, nicht minimierte Top-Level-Fenster von OBEN nach UNTEN.

    Rückgabe: [(hwnd, links, oben, rechts, unten), ...] in Bildschirm-Pixeln,
    oder None (kein Windows / Fehler). Minimierte, verdeckte (andere virtuelle
    Desktops, 'cloaked') und durchklickbare Overlay-Fenster werden ausgelassen.
    """
    global _enum_ready
    if not IS_WIN:
        return None
    try:
        u, d = ctypes.windll.user32, ctypes.windll.dwmapi
        if not _enum_ready:
            u.IsWindowVisible.argtypes = [wintypes.HWND]
            u.IsIconic.argtypes = [wintypes.HWND]
            u.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
            u.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
            u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
            d.DwmGetWindowAttribute.argtypes = [wintypes.HWND, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD]
            _enum_ready = True
        out = []
        ENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def cb(hwnd, _lp):
            try:
                if not u.IsWindowVisible(hwnd) or u.IsIconic(hwnd):
                    return True
                cloaked = wintypes.DWORD(0)
                d.DwmGetWindowAttribute(hwnd, 14, ctypes.byref(cloaked), 4)      # DWMWA_CLOAKED
                if cloaked.value:
                    return True
                ex = u.GetWindowLongW(hwnd, -20) & 0xFFFFFFFF
                if (ex & 0x20) and (ex & 0x80000):                               # click-through Overlay
                    return True
                rc = wintypes.RECT()
                if d.DwmGetWindowAttribute(hwnd, 9, ctypes.byref(rc), ctypes.sizeof(rc)) != 0:  # sichtbarer Rahmen
                    u.GetWindowRect(hwnd, ctypes.byref(rc))
                if rc.right - rc.left <= 0 or rc.bottom - rc.top <= 0:
                    return True
                if exclude_pid:
                    pid = wintypes.DWORD(0)
                    u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                    if pid.value == exclude_pid:
                        return True
                out.append((int(hwnd), rc.left, rc.top, rc.right, rc.bottom))
            except Exception:
                pass
            return True

        u.EnumWindows(ENUMPROC(cb), 0)      # EnumWindows liefert die Fenster in Z-Reihenfolge, oberstes zuerst
        return out
    except Exception:
        return None


def foreground_process_name():
    """Dateiname des Programms im Vordergrund (z. B. 'chrome.exe') oder ''."""
    if not IS_WIN:
        return ""
    try:
        user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
        hwnd = user32.GetForegroundWindow()
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        h = kernel32.OpenProcess(0x1000, False, pid.value)  # QUERY_LIMITED_INFORMATION
        if not h:
            return ""
        try:
            buf = ctypes.create_unicode_buffer(520)
            size = wintypes.DWORD(520)
            if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                return os.path.basename(buf.value).lower()
        finally:
            kernel32.CloseHandle(h)
    except Exception:
        pass
    return ""


# --------------------------------------------------------------------------
# Globale Hotkeys (funktionieren auch, wenn ein Popup oder Spiel den Fokus hat)
# --------------------------------------------------------------------------
def make_hotkey_filter():
    """Erzeugt einen Qt-Event-Filter für globale Hotkeys (oder None)."""
    if not IS_WIN:
        return None
    from PySide6.QtCore import QAbstractNativeEventFilter

    class HotkeyFilter(QAbstractNativeEventFilter):
        def __init__(self):
            super().__init__()
            self.callbacks = {}

        def register(self, hk_id, mods, vk, callback):
            try:
                ok = bool(ctypes.windll.user32.RegisterHotKey(None, hk_id, mods | MOD_NOREPEAT, vk))
            except Exception:
                ok = False
            if ok:
                self.callbacks[hk_id] = callback
            return ok

        def unregister_all(self):
            for hk_id in list(self.callbacks):
                try:
                    ctypes.windll.user32.UnregisterHotKey(None, hk_id)
                except Exception:
                    pass
            self.callbacks.clear()

        def nativeEventFilter(self, event_type, message):
            try:
                if bytes(event_type) == b"windows_generic_MSG":
                    msg = wintypes.MSG.from_address(int(message))
                    if msg.message == WM_HOTKEY and msg.wParam in self.callbacks:
                        self.callbacks[msg.wParam]()
                        return True, 0
            except Exception:
                pass
            return False, 0

    return HotkeyFilter()
