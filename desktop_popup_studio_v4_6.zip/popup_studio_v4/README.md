# Desktop Popup Studio v4.6

## Neu in 4.6
- **Speicherexplosion behoben (hing mit der Zensur zusammen):** Die Bild-Zensur der Popups hat für jede neue Bildgröße eine neue KI-Sitzung
  angelegt und nie freigegeben (~90 MB pro Bildgröße, bei DirectML zusätzlich Sekunden Wartezeit pro Sitzung im Hauptprogramm).
  Im Test: 18 verschieden große Bilder = 1,7 GB. Jetzt: auf der CPU eine einzige Sitzung für alle Größen (~190 MB),
  auf der Grafikkarte feste Eingabeformen und höchstens 6 Sitzungen.
- **Video-Obergrenze ist jetzt hart:** Die Grenze sitzt im Video-Popup selbst (ein 4. Video wird schon beim Erzeugen abgelehnt), unabhängig von
  Listen oder Timern. Decoder und Audio werden beim Schließen sofort freigegeben; ein Fehler beim Aufräumen kann ein Popup nicht mehr
  „unsichtbar“ in der Zählung zurücklassen. Die zufällige Startposition springt nur noch einmal (vorher mögliche Endlosschleife bei Statuswechseln).
- **Video-Speicherbremse** (Sicherheit & Hilfe): Überschreitet das Programm 1500 MB, werden alle Videos geschlossen und 20 s gesperrt
  – bevor der Wächter eingreift. Das Dashboard zeigt den aktuellen Speicher.
- **Multimedia-Backend wählbar** (Bild · Video · Audio → Videos, wirkt nach Neustart): „windows (WMF)“ statt des Standard-Backends – falls Videos
  trotzdem viel Speicher fressen oder ruckeln.
- **Einstellungssuche:** Suchfeld oben links (Strg+F). Findet Einstellungen, Schalter und Bereiche, springt zur Seite und lässt die Einstellung gelb aufleuchten.


## Neu in 4.5 – Absturz-/Hänger-Schutz
- **Wächter mit Not-Aus-Knopf (eigener Prozess):** Ein winziger roter „■ STOP“-Knopf (56×18 px) sitzt ganz oben in einer Bildschirmecke
  (Standard: oben links, einstellbar), solange Popups laufen. Weil er ein **eigener Prozess** ist, bleibt er bedienbar, wenn Popup Studio hängt
  oder abstürzt (dann steht dort „■ HÄNGT“). Ein Klick beendet Popup Studio sofort und hart – wie „Task beenden“ im Task-Manager. Er holt sich
  alle 0,1 s den obersten Platz zurück, und neue Popups werden so platziert, dass sie ihn nicht überdecken.
  Zusätzlich Hotkey **Strg+Alt+Umschalt+F12** (ebenfalls im Wächter-Prozess).
- **Automatische Notbremse:** Der Wächter beendet Popup Studio selbst, wenn die Oberfläche länger als 10 s nicht reagiert (einstellbar),
  deutlich mehr Fenster offen sind als erlaubt oder der Arbeitsspeicher über 3000 MB steigt (einstellbar). Die Zensur läuft als eigener Prozess weiter
  (beenden mit Strg+Alt+F10).
- **Fensterzahl hart begrenzt:** Alle Wege (Timer, Fehlklick-Strafen, Vorschau, Audio-Fenster) laufen jetzt durch eine einzige Sperre.
  Absolute Obergrenze 40 Fenster; „Strafe darf Maximum überschreiten“ erlaubt höchstens +10. Videos gleichzeitig: max. 3 (einstellbar).
  Das Dashboard zeigt „aktive Fenster / erlaubt“. Achtung: **Die Presets ändern „Gleichzeitig max.“ mit** (Adware 10, Albtraum 25) – das steht jetzt im Protokoll.
- **Nur eine Instanz:** Ein zweites Starten wird abgefangen (zwei Instanzen = doppelt so viele Popups).
- **Hauptprogramm läuft mit niedrigerer Priorität**, damit Windows und der Task-Manager auch unter Last bedienbar bleiben.
- **Absturzprotokolle:** `crash.log` (Python-Fehler) und `crash_native.log` (harte Abstürze, außerdem eine Stapelspur, falls die Oberfläche hängt) in
  `%APPDATA%\PopupStudio`. Bitte schicken, falls es wieder hakt.
- **Bild-Zensur der Popups** erkennt jedes Bild nur noch einmal (Zwischenspeicher) und rechnet große Bilder vorher herunter – verhindert Ruckler.


## Neu in 4.4
- **Profile, Export/Import, Zurücksetzen** (Dashboard, Karte „Profile & Standard“): kompletter Stand (alle Seiten, Text-Vorlagen, Medienliste,
  Zensur, eigene PNGs) als benanntes Profil speichern/laden/löschen, in eine Datei exportieren oder importieren und
  **alles auf Standard zurücksetzen** (wahlweise mit oder ohne Medienbibliothek). Änderungen werden weiterhin automatisch gespeichert.
- **Mehr Popup-Arten für Bild & Video** (Seite „Größe & Verhalten“, Karte „Popup-Vielfalt“): Banner am unteren Bildschirmrand,
  Skyscraper an der Seite (mit Button), Karte wie Werbung auf Nachrichtenseiten, rahmenlose Anzeige – hell oder dunkel, mit
  „Anzeige“-/„Sponsored“-Kennzeichen. Überschrift, Unterzeile und Button kommen aus deinen Text-Vorlagen.
- **Fiese Schließknöpfe** (Karte „Fiese Schließknöpfe“): winziges, blasses X mit kleinerer, versetzter unsichtbarer Trefferfläche ·
  falsches X, das nichts schließt und mehr öffnet (das echte ist winzig in einer anderen Ecke) · X, das nur manchmal schließt und sonst
  mehr öffnet · X erst nach Countdown · winziges X in anderer Ecke. Klick auf das sichtbare X neben die Trefferfläche zählt als Fehlklick.
- **Nur oberhalb von „Leicht nervig“:** Die Presets *Adware* und *Kompletter Albtraum* schalten Vielfalt und fiese Knöpfe ein, *Leicht nervig*
  schaltet sie aus (alles lässt sich auch manuell einstellen). Not-Aus bleibt immer erreichbar.


## Neu in 4.3
- **Männer werden nicht mehr zensiert:** Das Modell rät das Geschlecht bei Gesichtern und Brust und verwechselt gern. Jetzt läuft die
  männliche Klasse als Gegenprobe mit: Ist sie an derselben Stelle gleich sicher oder sicherer, wird der „weibliche“ Treffer verworfen.
  Männer selbst werden nie zensiert, außer Genitalien.
- **„Gesicht“ ist jetzt „Augen (weiblich)“:** Das Modell kennt keine Augen, der Augenbalken wird aus der erkannten Gesichtsbox geschnitten
  (Position über „Rand“ der Gruppe feinjustierbar).
- **Hängende Zensur-Kästen behoben (YouTube, Scrollen, Neuladen):** Bei ruhigem Bild wurden Boxen fälschlich als „bestätigt“ markiert und
  blieben für immer. Jetzt zählen nur echte Treffer, und ändert sich der Inhalt unter einer Box stark, muss die nächste Erkennung sie
  sofort neu bestätigen – sonst verschwindet sie nach ca. 0,1 s.
- **Bild-Zensur der Popups ist jetzt eigenständig** (Seite „Bild · Video · Audio“): eigener Schalter, eigene Gruppen, eigener Effekt,
  eigene Empfindlichkeit – oder „Wie Live-Zensur“. Sie hat nichts mehr mit dem Ein/Aus der Live-Zensur zu tun.
- **640m-Download repariert:** drei Quellen nacheinander, Prüfsumme, jeder Fehler wird einzeln angezeigt. Die Statusanzeige nennt das tatsächlich
  geladene Modell (vorher lief bei fehlendem 640m still das 320n – deshalb war kein Unterschied zu sehen).

### 640m manuell herunterladen (falls der Knopf scheitert)
Datei `640m.onnx` (103.538.690 Bytes, SHA-256 `04fe3d77980780c1f8297dc6d7f942fd5b3abe6942a188f742a85241e4f634eb`) von einer dieser Seiten:
- https://huggingface.co/ServiceStack/comfy-gateway/resolve/main/640m.onnx
- https://huggingface.co/spaces/Nymbo/Nudity-Censor/resolve/main/640m.onnx
- https://github.com/notAI-tech/NudeNet/releases/download/v3.4-weights/640m.onnx

Ablegen in `%APPDATA%\PopupStudio\models\640m.onnx` (Ordner ggf. anlegen) **oder** unter „Eigenes Modell (.onnx)“ auswählen.
Dann „Modell: 640m“ wählen und die Zensur neu starten; in der Statusanzeige muss `Modell 640m.onnx` stehen.


## Neu in 4.2
- **Zensur nur im betroffenen Fenster:** Jede Box wird an das Fenster gebunden, in dem sie erkannt wurde. Sie wird auf dessen sichtbaren Bereich
  begrenzt (liegt nie über anderen Fenstern), wandert beim Verschieben mit und verschwindet sofort, wenn das Fenster minimiert/geschlossen wird.
  Abschaltbar unter „Genauigkeit & Tempo“ (Fenster-Bindung).
- **Deutlich bessere Erkennung:**
  - Das Modell läuft jetzt mit Bildschirmformat und höherer Auflösung statt mit einem kleinen gepolsterten Quadrat; vier Stufen
    (Schnell / Standard / Genau / Maximal, mit Kacheln).
  - Auswertung korrigiert: Zweitbeste Klassen zählen jetzt mit (vorher konnte ein Genital-Treffer von einer anderen Klasse
    „verschluckt“ werden) und die Unterdrückung doppelter Boxen läuft je Klasse.
  - Eigene Mindest-Sicherheit und eigener Rand je Gruppe; Genitalien stehen bewusst niedrig (15 %). Globaler Regler „Empfindlichkeit verschieben“.
  - Optionales Modell **640m** (deutlich genauer, ~100 MB): Download-Knopf unter „Genauigkeit & Tempo“.
- **Mehr Zensur-Optionen:** 16 Gruppen (Brüste, Vulva, Genitalien männlich, Gesäß, After, Bauch, Achseln, Füße, Gesicht – frei und bedeckt),
  Männer nur Genitalien. 12 Effekte, neu: Schwarze Ellipse, Verpixeln (grob), Invertieren, Rauschen, Warnstreifen.
- **Tempo:** Erkennung läuft ohne künstliche Wartezeit (bis 60/s), Zensur-Haltezeit nur noch 150 ms, das Overlay zeichnet nur geänderte Bereiche.


## Neu in 4.1 (Korrekturen)
- **Zensur erkannte nichts:** Der Empfindlichkeits-Regler schrieb Prozentwerte, die Engine erwartete 0–1. Dadurch lag die Schwelle
  praktisch bei 1000 % und es wurde nie etwas erkannt (live und bei Popup-Bildern). Behoben.
- **Installation:** Klammern in Kommentarzeilen konnten die BAT mitten in der Einrichtung zerlegen. Neu geschrieben; am Ende wird geprüft,
  ob das Zensur-Modul wirklich da ist. Die Einrichtung läuft einmalig erneut (neue Marker-Datei).
- **GPU-Absicherung:** DirectML wird nur genutzt, wenn es dieselben Ergebnisse wie die CPU liefert, sonst automatisch CPU.
- **Bildschirmaufnahme:** `grab()` statt Dauerstream (blockierte bei unverändertem Bild).
- **Fehler sind sichtbar:** Scheitert die Bild-Zensur der Popups, steht es im Protokoll statt stillschweigend unzensiert zu bleiben.
- **Eigene PNGs als Zensur:** Effekt „Eigenes Bild“ (pro Gruppe oder als Standard), mehrere PNGs möglich (jeder Treffer bekommt eins),
  Darstellung Füllen / Einpassen / Zuschneiden, optional Farbfläche dahinter. Gilt live und für Popup-Bilder.
- **Taskleiste:** Die eigene AppID wird jetzt gesetzt, bevor das Fenster angezeigt wird (vorher danach – dann hat Windows die Gruppierung schon festgelegt).
- **Diagnose-Knopf** (Live-Zensur): prüft Pakete, Modell, GPU, Aufnahme und zeigt, woran es hakt.

Popup-Baukasten für dein Horror-OS-Projekt: Bilder, Videos, Audio und eigene Text-Popups
zufällig auf dem echten Desktop – plus optionale Live-Zensur über allen Fenstern.

## Starten
1. ZIP entpacken (nicht aus der ZIP heraus starten).
2. `START_POPUP_STUDIO.bat` doppelklicken. Beim ersten Mal werden Pakete installiert (Internet nötig, ein paar Minuten).
3. Danach startet derselbe Doppelklick sofort. Python 3.11 oder 3.12 empfohlen.

Optional: `BUILD_EXE.bat` baut eine EXE. **Das ist ungetestet** (ich konnte hier kein Windows-Build prüfen) –
die BAT-Variante ist der verlässliche Weg.

## Not-Aus (damit du nie die Kontrolle verlierst)
- Rote Leiste **POPUPS STOPPEN** am unteren Bildschirmrand (wird alle 250 ms wieder nach ganz oben geholt)
- Hotkey **Strg + Alt + F12** (global, auch wenn ein Popup den Fokus hat)
- Tray-Symbol neben der Uhr → „Popups stoppen“
- Zusätzlich: „Automatisch stoppen nach X Minuten“ im Dashboard

## Was in v4 anders ist
- **Klickregeln wie gewünscht:** Klick aufs X = Popup schließt sich, keine Folgen. Klick irgendwo anders im Popup
  (Bild, Video, Text, auch knapp neben dem X) = 2–3 neue Popups (alles einstellbar).
- **Größen-Obergrenze:** 1/2, 1/4, 1/9, 1/16, 1/25 oder 1/36 der Bildschirmfläche. Modi: Original (nur verkleinern),
  immer auf Obergrenze, zufällig zwischen Min und Max, feste Breite. Seitenverhältnis bleibt, Hoch- und Querformat
  ergeben unterschiedliche Fenster.
- **Eigener Taskleisten-Eintrag pro Popup** (jedes Fenster bekommt eine eigene Windows-AppID).
- **Neue Oberfläche** (dunkel, Seitenleiste, Vorschaubilder), jedes Modul einzeln schaltbar mit Häufigkeits-Regler.
- **Text-Popups:** Vorlagenliste, Schrift (Art, Größe, fett/kursiv/unterstrichen/durchgestrichen, Abstand), Verlauf,
  Rahmen, Rundung, Effekte (Neon, Glitch, Blinken, Wackeln, Schreibmaschine, Regenbogen, Pulsieren, Scanlines),
  5 Stil-Presets. Platzhalter `{user}` `{pc}` `{time}` `{date}` (Windows-Name, PC-Name, Uhrzeit, Datum) für Meta-Horror.
- **Mehr Optionen:** GIFs, Bild-Effekte, Video-Tempo/Zufallsstart, Audio ohne Fenster, mehrere Monitore u. v. m.
- Einstellungen werden automatisch gespeichert (`%APPDATA%\PopupStudio`).

## Live-Zensur
Eigener Prozess (bremst die Popups nicht), Start/Stopp auf der Seite „Live-Zensur“.

Ablauf: Bildschirm aufnehmen (dxcam, Fallback mss) → NudeNet-Modell (ONNX, lokal, GPU über DirectML falls möglich)
→ Boxen glätten und kurz halten (gegen Flackern) → durchklickbares Overlay zeichnet die Zensur.
Das Overlay ist für die Aufnahme unsichtbar (`WDA_EXCLUDEFROMCAPTURE`), deshalb gibt es keine Rückkopplung.

- Pro Körperregion an/aus und eigener Effekt: schwarzer Balken, Farbfläche, Verpixeln, Weichzeichnen, Text, Emoji
- Genauigkeitsstufen, Modellwahl (320n / 640m), Empfindlichkeit, Haltezeit, Glättung, Erkennungen pro Sekunde
- Pro App (nur in / außer in bestimmten Programmen, gilt für das Fenster im Vordergrund)
- Notfall-Modus: ganzer Bildschirm verpixelt, wenn viele Treffer gleichzeitig
- Optional auch für die eigenen Bilder der Popups
- Hotkeys: Strg+Alt+F11 Pause/Weiter · Strg+Alt+F10 beenden
- **„Geschwindigkeit testen“** misst auf deinem PC (RTX 3080), was machbar ist. Mach das zuerst.

Grenzen, ehrlich: Die KI ist nicht perfekt – besonders bei gezeichneten Bildern (Anime/Hentai/Comics) ist NudeNet deutlich schwächer als bei Fotos, auch das 640m-Modell (Fehlalarme und Übersehenes sind normal). Ein neu auftauchendes Bild kann
für einen Augenblick (Erkennungsdauer + Zeichnen) unzensiert sein. Bei schnellem Scrollen hinkt die Box kurz hinterher
(dafür gibt es den Sicherheitsrand). Exklusiver Vollbildmodus von Spielen/Playern kann das Overlay verdecken (randloses
Fenster geht). Geschützte Videos (DRM) sind je nach Browser/Player in der Aufnahme schwarz.

## Was ich NICHT testen konnte (bitte beim ersten Start prüfen)
Ich habe in einer Linux-Testumgebung entwickelt. Dort getestet und ok: Oberfläche, Größenberechnung, Klicklogik
(X schließt ohne Strafe, Fehlklick spawnt), Stopp, Text-Effekte, Speichern/Laden, Erkennung + Overlay-Zeichnen
(mit harmlosem Testfoto). **Nur unter Windows prüfbar und deshalb ungetestet:**
1. Eigene Taskleisten-Einträge (siehe Logbuch im Dashboard: „gesetzt“ oder „nicht möglich“). Falls Windows
   trotzdem gruppiert: Einstellungen → Personalisierung → Taskleiste → „Schaltflächen kombinieren“ = „Nie“.
2. Hotkeys Strg+Alt+F12 / F11 / F10.
3. Video- und Audio-Wiedergabe (Codecs: am besten H.264/AAC-MP4).
4. dxcam-Aufnahme, DirectML-GPU, Ausschluss des Overlays aus der Aufnahme (Windows 10 ab 2004 / Windows 11).
   Wenn das fehlschlägt, steht eine Warnung in der Statusanzeige.

**Erster Test:** Mit wenigen Popups und `max. gleichzeitig = 4` starten, Not-Aus einmal bewusst ausprobieren, erst dann hochdrehen.

## Lizenz-Hinweis
Das Erkennungsmodell stammt aus dem Projekt NudeNet (github.com/notAI-tech/NudeNet, AGPL-3.0, auf Ultralytics YOLOv8
basierend) und wird beim Einrichten von dort über pip geladen, nicht in diesem ZIP mitgeliefert. Für privaten Gebrauch
unproblematisch; bei Weitergabe oder Veröffentlichung des Spiels bitte die Lizenz beachten.
