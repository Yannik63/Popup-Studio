@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Erste Einrichtung: lokale Python-Umgebung wird erstellt ...
  py -3 -m venv .venv
  if errorlevel 1 (
    echo Python 3 wurde nicht gefunden. Bitte installieren: https://www.python.org/downloads/
    echo Version 3.11 oder 3.12 empfohlen, Haken bei Add python.exe to PATH
    pause
    exit /b 1
  )
)
if not exist ".venv\deps_v41.ok" (
  echo Installiere Pakete - das dauert beim ersten Mal ein paar Minuten ...
  ".venv\Scripts\python.exe" --version
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Installation der Grundpakete fehlgeschlagen.
    pause
    exit /b 1
  )
  echo.
  echo Zensur-Modul: erst GPU-Version, sonst CPU-Version
  ".venv\Scripts\python.exe" -m pip uninstall -y onnxruntime onnxruntime-directml
  ".venv\Scripts\python.exe" -m pip install onnxruntime-directml
  if errorlevel 1 ".venv\Scripts\python.exe" -m pip install onnxruntime
  echo.
  echo NudeNet nur wegen der Modelldatei, ohne Abhaengigkeiten
  ".venv\Scripts\python.exe" -m pip install --no-deps "nudenet==3.4.2"
  echo.
  echo Schnelle Bildschirmaufnahme, optional
  ".venv\Scripts\python.exe" -m pip install comtypes
  ".venv\Scripts\python.exe" -m pip install --no-deps dxcam
  echo.
  ".venv\Scripts\python.exe" -c "import importlib.util as u, sys, onnxruntime, cv2, numpy; sys.exit(0 if u.find_spec('nudenet') else 1)"
  if errorlevel 1 (
    echo.
    echo ACHTUNG: Das Zensur-Modul konnte nicht vollstaendig installiert werden.
    echo Die Popups funktionieren trotzdem. Im Programm unter Live-Zensur den Knopf Diagnose druecken
    echo und mir die Ausgabe schicken. Beim naechsten Start wird die Installation erneut versucht.
    pause
  ) else (
    echo ok> ".venv\deps_v41.ok"
  )
)
start "" ".venv\Scripts\pythonw.exe" popup_studio.py
endlocal
