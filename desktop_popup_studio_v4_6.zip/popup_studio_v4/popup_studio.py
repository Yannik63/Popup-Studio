"""Desktop Popup Studio v4 – Popup-Baukasten für dein Horror-OS-Projekt.

Start:      START_POPUP_STUDIO.bat (Doppelklick)
Not-Aus:    Strg+Alt+F12  |  rote Leiste am unteren Bildschirmrand  |  Tray-Symbol
"""
import sys
import os
import json
import math
import random
import time
import uuid
import getpass
import platform
import re
import subprocess
from pathlib import Path

# Sonder-Modi (Zensur-Prozess / Benchmark) laufen ohne die ganze Oberfläche
if "--censor" in sys.argv or "--benchmark" in sys.argv or "--diagnose" in sys.argv or "--guard" in sys.argv:
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    if "--guard" in sys.argv:
        import guardian
        _i = sys.argv.index("--guard")
        sys.exit(guardian.run_guard(int(sys.argv[_i + 1]), sys.argv[_i + 2]))
    import censor_engine
    for _flag in ("--benchmark", "--diagnose"):
        if _flag in sys.argv:
            _i = sys.argv.index(_flag)
            if _i + 1 < len(sys.argv):                    # Ausgabedatei (für pythonw / EXE ohne Konsole)
                sys.stdout = sys.stderr = open(sys.argv[_i + 1], "w", encoding="utf-8", buffering=1)
            try:
                (censor_engine.run_benchmark if _flag == "--benchmark" else censor_engine.run_diagnose)()
            except Exception as _e:
                print("FEHLER:", type(_e).__name__, _e)
            if sys.stdin is not None and sys.stdin.isatty():
                input("\nFertig. Enter zum Schließen ...")
            sys.exit(0)
    i = sys.argv.index("--censor")
    cfg = sys.argv[i + 1]
    status = str(Path(cfg).with_name("censor_status.json"))
    sys.exit(censor_engine.run_censor(cfg, status))

from PySide6.QtCore import (Qt, QTimer, QUrl, QSize, QObject, Signal, QProcess, QPointF, QRectF, QRect)
from PySide6.QtGui import (QPixmap, QGuiApplication, QFont, QColor, QImage, QImageReader, QMovie,
                           QPainter, QLinearGradient, QPen, QIcon, QBrush, QAction)
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFileDialog, QListWidget, QListWidgetItem, QPushButton,
    QLabel, QVBoxLayout, QHBoxLayout, QFormLayout, QGridLayout, QSpinBox, QSlider, QCheckBox,
    QComboBox, QAbstractItemView, QLineEdit, QTextEdit, QFontComboBox, QColorDialog, QStackedWidget,
    QGroupBox, QScrollArea, QFrame, QSystemTrayIcon, QMenu, QMessageBox, QPlainTextEdit, QInputDialog,
    QGraphicsDropShadowEffect
)
from shiboken6 import isValid
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget

import winutil
import guardian

APP_NAME = "Desktop Popup Studio"
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp"}
VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm"}
AUDIO_EXTS = {".mp3", ".wav", ".ogg", ".m4a", ".flac"}
MEDIA_EXTS = IMAGE_EXTS | VIDEO_EXTS | AUDIO_EXTS
MEDIA_FILTER = ("Medien (" + " ".join("*" + e for e in sorted(MEDIA_EXTS)) + ");;Alle Dateien (*.*)")

DATA_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "PopupStudio"
DATA_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = DATA_DIR / "settings.json"
CENSOR_FILE = DATA_DIR / "censor_config.json"
CENSOR_STATUS = DATA_DIR / "censor_status.json"
PROFILES_DIR = DATA_DIR / "profiles"
PROFILES_DIR.mkdir(parents=True, exist_ok=True)

HARD_POPUP_LIMIT = 40       # absolute Obergrenze gleichzeitiger Fenster (Sicherheitsnetz)
CAP_CHOICES = {"1/2 des Bildschirms": 0.5, "1/4 des Bildschirms": 0.25, "1/9 des Bildschirms": 1 / 9,
               "1/16 des Bildschirms": 1 / 16, "1/25 des Bildschirms": 1 / 25, "1/36 des Bildschirms": 1 / 36}
SIZE_MODES = ["Original (bis zur Obergrenze)", "Immer auf Obergrenze skalieren",
              "Zufällig zwischen Min und Max", "Feste Breite in Pixel"]

TITLES = ["Werbung", "Sicherheitswarnung", "Systemmeldung", "Update erforderlich", "Gewinnbenachrichtigung",
          "Empfohlen für dich", "Wichtige Nachricht", "Fehler 0x80070005"]

DEFAULTS = {
    # Module (einzeln schaltbar) + Gewichtung im Zufall
    "mod_image": True, "mod_video": True, "mod_audio": True, "mod_text": True,
    "w_image": 5, "w_video": 3, "w_audio": 3, "w_text": 4,
    # Verhalten
    "interval": 4, "spawn_mode": "Gleichmäßig", "max_popups": 8, "burst": 1, "vid_max": 3, "mem_brake_mb": 1500, "mm_backend": "Automatisch",
    "guard_on": True, "guard_corner": "oben links", "guard_hang_s": 10, "guard_mem_mb": 3000,
    "life_min": 10, "life_max": 25, "escalation": 4,
    "auto_stop_min": 0,
    # Größe & Position
    "size_mode": SIZE_MODES[0], "size_cap": "1/4 des Bildschirms", "size_min_cap": "1/36 des Bildschirms",
    "size_px": 420, "upscale_small": False, "all_monitors": False, "offscreen_ok": False,
    # Interaktion
    "penalty_on": True, "penalty_min": 2, "penalty_max": 3, "penalty_chance": 100,
    "penalty_ignore_max": False, "penalty_button": True, "penalty_delay": 120,
    "x_size": 22, "x_color": "#c42b1c", "fake_titlebar": True, "steal_focus": False,
    "always_on_top": True, "separate_taskbar": True, "panic_bar": True,
    # Vielfalt (nur Bild/Video): Anzeigen-Stile
    "var_on": False, "var_pct": 50, "var_banner": True, "var_sky": True, "var_card": True, "var_frameless": True,
    # Fiese Schließknöpfe (nur Bild/Video)
    "tc_on": False, "tc_pct": 40, "tc_tiny": True, "tc_fake": True, "tc_flaky": True, "tc_delay": True,
    "tc_far": True, "tc_flaky_pct": 50, "tc_glyph": 11, "tc_hit": 7, "tc_delay_s": 4,
    # Bild
    "img_effect": "Keiner", "img_opacity": 100, "img_flip": False, "img_shake": False,
    "img_censor": False, "ic_mode": "Eigene Einstellungen", "ic_effect": "Verpixeln", "ic_shift": 0,
    # Video
    "vid_volume": 60, "vid_speed": 100, "vid_loop": True, "vid_random_start": True, "vid_muted": False,
    # Audio
    "aud_vol_min": 40, "aud_vol_max": 80, "aud_speed": 100, "aud_loop": False, "aud_max": 4,
    "aud_window": False,
    # Text – Inhalt wird als Vorlagenliste gespeichert (templates)
    "t_font": "Segoe UI", "t_size": 18, "t_bold": True, "t_italic": False, "t_underline": False,
    "t_strike": False, "t_spacing": 0, "t_align": "Mitte",
    "t_fg": "#ffffff", "t_bg": "#1b1b24", "t_bg2": "#3a0a14", "t_gradient": True,
    "t_accent": "#ff2e63", "t_border": "#ff2e63", "t_border_w": 2, "t_radius": 0,
    "t_w": 440, "t_h": 260, "t_auto_h": True, "t_button": True, "t_button_text": "KLICK HIER",
    "fx_neon": False, "fx_glitch": False, "fx_blink": False, "fx_shake": False, "fx_type": False,
    "fx_rainbow": False, "fx_pulse": False, "fx_scan": False,
}

DEFAULT_TEMPLATES = [
    {"title": "Sicherheitswarnung", "headline": "⚠ VIRUS GEFUNDEN",
     "body": "{user}, dein PC ist infiziert!\nSofort handeln: {time}", "button": "JETZT ENTFERNEN"},
    {"title": "Gewinnbenachrichtigung", "headline": "GLÜCKWUNSCH!",
     "body": "Du bist der 1.000.000. Besucher!\nHol dir deinen Preis ab.", "button": "PREIS ABHOLEN"},
    {"title": "Systemmeldung", "headline": "Fehler 0x80070005",
     "body": "Zugriff verweigert auf {pc}.\nEtwas ist in deinem System.", "button": "OK"},
]

TEXT_PRESETS = {
    "Windows-Fehler": {"t_font": "Segoe UI", "t_fg": "#000000", "t_bg": "#f0f0f0", "t_bg2": "#d8d8d8",
                       "t_gradient": False, "t_accent": "#e1e1e1", "t_border": "#0a246a", "t_border_w": 2,
                       "t_bold": False, "fx_neon": False, "fx_glitch": False, "fx_blink": False,
                       "fx_scan": False, "t_radius": 0},
    "Virus-Alarm": {"t_font": "Arial Black", "t_fg": "#ffffff", "t_bg": "#8b0000", "t_bg2": "#ff0000",
                    "t_gradient": True, "t_accent": "#ffd400", "t_border": "#ffd400", "t_border_w": 4,
                    "t_bold": True, "fx_blink": True, "fx_shake": True, "fx_neon": False, "fx_scan": False},
    "Terminal": {"t_font": "Consolas", "t_fg": "#00ff66", "t_bg": "#020a04", "t_bg2": "#020a04",
                 "t_gradient": False, "t_accent": "#00ff66", "t_border": "#00ff66", "t_border_w": 1,
                 "t_bold": False, "fx_type": True, "fx_scan": True, "fx_neon": True, "fx_blink": False},
    "Gewinnspiel-Scam": {"t_font": "Comic Sans MS", "t_fg": "#ffffff", "t_bg": "#ff00aa", "t_bg2": "#ffcc00",
                         "t_gradient": True, "t_accent": "#00c853", "t_border": "#ffffff", "t_border_w": 5,
                         "t_bold": True, "fx_rainbow": True, "fx_pulse": True, "fx_blink": False},
    "Dunkler Horror": {"t_font": "Georgia", "t_fg": "#d9d9d9", "t_bg": "#050505", "t_bg2": "#1a0000",
                       "t_gradient": True, "t_accent": "#5a0000", "t_border": "#5a0000", "t_border_w": 2,
                       "t_italic": True, "fx_glitch": True, "fx_neon": False, "fx_scan": True},
}

BEHAVIOR_PRESETS = {
    "Leicht nervig": {"interval": 7, "max_popups": 4, "burst": 1, "spawn_mode": "Gleichmäßig",
                      "penalty_min": 1, "penalty_max": 2, "life_min": 12, "life_max": 25,
                      "var_on": False, "tc_on": False},
    "Adware": {"interval": 3, "max_popups": 10, "burst": 1, "spawn_mode": "Eskalierend",
               "penalty_min": 2, "penalty_max": 3, "life_min": 10, "life_max": 30,
               "var_on": True, "var_pct": 45, "tc_on": True, "tc_pct": 25, "tc_flaky_pct": 40},
    "Kompletter Albtraum": {"interval": 1, "max_popups": 25, "burst": 2, "spawn_mode": "Chaotisch",
                            "penalty_min": 3, "penalty_max": 4, "life_min": 15, "life_max": 0,
                            "var_on": True, "var_pct": 80, "tc_on": True, "tc_pct": 60, "tc_flaky_pct": 55},
}


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------
def fill_placeholders(text):
    try:
        user = getpass.getuser()
    except Exception:
        user = "Benutzer"
    now = time.localtime()
    return (text.replace("{user}", user).replace("{pc}", platform.node() or "PC")
            .replace("{time}", time.strftime("%H:%M:%S", now)).replace("{date}", time.strftime("%d.%m.%Y", now)))


def pick_screen(S):
    screens = QGuiApplication.screens()
    return random.choice(screens) if (S["all_monitors"] and len(screens) > 1) else QGuiApplication.primaryScreen()


def fit_scale(S, screen_geo, w, h, kind="media"):
    """Skalierungsfaktor, damit Inhalt (w x h) in die gewünschte Bildschirm-Obergrenze passt."""
    sw, sh = screen_geo.width(), screen_geo.height()
    cap = CAP_CHOICES.get(S["size_cap"], 0.11)
    mode = S["size_mode"]
    w, h = max(1, w), max(1, h)

    def box(frac):
        lin = math.sqrt(frac)           # Anteil der FLÄCHE -> Anteil pro Seite
        return sw * lin, sh * lin

    if mode == SIZE_MODES[0]:           # Original, nur verkleinern
        bw, bh = box(cap)
        return min(1.0, bw / w, bh / h)
    if mode == SIZE_MODES[1]:           # immer auf Obergrenze
        bw, bh = box(cap)
        return min(bw / w, bh / h)
    if mode == SIZE_MODES[2]:           # zufällig zwischen Min und Max
        lo = CAP_CHOICES.get(S["size_min_cap"], 1 / 36)
        hi = cap
        if lo > hi:
            lo, hi = hi, lo
        bw, bh = box(random.uniform(lo, hi))
        return min(bw / w, bh / h)
    bw, bh = box(cap)                   # feste Breite, aber nie über der Obergrenze
    return min(S["size_px"] / w, bw / w, bh / h)


def apply_image_effect(img: QImage, effect: str) -> QImage:
    if effect == "Graustufen":
        return img.convertToFormat(QImage.Format_Grayscale8).convertToFormat(QImage.Format_ARGB32)
    img = img.convertToFormat(QImage.Format_ARGB32)
    if effect == "Invertiert":
        img.invertPixels(QImage.InvertRgb)
    elif effect in ("Sepia", "Rot-Stich"):
        gray = img.convertToFormat(QImage.Format_Grayscale8).convertToFormat(QImage.Format_ARGB32)
        p = QPainter(gray)
        p.setCompositionMode(QPainter.CompositionMode_Multiply)
        p.fillRect(gray.rect(), QColor("#d9a066") if effect == "Sepia" else QColor("#ff4040"))
        p.end()
        img = gray
    elif effect in ("Verpixelt", "Unscharf"):
        w, h = img.width(), img.height()
        f = 14 if effect == "Verpixelt" else 8
        small = img.scaled(max(1, w // f), max(1, h // f), Qt.IgnoreAspectRatio,
                           Qt.FastTransformation if effect == "Verpixelt" else Qt.SmoothTransformation)
        img = small.scaled(w, h, Qt.IgnoreAspectRatio,
                           Qt.FastTransformation if effect == "Verpixelt" else Qt.SmoothTransformation)
    return img


class ColorButton(QPushButton):
    changed = Signal()

    def __init__(self, color="#ffffff"):
        super().__init__()
        self._c = color
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(28)
        self.clicked.connect(self._pick)
        self._paint()

    def color(self):
        return self._c

    def setColor(self, c):
        self._c = c
        self._paint()

    def _pick(self):
        col = QColorDialog.getColor(QColor(self._c), self, "Farbe wählen")
        if col.isValid():
            self.setColor(col.name())
            self.changed.emit()

    def _paint(self):
        fg = "#000" if QColor(self._c).lightness() > 140 else "#fff"
        self.setText(self._c.upper())
        self.setStyleSheet(f"QPushButton{{background:{self._c};color:{fg};border:1px solid #444;"
                           f"border-radius:6px;padding:2px 10px;font-weight:600}}")


# ---------------------------------------------------------------------------
# Hilfen für Anzeigen-Stile und fiese Schließknöpfe
# ---------------------------------------------------------------------------
AD_TAGS = ["Anzeige", "ANZEIGE", "Anzeige", "Sponsored", "Gesponsert"]
COVER_STYLES = ("banner", "sky", "card")          # Medium füllt seine Fläche vollständig (zugeschnitten)


def cap_box(S, scr):
    """Breite/Höhe der Obergrenze (Anteil der Bildschirmfläche -> Anteil je Seite)."""
    lin = math.sqrt(CAP_CHOICES.get(S["size_cap"], 0.25))
    return scr.width() * lin, scr.height() * lin


def pick_copy(templates):
    """Anzeigentext aus den (aktiven) Text-Vorlagen: Überschrift, Unterzeile, Button, Absender."""
    tpls = [t for t in templates if t.get("on", True)] or DEFAULT_TEMPLATES
    t = random.choice(tpls)
    body = " ".join(fill_placeholders(t.get("body", "")).split())
    return {"headline": fill_placeholders(t.get("headline") or t.get("title") or "Jetzt ansehen"),
            "sub": body, "button": fill_placeholders(t.get("button") or "Mehr erfahren"),
            "source": fill_placeholders(t.get("title") or "Anzeige"), "tag": random.choice(AD_TAGS)}


def choose_style(S):
    if not S["var_on"] or random.randint(1, 100) > S["var_pct"]:
        return "classic"
    opts = [k for k, key in (("banner", "var_banner"), ("sky", "var_sky"), ("card", "var_card"),
                             ("frameless", "var_frameless")) if S[key]]
    return random.choice(opts) if opts else "classic"


def choose_tricky(S):
    if not S["tc_on"] or random.randint(1, 100) > S["tc_pct"]:
        return None
    opts = [k for k, key in (("tiny", "tc_tiny"), ("fake", "tc_fake"), ("flaky", "tc_flaky"),
                             ("delayed", "tc_delay"), ("far", "tc_far")) if S[key]]
    return random.choice(opts) if opts else None


class XGlyph(QWidget):
    """Nur gezeichnetes X – reagiert NICHT auf die Maus (Klicks gehen an das Popup = Fehlklick)."""

    def __init__(self, parent, size, look="ghost", alpha=1.0):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self.look, self.alpha = look, alpha
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setOpacity(self.alpha)
        s = self.width()
        m = max(2.5, s * 0.3)
        if self.look == "circle":
            p.setBrush(QColor(255, 255, 255, 235))
            p.setPen(QPen(QColor("#222"), 1.2))
            p.drawEllipse(QRectF(0.6, 0.6, s - 1.2, s - 1.2))
            pen = QPen(QColor("#111"), max(1.2, s / 14.0))
        else:                                              # ghost: schwacher Schatten + graues, dünnes X
            p.setBrush(QColor(0, 0, 0, 70))
            p.setPen(Qt.NoPen)
            p.drawEllipse(QRectF(0.5, 0.5, s - 1, s - 1))
            pen = QPen(QColor(200, 200, 200, 210), max(1.0, s / 11.0))
        p.setPen(pen)
        p.drawLine(QPointF(m, m), QPointF(s - m, s - m))
        p.drawLine(QPointF(s - m, m), QPointF(m, s - m))
        p.end()


# ---------------------------------------------------------------------------
# Popup-Grundklasse: EIN Fenster, EIN eigenes X, eigener Taskleisten-Eintrag
# ---------------------------------------------------------------------------
class PopupBase(QWidget):
    closed = Signal(object)
    missclick = Signal(object)

    def __init__(self, S, title, number, header_h=None, media=False):
        flags = Qt.Window | Qt.FramelessWindowHint      # kein Qt.Tool -> bekommt Taskleisten-Eintrag
        if S["always_on_top"]:
            flags |= Qt.WindowStaysOnTopHint
        super().__init__(None, flags)
        self.S = S
        self.number = number
        self._shutting_down = False
        self.setWindowTitle(f"{title} #{number}")
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        if not S["steal_focus"]:
            self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        # Anzeigen-Stil und Schließknopf-Art gelten nur für Bild/Video-Popups
        self.style_name = S.get("_style", "classic") if media else "classic"
        self.close_mode = (S.get("_tricky") or "normal") if media else "normal"
        self.theme_dark = self.style_name != "classic" and random.random() < 0.2
        self.scr = pick_screen(S).availableGeometry()
        if self.style_name != "classic":
            self.header_h = 0
        else:
            self.header_h = header_h if header_h is not None else (max(24, S["x_size"] + 6) if S["fake_titlebar"] else 0)
        self.title_label = QLabel(title, self)
        self.title_label.setStyleSheet("color:#dcdcdc;background:transparent;font:600 9pt 'Segoe UI';padding-left:8px;")
        self.title_label.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.title_label.setVisible(self.header_h > 0)
        self.content = QWidget(self)
        self.chrome = None
        self.x_corner = "tr"
        self._build_close()
        self.lifetime = QTimer(self)
        self.lifetime.setSingleShot(True)
        self.lifetime.timeout.connect(self.close_clean)
        self.shake_timer = None
        self._home = None
        self.appid_ok = None

    # ------------------------------------------------------------------ Schließen
    def _x_css(self, size, look):
        S = self.S
        if look == "box":
            return (f"QPushButton{{background:{S['x_color']};color:white;border:none;border-radius:3px;"
                    f"font:bold {int(size * 0.85)}px 'Segoe UI';padding:0 0 2px 0;}}QPushButton:hover{{background:#ff5a4a;}}")
        return (f"QPushButton{{background:white;color:#111;border:1.5px solid #222;border-radius:{size // 2}px;"
                f"font:bold {int(size * 0.8)}px 'Segoe UI';padding:0 0 2px 0;}}QPushButton:hover{{background:#eee;}}")

    def _build_close(self):
        S, mode = self.S, self.close_mode
        xs = S["x_size"]
        look = "box" if self.style_name == "classic" else "circle"
        self.look = look
        self.xglyph = self.xfake = self.xcount = self.cd_timer = None
        self.delay_left = 0
        self.hit_off = (0, 0)
        self.far_corner = random.choice(["tl", "bl", "br"])
        self.xbtn = QPushButton("×", self)                 # DAS echte Schließ-Ziel
        self.xbtn.setFocusPolicy(Qt.NoFocus)
        self.xbtn.setCursor(Qt.ArrowCursor)
        if mode in ("normal", "flaky", "delayed"):
            size = xs if mode == "normal" else max(14, int(xs * 0.8))
            self.xbtn.setFixedSize(size, size)
            self.xbtn.setStyleSheet(self._x_css(size, look))
            if mode == "delayed":
                self.delay_left = max(1, int(S["tc_delay_s"]))
                self.xbtn.setStyleSheet("QPushButton{background:#999;color:#ddd;border:none;border-radius:%dpx;}" % (size // 2))
                self.xcount = QLabel(str(self.delay_left), self)
                self.xcount.setStyleSheet("color:#fff;background:rgba(0,0,0,150);font:bold 8pt 'Segoe UI';"
                                          "border-radius:3px;padding:0 3px;")
                self.xcount.setAttribute(Qt.WA_TransparentForMouseEvents, True)
                self.xcount.adjustSize()
                self.cd_timer = QTimer(self)
                self.cd_timer.timeout.connect(self._tick_delay)
        else:                                              # tiny / far / fake: sichtbares Glyph != Trefferfläche
            g = max(8, int(S["tc_glyph"]))
            h = max(4, min(int(S["tc_hit"]), g))
            self.xglyph = XGlyph(self, g, "ghost", 0.9)
            self.xbtn.setText("")
            self.xbtn.setFixedSize(h, h)
            self.xbtn.setFlat(True)
            self.xbtn.setStyleSheet("QPushButton{background:transparent;border:none;}")
            spread = max(0, (g - h) // 2) + 1              # Trefferfläche sitzt leicht versetzt hinter dem Glyph
            self.hit_off = (random.randint(-spread, spread), random.randint(-spread, spread))
            if mode == "fake":                             # großes, gut sichtbares X, das NICHT schließt
                self.xfake = QPushButton("×", self)
                self.xfake.setFocusPolicy(Qt.NoFocus)
                self.xfake.setFixedSize(xs, xs)
                self.xfake.setStyleSheet(self._x_css(xs, look))
                self.xfake.clicked.connect(lambda: self.missclick.emit(self))
        self.xbtn.clicked.connect(self._x_clicked)

    def _x_clicked(self):
        S, mode = self.S, self.close_mode
        if mode == "flaky" and random.randint(1, 100) <= S["tc_flaky_pct"]:
            self.missclick.emit(self)                      # "geschlossen" – aber nichts passiert, dafür kommt mehr
            return
        if mode == "delayed" and self.delay_left > 0:
            self.missclick.emit(self)
            return
        self.close_clean()

    def _tick_delay(self):
        self.delay_left -= 1
        if self.delay_left > 0:
            self.xcount.setText(str(self.delay_left))
            self.xcount.adjustSize()
            return
        self.cd_timer.stop()
        self.xcount.hide()
        self.xbtn.setStyleSheet(self._x_css(self.xbtn.width(), self.look))

    def _corner_xy(self, corner, w, h, size, inset=4):
        x = inset if corner in ("tl", "bl") else w - size - inset
        y = inset if corner in ("tl", "tr") else h - size - inset
        return x, y

    def _place_close(self):
        w, h, H = self.width(), self.height(), self.header_h
        mode = self.close_mode
        if self.xglyph is None:                            # sichtbares X = Trefferfläche
            size = self.xbtn.width()
            if self.style_name == "classic":
                x, y = w - size - 4, ((H - size) // 2 if H else 4)
            else:
                x, y = self._corner_xy(self.x_corner, w, h, size, 5)
            self.xbtn.move(max(0, x), max(0, y))
            if self.xcount is not None:
                if self.style_name != "classic" and self.x_corner == "tl":
                    self.xcount.move(self.xbtn.x() + self.xbtn.width() + 3, self.xbtn.y() + 1)
                else:
                    self.xcount.move(max(0, self.xbtn.x() - self.xcount.width() - 3), self.xbtn.y() + 1)
                self.xcount.raise_()
            self.xbtn.raise_()
            return
        g, hit = self.xglyph.width(), self.xbtn.width()
        corner = "tr" if mode == "tiny" else self.far_corner
        gx, gy = self._corner_xy(corner, w, h, g, 3)
        self.xglyph.move(gx, gy)
        hx = min(max(0, gx + (g - hit) // 2 + self.hit_off[0]), w - hit)
        hy = min(max(0, gy + (g - hit) // 2 + self.hit_off[1]), h - hit)
        self.xbtn.move(hx, hy)
        if self.xfake is not None:
            fx, fy = (w - self.xfake.width() - 4, ((H - self.xfake.height()) // 2 if H else 4)) \
                if self.style_name == "classic" else self._corner_xy("tr", w, h, self.xfake.width(), 5)
            self.xfake.move(max(0, fx), max(0, fy))
            self.xfake.raise_()
        self.xglyph.raise_()
        self.xbtn.raise_()

    # ------------------------------------------------------------------ Zeichnen / Layout
    def paintEvent(self, e):
        p = QPainter(self)
        if self.style_name == "classic":
            p.fillRect(self.rect(), QColor("#101015"))
            if self.header_h:
                p.fillRect(0, 0, self.width(), self.header_h, QColor("#23232e"))
            p.setPen(QColor("#3a3a48"))
        else:
            p.fillRect(self.rect(), QColor("#1c1c20" if self.theme_dark else "#ffffff"))
            p.setPen(QColor("#555" if self.theme_dark else "#8a8a8a"))
        p.drawRect(0, 0, self.width() - 1, self.height() - 1)
        p.end()

    def set_content_size(self, cw, ch):
        self.setFixedSize(cw, ch + self.header_h)
        self._relayout()

    def _relayout(self):
        w, h, H = self.width(), self.height(), self.header_h
        if self.style_name == "classic":
            self.title_label.setGeometry(0, 0, max(0, w - self.S["x_size"] - 8), H)
            self.content.setGeometry(0, H, w, max(0, h - H))
        self._place_close()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._relayout()

    # ------------------------------------------------------------------ Anzeigen-Stile (nur Bild/Video)
    def plan_media(self, nw, nh, is_video=False):
        """Zielgröße des Mediums je nach Stil. Banner/Skyscraper/Karte füllen ihre Fläche (zugeschnitten)."""
        S, st = self.S, self.style_name
        cw_, ch_ = cap_box(S, self.scr)
        nw, nh = max(1, nw), max(1, nh)
        if st == "banner":
            bh = int(min(140, max(84, ch_ * 0.2)))
            return int(min(max(bh * nw / nh, bh * 0.9), bh * 2.0)), bh
        if st == "sky":
            W = int(min(300, max(200, cw_ * 0.5)))
            return W, int(min(W * nh / nw, max(120, ch_ - 140)))
        if st == "card":
            W = int(min(340, max(220, cw_ * 0.7)))
            return W, int(min(W * nh / nw, max(110, ch_ - 110)))
        sc = fit_scale(S, self.scr, nw, nh)
        if S["size_mode"] == SIZE_MODES[0] and (is_video or not S["upscale_small"]):
            sc = min(sc, 1.0)
        return max(80, int(nw * sc)), max(60, int(nh * sc))

    def _ensure_chrome(self):
        if self.chrome is not None:
            return
        S = self.S

        def lab(parent=self):
            lb = QLabel(parent)
            lb.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            lb.setWordWrap(True)
            return lb
        c = {"tag": lab(), "head": lab(), "sub": lab(), "src": lab()}
        c["cta"] = QPushButton(self)
        c["cta"].setFocusPolicy(Qt.NoFocus)
        c["cta"].setCursor(Qt.PointingHandCursor)
        c["cta"].setStyleSheet("QPushButton{background:#f5a623;color:#111;border:none;border-radius:18px;"
                               "font:bold 10pt 'Segoe UI';}QPushButton:hover{background:#ffb94a;}")
        c["cta"].clicked.connect(lambda: self.missclick.emit(self) if S["penalty_button"] else None)
        self.chrome = c

    def layout_chrome(self, mw, mh):
        st = self.style_name
        if st == "classic":
            self.set_content_size(mw, mh)
            return
        self._ensure_chrome()
        c, copy = self.chrome, self.S.get("_copy") or pick_copy([])
        fg, sub = ("#f2f2f2", "#b0b0b0") if self.theme_dark else ("#111111", "#666666")
        cw_, _ = cap_box(self.S, self.scr)
        for k in ("head", "sub", "src", "tag", "cta"):
            c[k].hide()

        def put(lbl, text, x, y, w, font, color, max_lines, align=Qt.AlignLeft):
            lbl.setText(text)
            lbl.setFont(font)
            lbl.setAlignment(align | Qt.AlignTop)
            lbl.setStyleSheet(f"color:{color};background:transparent;")
            fm = lbl.fontMetrics()
            hh = min(fm.boundingRect(0, 0, w, 4000, Qt.TextWordWrap, text).height(), fm.lineSpacing() * max_lines)
            lbl.setGeometry(x, y, w, hh)
            lbl.show()
            return y + hh

        def tag_overlay(x, y):
            t = c["tag"]
            t.setText(copy["tag"])
            t.setFont(QFont("Segoe UI", 8))
            t.setStyleSheet("color:#222;background:rgba(255,255,255,225);padding:1px 5px;")
            t.setWordWrap(False)
            t.adjustSize()
            t.move(x, y)
            t.show()
        head_f, sub_f = QFont("Segoe UI", 12), QFont("Segoe UI", 9)
        head_f.setBold(True)
        if st == "frameless":
            W, H = mw, mh
            self.content.setGeometry(0, 0, mw, mh)
            tag_overlay(W - 60, 4)
            c["tag"].move(W - c["tag"].width() - 4, H - c["tag"].height() - 4)
        elif st == "banner":
            text_w = max(230, int(cw_) - mw)
            W, H = mw + text_w, mh
            self.content.setGeometry(0, 0, mw, mh)
            tag_overlay(4, 4)
            y = put(c["head"], copy["headline"], mw + 12, 10, text_w - 12 - 36, head_f, fg, 2)
            put(c["sub"], copy["sub"], mw + 12, y + 4, text_w - 12 - 12, sub_f, sub, 2)
        elif st == "sky":
            W = mw
            self.content.setGeometry(0, 22, mw, mh)
            put(c["tag"], copy["tag"], 8, 4, W - 40, QFont("Segoe UI", 8), fg, 1)
            c["tag"].setStyleSheet(f"color:{fg};background:transparent;")
            y = put(c["head"], copy["headline"], 10, 22 + mh + 10, W - 20, head_f, fg, 3, Qt.AlignHCenter)
            bw = int(W * 0.84)
            c["cta"].setText(copy["button"])
            c["cta"].setGeometry((W - bw) // 2, y + 12, bw, 36)
            c["cta"].show()
            H = y + 12 + 36 + 16
        else:                                              # card
            W = mw
            self.x_corner = "tl"
            self.content.setGeometry(0, 0, mw, mh)
            tag_overlay(0, 0)
            c["tag"].setText(copy["tag"].upper())
            c["tag"].adjustSize()
            c["tag"].move(W - c["tag"].width(), 0)
            y = put(c["head"], copy["headline"], 10, mh + 8, W - 20, head_f, fg, 3)
            y = put(c["src"], f"{copy['tag'].upper()} · {copy['source']}", 10, y + 4, W - 20, QFont("Segoe UI", 8), sub, 1)
            H = y + 12
        self.setFixedSize(W, H)
        self._relayout()
        c["tag"].raise_()
        self._place_close()

    def apply_media(self, nw, nh, is_video=False):
        mw, mh = self.plan_media(nw, nh, is_video)
        self.layout_chrome(mw, mh)
        return mw, mh

    # ------------------------------------------------------------------ Verhalten
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.missclick.emit(self)
        e.accept()

    def close_clean(self):
        self._shutting_down = True
        self.close()

    def _avoid_guard(self, x, y):
        """Hält Popups bei der Platzierung vom Not-Aus-Knopf (Wächter) fern."""
        corner = self.S.get("_guard")
        if not corner:
            return x, y
        g = QGuiApplication.primaryScreen().geometry()
        m = 8
        gx = g.left() if corner in ("tl", "bl") else g.right() - guardian.GUARD_W + 1
        gy = g.top() if corner in ("tl", "tr") else g.bottom() - guardian.GUARD_H + 1
        guard = QRect(gx - m, gy - m, guardian.GUARD_W + 2 * m, guardian.GUARD_H + 2 * m)
        w, h = self.width(), self.height()
        if not QRect(x, y, w, h).intersects(guard):
            return x, y
        if self.style_name == "banner" and corner in ("bl", "br"):         # Banner kleben unten: seitlich ausweichen
            x = guard.right() + 1 if corner == "bl" else guard.left() - w
        else:
            y = guard.bottom() + 1 if corner in ("tl", "tr") else guard.top() - h
        if not self.S["offscreen_ok"]:
            x, y = max(g.left(), min(x, g.right() - w + 1)), max(g.top(), min(y, g.bottom() - h + 1))
        return x, y

    def place_randomly(self):
        scr = self.scr if not self.S["all_monitors"] else pick_screen(self.S).availableGeometry()
        w, h = self.width(), self.height()
        st = self.style_name
        if st == "banner":                                  # klebt am unteren Bildschirmrand
            x, y = random.randint(scr.left(), max(scr.left(), scr.right() - w)), scr.bottom() - h + 1
        elif st == "sky":                                   # seitliche Anzeigenspalte
            x = scr.left() + 6 if random.random() < 0.5 else scr.right() - w - 6
            y = random.randint(scr.top(), max(scr.top(), scr.bottom() - h))
        else:
            if self.S["offscreen_ok"]:
                xr = (scr.left() - int(w * 0.3), scr.right() - int(w * 0.7))
                yr = (scr.top() - int(h * 0.3), scr.bottom() - int(h * 0.7))
            else:
                xr = (scr.left(), max(scr.left(), scr.right() - w))
                yr = (scr.top(), max(scr.top(), scr.bottom() - h))
            x, y = random.randint(*xr), random.randint(*yr)
        self.move(*self._avoid_guard(x, y))

    def start(self):
        self.place_randomly()
        hwnd = int(self.winId())             # erzeugt das native Fenster, ohne es schon anzuzeigen
        if self.S["separate_taskbar"]:
            # WICHTIG: die ID muss gesetzt sein, BEVOR Windows den Taskleisten-Button anlegt
            self.appid_ok = winutil.set_window_appid(hwnd, f"PopupStudio.Popup.{uuid.uuid4().hex[:12]}")
        self.show()
        if self.S["always_on_top"]:
            winutil.bring_topmost(hwnd)
        if self.cd_timer is not None:
            self.cd_timer.start(1000)
        lo, hi = self.S["life_min"], self.S["life_max"]
        if hi > 0:
            lo = min(lo, hi)
            self.lifetime.start(int(random.uniform(max(1, lo), max(1, hi)) * 1000))
        if self.S.get("shake_window"):
            self._home = self.pos()
            self.shake_timer = QTimer(self)
            self.shake_timer.timeout.connect(self._shake)
            self.shake_timer.start(45)

    def _shake(self):
        if self._home is not None and self.isVisible():
            self.move(self._home.x() + random.randint(-4, 4), self._home.y() + random.randint(-3, 3))

    def cleanup(self):
        pass

    def closeEvent(self, e):
        self.lifetime.stop()
        if self.cd_timer is not None:
            self.cd_timer.stop()
        if self.shake_timer:
            self.shake_timer.stop()
        try:
            self.cleanup()
        except Exception:
            pass                                             # Aufräumfehler dürfen das Abmelden nie verhindern
        self.closed.emit(self)
        e.accept()


def cover_pixmap(pm, mw, mh):
    pm = pm.scaled(mw, mh, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    return pm.copy(max(0, (pm.width() - mw) // 2), max(0, (pm.height() - mh) // 2), mw, mh)


# ---------------------------------------------------------------------------
# Bild-Popup (JPG/PNG/WEBP/GIF) – nahe an Originalgröße, Seitenverhältnis bleibt
# ---------------------------------------------------------------------------
class ImagePopup(PopupBase):
    def __init__(self, S, path, number, censor_fn=None):
        super().__init__(S, random.choice(TITLES), number, media=True)
        self.movie = None
        self.label = QLabel(self.content)
        self.label.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.label.setAlignment(Qt.AlignCenter)
        cover = self.style_name in COVER_STYLES
        if Path(path).suffix.lower() == ".gif":
            reader = QImageReader(path)
            size = reader.size() if reader.size().isValid() else QSize(320, 240)
            mw, mh = self.apply_media(size.width(), size.height())
            self.movie = QMovie(path)
            self.movie.setScaledSize(QSize(mw, mh))
            self.label.setMovie(self.movie)
            self.movie.start()
        else:
            reader = QImageReader(path)
            reader.setAutoTransform(True)
            img = reader.read()
            if img.isNull():
                mw, mh = self.apply_media(260, 120)
                self.label.setText("Bild konnte nicht geladen werden")
                self.label.setStyleSheet("color:#999;")
            else:
                if censor_fn is not None:
                    img = censor_fn(path, img)
                img = apply_image_effect(img, S["img_effect"])
                if S["img_flip"] and random.random() < 0.5:
                    img = img.mirrored(True, False)
                mw, mh = self.apply_media(img.width(), img.height())
                pm = QPixmap.fromImage(img)
                pm = cover_pixmap(pm, mw, mh) if cover else pm.scaled(mw, mh, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                self.label.setPixmap(pm)
        self.label.setGeometry(0, 0, mw, mh)
        self.setWindowOpacity(max(0.1, S["img_opacity"] / 100.0))
        S["shake_window"] = S["img_shake"]

    def cleanup(self):
        if self.movie:
            self.movie.stop()


# ---------------------------------------------------------------------------
# Video-Popup (MP4 & Co.)
# ---------------------------------------------------------------------------
class VideoPopup(PopupBase):
    alive = 0                                                # lebende Video-Popups (unabhängig von jeder Liste)

    def __init__(self, S, path, number):
        if VideoPopup.alive >= max(1, int(S["vid_max"])):    # HARTE Obergrenze: gilt, egal wer uns erzeugen will
            raise RuntimeError("Video-Obergrenze erreicht")
        super().__init__(S, random.choice(TITLES), number, media=True)
        self._counted = False
        self._seeked = False
        self._sized = False
        self.player = self.audio = None
        self.video = QVideoWidget(self.content)
        self.video.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        if self.style_name in COVER_STYLES:
            self.video.setAspectRatioMode(Qt.AspectRatioMode.KeepAspectRatioByExpanding)
        self._relayout_video(1280, 720)
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.audio.setVolume(0.0 if S["vid_muted"] else S["vid_volume"] / 100.0)
        self.player.setAudioOutput(self.audio)
        self.player.setVideoOutput(self.video)
        self.player.setPlaybackRate(max(0.25, S["vid_speed"] / 100.0))
        if S["vid_loop"]:
            try:
                self.player.setLoops(QMediaPlayer.Loops.Infinite)
            except Exception:
                pass
        self._sink = self.video.videoSink()
        self._sink.videoSizeChanged.connect(self._video_size)
        self.player.mediaStatusChanged.connect(self._status)
        VideoPopup.alive += 1
        self._counted = True
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()

    def _relayout_video(self, nw, nh):
        mw, mh = self.apply_media(nw, nh, is_video=True)
        self.video.setGeometry(0, 0, mw, mh)

    def _video_size(self):
        size = self._sink.videoSize()
        if self._sized or not size.isValid() or size.width() < 2:
            return
        self._sized = True
        c = self.frameGeometry().center()
        self._relayout_video(size.width(), size.height())
        if self.style_name != "banner":
            self.move(c.x() - self.width() // 2, c.y() - self.height() // 2)
        else:
            self.move(self.x(), self.scr.bottom() - self.height() + 1)

    def _status(self, status):
        # Nur EINMAL zu einer Zufallsposition springen (ein erneutes Springen bei jedem Statuswechsel kann eine Endlosschleife werden)
        if status == QMediaPlayer.MediaStatus.LoadedMedia and self.S["vid_random_start"] and not self._seeked:
            self._seeked = True
            dur = self.player.duration()
            if dur > 4000:
                self.player.setPosition(random.randint(0, int(dur * 0.7)))

    def cleanup(self):
        """Gibt Decoder, Audio und Bild sofort frei (nicht erst irgendwann)."""
        if self._counted:
            self._counted = False
            VideoPopup.alive = max(0, VideoPopup.alive - 1)
        try:
            if self.player is not None:
                self.player.stop()
                self.player.setVideoOutput(None)
                self.player.setAudioOutput(None)
                self.player.setSource(QUrl())
                self.player.deleteLater()
            if self.audio is not None:
                self.audio.deleteLater()
            self.video.deleteLater()
        except Exception:
            pass
        self.player = self.audio = None


# ---------------------------------------------------------------------------
# Audio (ohne Fenster – optional mit Mini-Fenster)
# ---------------------------------------------------------------------------
class AudioVoice(QObject):
    finished = Signal(object)

    def __init__(self, S, path):
        super().__init__()
        self.player = QMediaPlayer(self)
        self.out = QAudioOutput(self)
        lo, hi = sorted((S["aud_vol_min"], S["aud_vol_max"]))
        self.out.setVolume(random.uniform(lo, hi) / 100.0)
        self.player.setAudioOutput(self.out)
        self.player.setPlaybackRate(max(0.25, S["aud_speed"] / 100.0))
        if S["aud_loop"]:
            try:
                self.player.setLoops(QMediaPlayer.Loops.Infinite)
            except Exception:
                pass
        self.player.mediaStatusChanged.connect(
            lambda st: self.finished.emit(self) if st == QMediaPlayer.MediaStatus.EndOfMedia and not S["aud_loop"] else None)
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()

    def stop(self):
        try:
            self.player.stop()
        except Exception:
            pass


class AudioPopup(PopupBase):
    def __init__(self, S, path, number):
        super().__init__(S, "Audio-Wiedergabe", number)
        lab = QLabel("♫  " + Path(path).name, self.content)
        lab.setWordWrap(True)
        lab.setAlignment(Qt.AlignCenter)
        lab.setStyleSheet("color:#ddd;font:600 10pt 'Segoe UI';padding:8px;")
        lab.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        lab.setGeometry(0, 0, 240, 70)
        self.set_content_size(240, 70)
        self.voice = AudioVoice(S, path)

    def cleanup(self):
        self.voice.stop()


# ---------------------------------------------------------------------------
# Text-Popup mit vielen Stil- und Effekt-Optionen
# ---------------------------------------------------------------------------
class TextCanvas(QWidget):
    """Zeichnet Hintergrund (Verlauf), Rahmen, Rundung und Scanlines selbst."""

    def __init__(self, S, parent):
        super().__init__(parent)
        self.S = S
        self.glow = 0.0
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, e):
        S = self.S
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        r = self.rect().adjusted(0, 0, -1, -1)
        if S["t_gradient"]:
            g = QLinearGradient(0, 0, 0, r.height())
            g.setColorAt(0, QColor(S["t_bg"]))
            g.setColorAt(1, QColor(S["t_bg2"]))
            brush = QBrush(g)
        else:
            brush = QBrush(QColor(S["t_bg"]))
        bw = S["t_border_w"]
        border = QColor(S["t_border"])
        if S["fx_pulse"]:
            border.setAlphaF(0.45 + 0.55 * self.glow)
        p.setBrush(brush)
        p.setPen(QPen(border, bw) if bw > 0 else Qt.NoPen)
        half = bw / 2.0
        p.drawRoundedRect(r.adjusted(int(half), int(half), -int(half), -int(half)), S["t_radius"], S["t_radius"])
        if S["fx_scan"]:
            p.setPen(QPen(QColor(0, 0, 0, 55), 1))
            for y in range(0, r.height(), 3):
                p.drawLine(0, y, r.width(), y)
        p.end()


class TextPopup(PopupBase):
    ALIGN = {"Links": Qt.AlignLeft | Qt.AlignVCenter, "Mitte": Qt.AlignCenter,
             "Rechts": Qt.AlignRight | Qt.AlignVCenter}

    def __init__(self, S, tpl, number):
        title = fill_placeholders(tpl.get("title") or random.choice(TITLES))
        super().__init__(S, title, number)
        self.tpl = tpl
        self.headline = fill_placeholders(tpl.get("headline", ""))
        self.body_full = fill_placeholders(tpl.get("body", ""))
        self.tick = 0
        self.typed = 0 if S["fx_type"] else len(self.body_full)
        self.canvas = TextCanvas(S, self.content)

        w = S["t_w"]
        self.head_lbl = QLabel(self.headline, self.canvas)
        self.body_lbl = QLabel(self.body_full[:self.typed], self.canvas)
        for lb in (self.head_lbl, self.body_lbl):
            lb.setWordWrap(True)
            lb.setAlignment(self.ALIGN.get(S["t_align"], Qt.AlignCenter))
            lb.setTextFormat(Qt.PlainText)
            lb.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            lb.setStyleSheet("background:transparent;")
        font = QFont(S["t_font"], S["t_size"])
        font.setBold(S["t_bold"])
        font.setItalic(S["t_italic"])
        font.setUnderline(S["t_underline"])
        font.setStrikeOut(S["t_strike"])
        font.setLetterSpacing(QFont.AbsoluteSpacing, S["t_spacing"])
        hf = QFont(font)
        hf.setPointSize(int(S["t_size"] * 1.35))
        hf.setBold(True)
        self.head_lbl.setFont(hf)
        self.body_lbl.setFont(font)
        self._set_label_color(QColor(S["t_fg"]))

        self.button = None
        if S["t_button"]:
            self.button = QPushButton(fill_placeholders(tpl.get("button") or S["t_button_text"]), self.canvas)
            self.button.setFocusPolicy(Qt.NoFocus)
            self.button.setCursor(Qt.PointingHandCursor)
            self.button.setStyleSheet(
                f"QPushButton{{background:{S['t_accent']};color:#fff;border:1px solid {S['t_border']};"
                f"border-radius:{min(S['t_radius'], 10)}px;padding:8px 14px;font:bold 11pt '{S['t_font']}';}}"
                "QPushButton:hover{background:#ffffff33;}")
            # Aktionsbutton zählt als "Werbung angeklickt" -> optional Strafe, schließt NICHT
            self.button.clicked.connect(lambda: self.missclick.emit(self) if S["penalty_button"] else None)

        pad = 16
        cw = w
        inner_w = cw - 2 * pad
        for lb in (self.head_lbl, self.body_lbl):
            lb.setFixedWidth(inner_w)
        hh = self.head_lbl.sizeHint().height() if not self.headline else self.head_lbl.heightForWidth(inner_w)
        bh = self.body_lbl.heightForWidth(inner_w) if self.body_full else 0
        btn_h = 44 if self.button else 0
        ch = pad + hh + 8 + bh + (12 + btn_h if self.button else 0) + pad
        if not S["t_auto_h"]:
            ch = S["t_h"]
        scr = pick_screen(S).availableGeometry()
        ch = min(ch, int(scr.height() * 0.85))
        self.canvas.setGeometry(0, 0, cw, ch)
        self.head_lbl.setGeometry(pad, pad, inner_w, hh)
        self.body_lbl.setGeometry(pad, pad + hh + 8, inner_w, max(bh, 10))
        if self.button:
            self.button.setGeometry(pad, ch - pad - btn_h, inner_w, btn_h)
        self.set_content_size(cw, ch)
        S["shake_window"] = S["fx_shake"]

        if S["fx_neon"]:
            self.glow_fx = []
            for lb in (self.head_lbl, self.body_lbl):
                ef = QGraphicsDropShadowEffect(lb)
                ef.setColor(QColor(S["t_accent"]))
                ef.setOffset(0, 0)
                ef.setBlurRadius(18)
                lb.setGraphicsEffect(ef)
                self.glow_fx.append(ef)
        self.fx_timer = None
        if any(S[k] for k in ("fx_glitch", "fx_blink", "fx_type", "fx_rainbow", "fx_pulse", "fx_neon")):
            self.fx_timer = QTimer(self)
            self.fx_timer.timeout.connect(self._fx)
            self.fx_timer.start(70)

    def _set_label_color(self, col):
        for lb in (self.head_lbl, self.body_lbl):
            lb.setStyleSheet(f"background:transparent;color:{col.name()};")

    def _fx(self):
        S = self.S
        self.tick += 1
        t = self.tick
        pulse = 0.5 + 0.5 * math.sin(t / 5.0)
        self.canvas.glow = pulse
        if S["fx_neon"]:
            for ef in self.glow_fx:
                ef.setBlurRadius(10 + 22 * pulse)
        if S["fx_pulse"]:
            self.canvas.update()
        if S["fx_blink"]:
            self.head_lbl.setVisible((t // 6) % 2 == 0)
        if S["fx_type"] and self.typed < len(self.body_full):
            self.typed += 1
            self.body_lbl.setText(self.body_full[:self.typed])
        if S["fx_rainbow"]:
            self._set_label_color(QColor.fromHsv((t * 12) % 360, 230, 255))
        if S["fx_glitch"]:
            if random.random() < 0.18:
                self.head_lbl.move(self.head_lbl.x() + random.randint(-6, 6), self.head_lbl.y() + random.randint(-3, 3))
                chars = list(self.headline)
                for _ in range(random.randint(1, 3)):
                    if chars:
                        chars[random.randrange(len(chars))] = random.choice("#@%&§?!█▓░01")
                self.head_lbl.setText("".join(chars))
                self._set_label_color(random.choice([QColor(self.S["t_fg"]), QColor("#00ffff"), QColor("#ff0055")]))
            elif random.random() < 0.5:
                self.head_lbl.move(16, 16)
                self.head_lbl.setText(self.headline)
                self._set_label_color(QColor(self.S["t_fg"]))

    def cleanup(self):
        if self.fx_timer:
            self.fx_timer.stop()


# ---------------------------------------------------------------------------
# Not-Aus-Leiste: immer sichtbar und ganz oben, solange Popups laufen
# ---------------------------------------------------------------------------
class PanicBar(QWidget):
    def __init__(self, on_stop):
        super().__init__(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint |
                         Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setStyleSheet("background:#12060a;border:2px solid #ff2e63;border-radius:10px;")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 6, 10, 6)
        self.btn = QPushButton("■  POPUPS STOPPEN")
        self.btn.setCursor(Qt.PointingHandCursor)
        self.btn.setStyleSheet("QPushButton{background:#e11d48;color:white;font:bold 13pt 'Segoe UI';"
                               "border:none;border-radius:7px;padding:8px 22px;}QPushButton:hover{background:#ff3d68;}")
        self.btn.clicked.connect(on_stop)
        hint = QLabel("oder  Strg + Alt + F12")
        hint.setStyleSheet("color:#c9a0aa;border:none;font:9pt 'Segoe UI';")
        lay.addWidget(self.btn)
        lay.addWidget(hint)
        self.adjustSize()
        self.keep = QTimer(self)
        self.keep.timeout.connect(self._keep_on_top)

    def present(self):
        scr = QGuiApplication.primaryScreen().availableGeometry()
        self.move(scr.center().x() - self.width() // 2, scr.bottom() - self.height() - 8)
        self.show()
        self.keep.start(250)

    def dismiss(self):
        self.keep.stop()
        self.hide()

    def _keep_on_top(self):
        self.raise_()
        winutil.bring_topmost(int(self.winId()))


# ---------------------------------------------------------------------------
# Steuerlogik
# ---------------------------------------------------------------------------
class Engine(QObject):
    changed = Signal()
    log = Signal(str)

    def __init__(self, get_settings, get_assets, get_templates, censor_image_fn):
        super().__init__()
        self.get_settings, self.get_assets, self.get_templates = get_settings, get_assets, get_templates
        self.censor_image_fn = censor_image_fn
        self.popups, self.voices = [], []
        self.video_block_until = 0.0
        self.running = False
        self.counter = 0
        self.spawned = 0
        self.penalties = 0
        self.escal = 1.0
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self._tick)
        self.auto_stop = QTimer(self)
        self.auto_stop.setSingleShot(True)
        self.auto_stop.timeout.connect(lambda: (self.log.emit("Auto-Stopp ausgelöst."), self.stop_all()))

    # --- Auswahl
    def _choices(self, S):
        pool = []
        assets = [a for a in self.get_assets() if a[1]]
        def add(kind, w, items=None):
            if w > 0:
                pool.append((kind, w, items))
        imgs = [p for p, _ in assets if Path(p).suffix.lower() in IMAGE_EXTS]
        vids = [p for p, _ in assets if Path(p).suffix.lower() in VIDEO_EXTS]
        auds = [p for p, _ in assets if Path(p).suffix.lower() in AUDIO_EXTS]
        if S["mod_image"] and imgs:
            add("image", S["w_image"], imgs)
        if S["mod_video"] and vids:
            add("video", S["w_video"], vids)
        if S["mod_audio"] and auds:
            add("audio", S["w_audio"], auds)
        tpls = [t for t in self.get_templates() if t.get("on", True)]
        if S["mod_text"] and tpls:
            add("text", S["w_text"], tpls)
        return pool

    def limit(self, S, penalty=False):
        """Erlaubte Fensterzahl. Fehlklick-Strafen dürfen nur mit eigenem Schalter bis +10 darüber."""
        base = S["max_popups"] + (10 if (penalty and S["penalty_ignore_max"]) else 0)
        return max(1, min(base, HARD_POPUP_LIMIT))

    def _prep(self, S):
        s = dict(S)
        if S["guard_on"]:
            s["_guard"] = guardian.CORNERS.get(S["guard_corner"], "tl")
        return s

    def spawn_one(self, S=None, penalty=False):
        """Einziger Weg, ein Popup zu erzeugen – hier sitzen ALLE Obergrenzen."""
        S = S or self.get_settings()
        if len(self.popups) >= self.limit(S, penalty):
            return False
        n_vid = sum(isinstance(p, VideoPopup) for p in self.popups)
        n_aud = len(self.voices) + sum(isinstance(p, AudioPopup) for p in self.popups)
        video_ok = n_vid < S["vid_max"] and VideoPopup.alive < S["vid_max"] and time.time() >= self.video_block_until
        pool = [e for e in self._choices(S)
                if not (e[0] == "video" and not video_ok) and not (e[0] == "audio" and n_aud >= S["aud_max"])]
        if not pool:
            return False
        kind, _, items = random.choices(pool, weights=[w for _, w, _ in pool])[0]
        item = random.choice(items)
        if kind == "audio":
            if S["aud_window"]:
                return self._open(AudioPopup(self._prep(S), item, self._next()))
            v = AudioVoice(S, item)
            v.finished.connect(self._voice_done)
            self.voices.append(v)
            self.spawned += 1
            self.changed.emit()
            return True
        n = self._next()
        s = self._prep(S)
        if kind in ("image", "video"):
            s["_style"], s["_tricky"] = choose_style(S), choose_tricky(S)
            s["_copy"] = pick_copy(self.get_templates())
        if kind == "image":
            popup = ImagePopup(s, item, n, self.censor_image_fn if S["img_censor"] else None)
        elif kind == "video":
            try:
                popup = VideoPopup(s, item, n)
            except RuntimeError:                              # harte Video-Obergrenze im Popup selbst
                return False
        else:
            popup = TextPopup(s, item, n)
        return self._open(popup)

    def _next(self):
        self.counter += 1
        return self.counter

    def _open(self, popup):
        if len(self.popups) >= HARD_POPUP_LIMIT:              # letzte Sicherung, egal von wo aufgerufen
            try:
                popup.cleanup()
            except Exception:
                pass
            popup.deleteLater()
            return False
        popup.closed.connect(self._popup_closed)
        popup.missclick.connect(self._missclick)
        self.popups.append(popup)
        popup.start()
        if not getattr(self, "_logged_appid", False) and popup.S["separate_taskbar"]:
            self._logged_appid = True
            self.log.emit("Eigene Taskleisten-Gruppe pro Popup: " +
                          ("gesetzt" if popup.appid_ok else f"FEHLGESCHLAGEN ({winutil.last_error})"))
        self.spawned += 1
        self.changed.emit()
        return True

    def close_videos(self, block_s=20.0):
        """Speicherbremse: alle Videos sofort schließen und neue für eine Weile sperren."""
        self.video_block_until = time.time() + block_s
        for p in list(self.popups):
            if isinstance(p, VideoPopup):
                try:
                    p.close_clean()
                except Exception:
                    pass

    def _voice_done(self, v):
        if v in self.voices:
            self.voices.remove(v)
            v.stop()
            v.deleteLater()
            self.changed.emit()

    def _popup_closed(self, popup):
        if popup in self.popups:
            self.popups.remove(popup)
        self.changed.emit()

    # --- Fehlklick: nur wenn NICHT aufs X geklickt wurde
    def _missclick(self, popup):
        S = self.get_settings()
        if not (self.running and S["penalty_on"]):
            return
        if random.randint(1, 100) > S["penalty_chance"]:
            return
        lo, hi = sorted((S["penalty_min"], S["penalty_max"]))
        count = random.randint(lo, hi)
        self.penalties += 1
        self.log.emit(f"Fehlklick auf Popup #{popup.number} -> {count} neue Popups")
        for i in range(count):
            QTimer.singleShot(i * max(0, S["penalty_delay"]), self._penalty_spawn)

    def _penalty_spawn(self):
        if self.running:
            self.spawn_one(self.get_settings(), penalty=True)

    # --- Zeitsteuerung
    def start(self):
        S = self.get_settings()
        if not self._choices(S):
            return False
        self.running = True
        self.escal = 1.0
        self.penalties = 0
        if S["auto_stop_min"] > 0:
            self.auto_stop.start(S["auto_stop_min"] * 60 * 1000)
        self._tick()
        self.changed.emit()
        return True

    def _tick(self):
        if not self.running:
            return
        S = self.get_settings()
        for _ in range(S["burst"]):
            if not self.spawn_one(S):
                break
        base = S["interval"] * 1000
        mode = S["spawn_mode"]
        if mode == "Chaotisch":
            delay = random.randint(int(base * 0.15), int(base * 1.6))
            if random.random() < 0.15:
                for _ in range(random.randint(2, 3)):
                    if not self.spawn_one(S):
                        break
        elif mode == "Eskalierend":
            self.escal = max(0.2, self.escal * (1 - S["escalation"] / 100.0))
            delay = int(base * self.escal * random.uniform(0.8, 1.2))
        else:
            delay = int(base * random.uniform(0.7, 1.3))
        self.timer.start(max(150, delay))

    def stop_all(self):
        self.running = False
        self.timer.stop()
        self.auto_stop.stop()
        for p in list(self.popups):
            try:
                p.close_clean()
            except Exception:
                pass
            try:
                if isValid(p):                                # falls etwas schiefging: hart verstecken und löschen
                    p.hide()
                    p.deleteLater()
            except Exception:
                pass
        for v in list(self.voices):
            v.stop()
        self.voices.clear()
        self.popups.clear()
        self.changed.emit()


# ---------------------------------------------------------------------------
# Optionale Bildzensur für eigene Bilder (nutzt denselben Detektor)
# ---------------------------------------------------------------------------
class ImageCensor:
    def __init__(self, log_fn=None, adjust=None):
        self.log_fn = log_fn or (lambda t: None)
        self.adjust = adjust or (lambda cfg: cfg)
        self.det = None
        self.failed = False
        self.logged = False
        self.cache = {}
        self.results = {}                         # (Datei, Zeit, Einstellungen) -> zensiertes Bild

    def __call__(self, path, qimg):
        if self.failed:
            return qimg
        try:
            import numpy as np
            import cv2
            import censor_engine as ce
            cfg = self.adjust(ce.load_config(CENSOR_FILE))
            import hashlib
            try:
                mt = os.path.getmtime(path)
            except OSError:
                mt = 0
            key = (path, mt, hashlib.md5(json.dumps(cfg, sort_keys=True, default=str).encode()).hexdigest())
            if key in self.results:                # gleiches Bild + gleiche Einstellungen: nicht nochmal erkennen
                return self.results[key]
            if self.det is None:
                model, note = ce.resolve_model(cfg)
                self.det = ce.Detector(model, cfg["use_gpu"], "Genau", fixed_shapes=True)   # feste Formen -> keine Session pro Bildgröße
                self.log_fn(f"Bild-Zensur bereit ({self.det.provider}, {os.path.basename(model)}) {note} {self.det.note}".strip())
            if max(qimg.width(), qimg.height()) > 1600:           # Popups zeigen das Bild ohnehin klein
                qimg = qimg.scaled(1600, 1600, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            img = qimg.convertToFormat(QImage.Format_RGB888)
            arr = np.frombuffer(img.constBits(), np.uint8).reshape(img.height(), img.bytesPerLine())[:, :img.width() * 3]
            frame = cv2.cvtColor(arr.reshape(img.height(), img.width(), 3), cv2.COLOR_RGB2BGR)
            h, w = frame.shape[:2]
            dets = ce.dets_from_raw(self.det.detect(frame, ce.class_thresholds(cfg)), cfg, w, h)
            if len(self.results) > 8:
                self.results.pop(next(iter(self.results)))
            if not dets:
                self.results[key] = qimg
                return qimg
            out = qimg.convertToFormat(QImage.Format_ARGB32)
            p = QPainter(out)
            for i, (name, group, score, box) in enumerate(dets):
                ce.draw_effect(p, cfg, ce.pick_effect(cfg, group), frame, box, i, self.cache)
            p.end()
            self.results[key] = out
            if not self.logged:
                self.logged = True
                self.log_fn(f"Bild-Zensur: {len(dets)} Treffer in {Path(path).name}")
            return out
        except Exception as e:
            self.failed = True
            self.log_fn(f"Bild-Zensur FEHLER ({type(e).__name__}: {e}) – Bilder werden unzensiert gezeigt!")
            return qimg


# ---------------------------------------------------------------------------
# Oberfläche
# ---------------------------------------------------------------------------
QSS = """
* { font-family: 'Segoe UI', 'Inter', sans-serif; font-size: 10pt; color: #e8e8f0; }
QMainWindow, QWidget#root { background: #0c0c11; }
QScrollArea, QStackedWidget { background: transparent; border: none; }
QWidget#page { background: transparent; }
QWidget#leftcol { background: #101017; border-right: 1px solid #22222d; }
QListWidget#nav { background: transparent; border: none; padding: 4px 0; outline: 0; }
QListWidget#nav::item { padding: 11px 14px; border-radius: 9px; margin: 2px 0; color: #9a9ab0; }
QListWidget#nav::item:hover { background: #1a1a24; color: #fff; }
QListWidget#nav::item:selected { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #3b0f1d, stop:1 #1a1a24);
    color: #fff; border-left: 3px solid #ff2e63; }
QGroupBox { background: #14141c; border: 1px solid #25252f; border-radius: 12px; margin-top: 16px; padding: 16px 14px 12px 14px; }
QGroupBox::title { subcontrol-origin: margin; left: 14px; padding: 0 8px; color: #ff6b8e; font-weight: 700; letter-spacing: 1px; }
QLabel#h1 { font-size: 22pt; font-weight: 800; color: #fff; }
QLabel#sub { color: #8b8ba3; }
QLabel#status { font-size: 15pt; font-weight: 800; }
QLabel#stat { font-size: 20pt; font-weight: 800; color: #fff; }
QLabel#statcap { color: #8b8ba3; font-size: 8.5pt; }
QLabel#warn { color: #ffcf6b; }
QPushButton { background: #1f1f2b; border: 1px solid #30303f; border-radius: 8px; padding: 8px 16px; }
QPushButton:hover { background: #292938; border-color: #ff2e63; }
QPushButton:pressed { background: #14141c; }
QPushButton:disabled { color: #55556a; background: #15151d; border-color: #20202a; }
QPushButton#primary { background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #ff2e63, stop:1 #b3123f);
    border: none; color: #fff; font-weight: 800; font-size: 12pt; padding: 14px 26px; }
QPushButton#primary:hover { background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #ff5580, stop:1 #d2184d); }
QPushButton#primary:disabled { background: #2a1a20; color: #6d5058; }
QPushButton#danger { background: #2a0d14; border: 1px solid #e11d48; color: #ff8aa5; font-weight: 800; font-size: 12pt; padding: 14px 26px; }
QPushButton#danger:hover { background: #e11d48; color: #fff; }
QPushButton#danger:disabled { background: #17100f; border-color: #3a2226; color: #5a4448; }
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QComboBox, QFontComboBox {
    background: #0d0d13; border: 1px solid #2c2c3a; border-radius: 7px; padding: 6px 8px; selection-background-color: #ff2e63; }
QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QComboBox:focus { border-color: #ff2e63; }
QComboBox::drop-down { border: none; width: 22px; }
QComboBox QAbstractItemView { background: #14141c; border: 1px solid #30303f; selection-background-color: #3b0f1d; outline: 0; }
QCheckBox { spacing: 9px; }
QCheckBox::indicator { width: 18px; height: 18px; border-radius: 5px; border: 1px solid #3a3a4c; background: #0d0d13; }
QCheckBox::indicator:hover { border-color: #ff2e63; }
QCheckBox::indicator:checked { background: #ff2e63; border-color: #ff2e63; image: none; }
QSlider::groove:horizontal { height: 6px; background: #23232f; border-radius: 3px; }
QSlider::sub-page:horizontal { background: #ff2e63; border-radius: 3px; }
QSlider::handle:horizontal { background: #fff; width: 16px; height: 16px; margin: -5px 0; border-radius: 8px; }
QListWidget { background: #0d0d13; border: 1px solid #25252f; border-radius: 10px; padding: 6px; outline: 0; }
QListWidget::item { border-radius: 7px; padding: 5px; }
QListWidget::item:selected { background: #3b0f1d; }
QListWidget::item:hover { background: #1a1a24; }
QScrollBar:vertical { background: transparent; width: 11px; }
QScrollBar::handle:vertical { background: #30303f; border-radius: 5px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: #ff2e63; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QToolTip { background: #14141c; color: #fff; border: 1px solid #ff2e63; padding: 5px; }
"""


def make_app_icon():
    pm = QPixmap(64, 64)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setBrush(QColor("#e11d48"))
    p.setPen(Qt.NoPen)
    p.drawRoundedRect(4, 4, 56, 56, 14, 14)
    p.setPen(QColor("white"))
    f = QFont("Segoe UI", 28)
    f.setBold(True)
    p.setFont(f)
    p.drawText(pm.rect(), Qt.AlignCenter, "✕")
    p.end()
    return QIcon(pm)


def media_icon(path):
    ext = Path(path).suffix.lower()
    if ext in IMAGE_EXTS:
        r = QImageReader(path)
        r.setAutoTransform(True)
        sz = r.size()
        if sz.isValid() and sz.width() > 0:
            f = 96.0 / max(sz.width(), sz.height())
            r.setScaledSize(QSize(max(1, int(sz.width() * f)), max(1, int(sz.height() * f))))
        img = r.read()
        if not img.isNull():
            return QIcon(QPixmap.fromImage(img))
    pm = QPixmap(96, 96)
    pm.fill(QColor("#1b1b26"))
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(QColor("#ff6b8e") if ext in VIDEO_EXTS else QColor("#6bd0ff"))
    f = QFont("Segoe UI", 20)
    f.setBold(True)
    p.setFont(f)
    p.drawText(pm.rect(), Qt.AlignCenter, ("▶\n" if ext in VIDEO_EXTS else "♫\n") + ext[1:].upper())
    p.end()
    return QIcon(pm)


def widget_get(w):
    if isinstance(w, ColorButton):
        return w.color()
    if isinstance(w, QFontComboBox):
        return w.currentFont().family()
    if isinstance(w, QComboBox):
        return w.currentText()
    if isinstance(w, QCheckBox):
        return w.isChecked()
    if isinstance(w, (QSlider, QSpinBox)):
        return w.value()
    if isinstance(w, QLineEdit):
        return w.text()
    return None


def widget_set(w, v):
    if isinstance(w, ColorButton):
        w.setColor(str(v))
    elif isinstance(w, QFontComboBox):
        w.setCurrentFont(QFont(str(v)))
    elif isinstance(w, QComboBox):
        i = w.findText(str(v))
        if i >= 0:
            w.setCurrentIndex(i)
    elif isinstance(w, QCheckBox):
        w.setChecked(bool(v))
    elif isinstance(w, (QSlider, QSpinBox)):
        w.setValue(int(v))
    elif isinstance(w, QLineEdit):
        w.setText(str(v))


def widget_signal(w):
    if isinstance(w, ColorButton):
        return w.changed
    if isinstance(w, QFontComboBox):
        return w.currentFontChanged
    if isinstance(w, QComboBox):
        return w.currentTextChanged
    if isinstance(w, QCheckBox):
        return w.toggled
    if isinstance(w, (QSlider, QSpinBox)):
        return w.valueChanged
    if isinstance(w, QLineEdit):
        return w.textChanged
    return None


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(make_app_icon())
        self.resize(1180, 820)
        self.w = {}                       # Popup-Einstellungen: key -> Widget
        self.cw = {}                      # Zensur-Einstellungen: key -> Widget
        self.group_w = {}                 # Zensur-Gruppen: name -> (Checkbox, Effekt, Schwelle, Rand)
        self.sticker_paths = []           # eigene PNGs für die Zensur
        self.assets = []                  # [pfad, aktiv]
        self.templates = [dict(t, on=True) for t in DEFAULT_TEMPLATES]
        self.censor_proc = None
        self._loading = True
        self.image_censor = ImageCensor(lambda t: self.log(t), self.image_cfg)
        self.engine = Engine(self.current_settings, lambda: self.assets, lambda: self.templates, self.image_censor)
        self.engine.changed.connect(self.refresh_status)
        self.engine.log.connect(self.log)
        self.panic = PanicBar(self.stop_everything)

        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        row = QHBoxLayout(root)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        self.stack = QStackedWidget()
        self.search_index = []
        self.page_titles = ["◉  Dashboard", "▣  Medien", "✎  Text-Popups", "◐  Bild · Video · Audio",
                            "⚙  Größe & Verhalten", "▨  Live-Zensur", "?  Sicherheit & Hilfe"]
        builders = [self.page_dashboard, self.page_media, self.page_text, self.page_av, self.page_behavior,
                    self.page_censor, self.page_help]
        for idx, (name, build) in enumerate(zip(self.page_titles, builders)):
            self._cur_page, self._cur_card = idx, ""
            page = build()
            self.nav.addItem(name)
            self.stack.addWidget(self.scroll(page))
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.index_extras()
        left = QWidget()
        left.setObjectName("leftcol")
        left.setFixedWidth(230)
        lv = QVBoxLayout(left)
        lv.setContentsMargins(10, 12, 10, 8)
        lv.setSpacing(8)
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("🔍  Einstellung suchen …  (Strg+F)")
        self.search_box.setClearButtonEnabled(True)
        self.search_box.textChanged.connect(self.on_search)
        self.search_box.returnPressed.connect(self.search_pick)
        self.search_results = QListWidget()
        self.search_results.setObjectName("nav")
        self.search_results.setWordWrap(True)
        self.search_results.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.search_results.hide()
        self.search_results.itemClicked.connect(self.search_pick)
        lv.addWidget(self.search_box)
        lv.addWidget(self.nav, 1)
        lv.addWidget(self.search_results, 1)
        row.addWidget(left)
        row.addWidget(self.stack, 1)
        self.nav.setCurrentRow(0)
        from PySide6.QtGui import QShortcut, QKeySequence
        QShortcut(QKeySequence("Ctrl+F"), self, activated=lambda: (self.search_box.setFocus(), self.search_box.selectAll()))

        self.guard_proc = None
        self.guard_state = DATA_DIR / f"guard_{os.getpid()}.json"
        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.timeout.connect(self.save_all)
        self.status_timer = QTimer(self)
        self.status_timer.timeout.connect(self.poll_censor)
        self.status_timer.start(1000)

        self.load_all()
        self._loading = False
        self.refresh_templates_list()
        self.refresh_assets_list()
        self.refresh_stickers()
        self.refresh_profiles()
        self.refresh_status()
        self.setup_tray()
        self.hb_timer = QTimer(self)                  # Herzschlag: bleibt aus, wenn die Oberfläche hängt
        self.hb_timer.timeout.connect(self.write_guard_state)
        self.hb_timer.start(500)
        self.write_guard_state()
        self.w["guard_on"].toggled.connect(self.on_guard_toggle)
        if self.current_settings()["guard_on"]:
            self.start_guard()
        self.report_crashes()

    # ---------------- Bausteine ----------------
    def scroll(self, widget):
        widget.setObjectName("page")
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setWidget(widget)
        sc.setFrameShape(QFrame.NoFrame)
        return sc

    def card(self, title):
        self._cur_card = title
        g = QGroupBox(title.upper().replace("&", "&&"))        # '&' sonst als Tastenkürzel verschluckt
        return g

    # ---------------- Einstellungssuche ----------------
    def _index(self, widget, label, tip=""):
        """Merkt sich eine Einstellung für die Suche (Seite und Karte kommen aus dem Aufbau-Kontext)."""
        if widget is None or any(e["widget"] is widget for e in self.search_index):
            return
        label = " ".join(str(label).replace("&&", "&").split())
        self.search_index.append({"label": label, "card": getattr(self, "_cur_card", ""), "page": self._cur_page,
                                  "widget": widget, "tip": tip or (widget.toolTip() if hasattr(widget, "toolTip") else "")})

    def index_extras(self):
        """Nimmt alles in die Suche auf, was nicht über die Standard-Helfer gebaut wurde."""
        def add(w, label, page, card, tip=""):
            if w is not None and not any(e["widget"] is w for e in self.search_index):
                self.search_index.append({"label": label, "card": card, "page": page, "widget": w, "tip": tip})
        for key, name in (("image", "Bilder"), ("video", "Videos"), ("audio", "Audio"), ("text", "Text-Popups")):
            add(self.w["w_" + key], f"{name} – Häufigkeit", 0, "Module", "gewichtung wahrscheinlichkeit")
        add(self.preset_combo, "Verhaltens-Preset (Leicht nervig, Adware, Kompletter Albtraum)", 0, "Schnell-Presets")
        add(self.profile_combo, "Profile", 0, "Profile & Standard", "profil laden speichern")
        add(self.text_preset, "Text-Stil-Preset", 2, "Stil-Presets")
        for lbl, w in (("Fenstertitel", self.tpl_title), ("Überschrift", self.tpl_head), ("Text", self.tpl_body),
                       ("Button-Beschriftung", self.tpl_button)):
            add(w, f"Vorlage: {lbl}", 2, "Vorlagen")
        for name, (chk, cb, ts, ps) in self.group_w.items():
            add(chk, name, 5, "Was wird zensiert?", "zensur gruppe")
            add(cb, f"{name} – Effekt", 5, "Was wird zensiert?")
            add(ts, f"{name} – Mindest-Sicherheit", 5, "Was wird zensiert?", "schwelle empfindlichkeit")
            add(ps, f"{name} – Rand", 5, "Was wird zensiert?", "sicherheitsrand padding")
        add(self.model_edit, "Eigenes Modell (.onnx)", 5, "Genauigkeit & Tempo")
        add(self.sticker_list, "Eigene Bilder (PNG) für die Zensur", 5, "Effekt-Look", "sticker png")
        add(self.ic_list, "Bild-Zensur für Popups: Gruppen", 3, "Bild-Zensur für Popups")
        for pg in range(self.stack.count()):                       # Schaltflächen und Bereichsüberschriften
            host = self.stack.widget(pg)
            for b in host.findChildren(QPushButton):
                if b.text().strip() and len(b.text()) > 2:
                    add(b, b.text().replace("▶", "").replace("■", "").strip(" …"), pg, "Schaltfläche", b.toolTip())
            for gbox in host.findChildren(QGroupBox):
                add(gbox, gbox.title().replace("&&", "&").title(), pg, "Bereich")

    def on_search(self, text):
        text = text.strip().lower()
        self.search_results.clear()
        if not text:
            self.search_results.hide()
            self.nav.show()
            return
        toks = text.split()
        hits = []
        for e in self.search_index:
            hay = f"{e['label']} {e['card']} {e['page']} {e['tip']}".lower()
            if all(t in hay for t in toks):
                score = sum(t in e["label"].lower() for t in toks)      # Treffer im Namen zuerst
                hits.append((-score, e))
        hits.sort(key=lambda h: h[0])
        for _s, e in hits[:25]:
            it = QListWidgetItem(f"{e['label']}\n    {self.page_titles[e['page']]}  ›  {e['card']}")
            it.setData(Qt.UserRole, self.search_index.index(e))
            self.search_results.addItem(it)
        if not hits:
            it = QListWidgetItem("Keine Einstellung gefunden")
            it.setFlags(Qt.NoItemFlags)
            self.search_results.addItem(it)
        self.nav.hide()
        self.search_results.show()

    def search_pick(self, item=None):
        item = item or self.search_results.item(0)
        if item is None or item.data(Qt.UserRole) is None:
            return
        e = self.search_index[item.data(Qt.UserRole)]
        self.search_box.clear()                                         # zeigt wieder die Navigation
        self.nav.setCurrentRow(e["page"])
        QTimer.singleShot(80, lambda: self._reveal(e))

    def _reveal(self, e):
        w = e["widget"]
        if not isValid(w):
            return
        sa = self.stack.widget(e["page"])
        sa.ensureWidgetVisible(w, 40, 140)
        ef = QGraphicsDropShadowEffect(w)
        ef.setColor(QColor("#ffd400"))
        ef.setBlurRadius(34)
        ef.setOffset(0, 0)
        w.setGraphicsEffect(ef)
        QTimer.singleShot(2200, lambda: w.setGraphicsEffect(None) if isValid(w) else None)

    def vpage(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(28, 24, 28, 24)
        v.setSpacing(14)
        return w, v

    def head(self, v, title, sub):
        a = QLabel(title)
        a.setObjectName("h1")
        b = QLabel(sub)
        b.setObjectName("sub")
        b.setWordWrap(True)
        v.addWidget(a)
        v.addWidget(b)

    def reg(self, key, widget):
        self.w[key] = widget
        if isinstance(widget, QCheckBox):
            self._index(widget, widget.text())
        widget_set(widget, DEFAULTS[key])
        sig = widget_signal(widget)
        if sig is not None:
            sig.connect(self.dirty)
        return widget

    def creg(self, key, widget):
        self.cw[key] = widget
        if isinstance(widget, QCheckBox):
            self._index(widget, widget.text())
        from censor_engine import DEFAULT_CONFIG
        widget_set(widget, DEFAULT_CONFIG[key])
        sig = widget_signal(widget)
        if sig is not None:
            sig.connect(self.dirty_censor)
        return widget

    def f_check(self, form, key, text, tip=None, censor=False):
        c = QCheckBox(text)
        (self.creg if censor else self.reg)(key, c)
        if tip:
            c.setToolTip(tip)
        form.addRow(c)
        return c

    def f_spin(self, form, key, label, lo, hi, suffix="", tip=None, censor=False):
        s = QSpinBox()
        s.setRange(lo, hi)
        if suffix:
            s.setSuffix(suffix)
        (self.creg if censor else self.reg)(key, s)
        if tip:
            s.setToolTip(tip)
        self._index(s, label.rstrip(":"), tip)
        form.addRow(label, s)
        return s

    def f_slider(self, form, key, label, lo, hi, suffix="", censor=False, tip=None):
        s = QSlider(Qt.Horizontal)
        s.setRange(lo, hi)
        lab = QLabel()
        lab.setMinimumWidth(56)
        lab.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        s.valueChanged.connect(lambda v, l=lab: l.setText(f"{v}{suffix}"))
        (self.creg if censor else self.reg)(key, s)
        lab.setText(f"{s.value()}{suffix}")
        box = QHBoxLayout()
        box.addWidget(s, 1)
        box.addWidget(lab)
        if tip:
            s.setToolTip(tip)
        self._index(s, label.rstrip(":"), tip)
        form.addRow(label, box)
        return s

    def f_combo(self, form, key, label, items, censor=False, tip=None):
        c = QComboBox()
        c.addItems(items)
        (self.creg if censor else self.reg)(key, c)
        if tip:
            c.setToolTip(tip)
        self._index(c, label.rstrip(":"), tip)
        form.addRow(label, c)
        return c

    def f_color(self, form, key, label, censor=False):
        b = ColorButton()
        (self.creg if censor else self.reg)(key, b)
        self._index(b, label.rstrip(":"))
        form.addRow(label, b)
        return b

    def f_line(self, form, key, label, censor=False):
        e = QLineEdit()
        (self.creg if censor else self.reg)(key, e)
        self._index(e, label.rstrip(":"))
        form.addRow(label, e)
        return e

    # ---------------- Seite: Dashboard ----------------
    def page_dashboard(self):
        page, v = self.vpage()
        self.head(v, "Desktop Popup Studio", "Baukasten für Adware-Popups auf deinem echten Desktop – für dein Horror-OS-Projekt.")

        c = self.card("Steuerung")
        g = QGridLayout(c)
        self.status_lbl = QLabel("BEREIT")
        self.status_lbl.setObjectName("status")
        g.addWidget(self.status_lbl, 0, 0, 1, 4)
        self.stat_active, self.stat_total, self.stat_pen = QLabel("0"), QLabel("0"), QLabel("0")
        self.stat_mem = QLabel("–")
        for i, (lab, cap) in enumerate([(self.stat_active, "FENSTER / ERLAUBT"), (self.stat_total, "GESPAWNT"),
                                        (self.stat_pen, "FEHLKLICKS"), (self.stat_mem, "SPEICHER")]):
            lab.setObjectName("stat")
            capl = QLabel(cap)
            capl.setObjectName("statcap")
            g.addWidget(lab, 1, i)
            g.addWidget(capl, 2, i)
        self.start_btn = QPushButton("▶  START")
        self.start_btn.setObjectName("primary")
        self.start_btn.clicked.connect(self.start_popups)
        self.stop_btn = QPushButton("■  POPUPS STOPPEN")
        self.stop_btn.setObjectName("danger")
        self.stop_btn.clicked.connect(self.stop_everything)
        self.preview_btn = QPushButton("Text-Popup testen")
        self.preview_btn.clicked.connect(self.preview_text)
        g.addWidget(self.start_btn, 3, 0, 1, 2)
        g.addWidget(self.stop_btn, 3, 2)
        g.addWidget(self.preview_btn, 3, 3)
        v.addWidget(c)

        c = self.card("Schnell-Presets")
        h = QHBoxLayout(c)
        self.preset_combo = QComboBox()
        self.preset_combo.addItems(list(BEHAVIOR_PRESETS))
        b = QPushButton("Anwenden")
        b.clicked.connect(lambda: self.apply_preset(BEHAVIOR_PRESETS[self.preset_combo.currentText()]))
        h.addWidget(QLabel("Verhalten:"))
        h.addWidget(self.preset_combo, 1)
        h.addWidget(b)
        v.addWidget(c)

        c = self.card("Profile & Standard")
        g = QGridLayout(c)
        info = QLabel("Alle Änderungen werden automatisch gespeichert. Hier kannst du den kompletten Stand "
                      "(alle Seiten inkl. Text-Vorlagen, Medienliste, Zensur) als Profil sichern oder alles zurücksetzen.")
        info.setObjectName("sub")
        info.setWordWrap(True)
        g.addWidget(info, 0, 0, 1, 4)
        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(180)
        g.addWidget(self.profile_combo, 1, 0, 1, 2)
        for col, (text, fn) in enumerate([("Laden", self.load_profile), ("Löschen", self.delete_profile)], start=2):
            b = QPushButton(text)
            b.clicked.connect(fn)
            g.addWidget(b, 1, col)
        b = QPushButton("Aktuellen Stand als Profil speichern …")
        b.clicked.connect(self.save_profile)
        g.addWidget(b, 2, 0, 1, 2)
        b = QPushButton("Exportieren …")
        b.clicked.connect(self.export_settings)
        g.addWidget(b, 2, 2)
        b = QPushButton("Importieren …")
        b.clicked.connect(self.import_settings)
        g.addWidget(b, 2, 3)
        b = QPushButton("Alles auf Standard zurücksetzen …")
        b.setObjectName("danger")
        b.clicked.connect(self.reset_defaults)
        g.addWidget(b, 3, 0, 1, 4)
        g.setColumnStretch(0, 1)
        v.addWidget(c)

        c = self.card("Module – einzeln ein-/ausschaltbar, mit Gewichtung")
        g = QGridLayout(c)
        for r, (key, text) in enumerate([("image", "Bilder"), ("video", "Videos"), ("audio", "Audio"), ("text", "Text-Popups")]):
            chk = QCheckBox(text)
            self.reg("mod_" + key, chk)
            sl = QSlider(Qt.Horizontal)
            sl.setRange(0, 10)
            self.reg("w_" + key, sl)
            lab = QLabel()
            lab.setMinimumWidth(30)
            sl.valueChanged.connect(lambda val, l=lab: l.setText(str(val)))
            lab.setText(str(sl.value()))
            g.addWidget(chk, r, 0)
            g.addWidget(QLabel("Häufigkeit"), r, 1)
            g.addWidget(sl, r, 2)
            g.addWidget(lab, r, 3)
        g.setColumnStretch(2, 1)
        v.addWidget(c)

        c = self.card("Schalter")
        f = QFormLayout(c)
        self.f_check(f, "penalty_on", "Fehlklick-Strafe: Klick aufs Popup (nicht aufs X) öffnet mehr Popups")
        self.f_check(f, "separate_taskbar", "Jedes Popup bekommt einen eigenen Taskleisten-Eintrag")
        self.f_check(f, "panic_bar", "Not-Aus-Leiste einblenden, solange Popups laufen")
        self.f_check(f, "always_on_top", "Popups immer im Vordergrund")
        self.f_check(f, "steal_focus", "Popups dürfen den Tastatur-Fokus stehlen (nerviger)")
        self.f_spin(f, "auto_stop_min", "Automatisch stoppen nach:", 0, 240, " min", "0 = nie")
        v.addWidget(c)

        c = self.card("Protokoll")
        l = QVBoxLayout(c)
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumBlockCount(200)
        self.log_box.setFixedHeight(120)
        l.addWidget(self.log_box)
        v.addWidget(c)
        v.addStretch(1)
        return page

    # ---------------- Seite: Medien ----------------
    def page_media(self):
        page, v = self.vpage()
        self.head(v, "Medien", "Bilder, MP4s und MP3s hinzufügen. Per Haken lässt sich jede Datei einzeln aus der Rotation nehmen.")
        self.media_list = QListWidget()
        self.media_list.setViewMode(QListWidget.IconMode)
        self.media_list.setIconSize(QSize(96, 96))
        self.media_list.setGridSize(QSize(124, 140))
        self.media_list.setResizeMode(QListWidget.Adjust)
        self.media_list.setMovement(QListWidget.Static)
        self.media_list.setWordWrap(True)
        self.media_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.media_list.setMinimumHeight(420)
        self.media_list.itemChanged.connect(self.media_item_changed)
        v.addWidget(self.media_list, 1)
        self.media_count = QLabel("")
        self.media_count.setObjectName("sub")
        v.addWidget(self.media_count)
        h = QHBoxLayout()
        for text, fn in [("Dateien hinzufügen …", self.add_files), ("Ordner hinzufügen …", self.add_folder),
                         ("Auswahl entfernen", self.remove_selected), ("Alle abhaken", lambda: self.set_all(False)),
                         ("Alle anhaken", lambda: self.set_all(True)), ("Bibliothek leeren", self.clear_assets)]:
            b = QPushButton(text)
            b.clicked.connect(fn)
            h.addWidget(b)
        v.addLayout(h)
        return page

    # ---------------- Seite: Text ----------------
    def page_text(self):
        page, v = self.vpage()
        self.head(v, "Text-Popups", "Eigene Texte mit Schrift, Farben, Effekten. Platzhalter: {user} {pc} {time} {date} – ideal für Meta-Horror.")

        c = self.card("Vorlagen (zufällig gewählt)")
        h = QHBoxLayout(c)
        left = QVBoxLayout()
        self.tpl_list = QListWidget()
        self.tpl_list.setFixedWidth(240)
        self.tpl_list.setMinimumHeight(220)
        self.tpl_list.currentRowChanged.connect(self.tpl_select)
        self.tpl_list.itemChanged.connect(self.tpl_item_checked)
        left.addWidget(self.tpl_list)
        hb = QHBoxLayout()
        for text, fn in [("Neu", self.tpl_new), ("Duplizieren", self.tpl_dup), ("Löschen", self.tpl_del)]:
            b = QPushButton(text)
            b.clicked.connect(fn)
            hb.addWidget(b)
        left.addLayout(hb)
        h.addLayout(left)
        f = QFormLayout()
        self.tpl_title, self.tpl_head, self.tpl_button = QLineEdit(), QLineEdit(), QLineEdit()
        self.tpl_body = QTextEdit()
        self.tpl_body.setFixedHeight(110)
        for wdg in (self.tpl_title, self.tpl_head, self.tpl_button):
            wdg.textChanged.connect(self.tpl_edit)
        self.tpl_body.textChanged.connect(self.tpl_edit)
        f.addRow("Fenstertitel:", self.tpl_title)
        f.addRow("Überschrift:", self.tpl_head)
        f.addRow("Text:", self.tpl_body)
        f.addRow("Button-Beschriftung:", self.tpl_button)
        h.addLayout(f, 1)
        v.addWidget(c)

        c = self.card("Schrift")
        f = QFormLayout(c)
        self.f_combo_font(f)
        self.f_spin(f, "t_size", "Größe:", 8, 90, " pt")
        row = QHBoxLayout()
        for key, text in [("t_bold", "Fett"), ("t_italic", "Kursiv"), ("t_underline", "Unterstrichen"), ("t_strike", "Durchgestrichen")]:
            ch = QCheckBox(text)
            self.reg(key, ch)
            row.addWidget(ch)
        row.addStretch(1)
        f.addRow("Stil:", row)
        self.f_spin(f, "t_spacing", "Buchstabenabstand:", -2, 30, " px")
        self.f_combo(f, "t_align", "Ausrichtung:", ["Links", "Mitte", "Rechts"])
        v.addWidget(c)

        c = self.card("Farben & Rahmen")
        f = QFormLayout(c)
        self.f_color(f, "t_fg", "Textfarbe:")
        self.f_color(f, "t_bg", "Hintergrund:")
        self.f_check(f, "t_gradient", "Farbverlauf nach unten")
        self.f_color(f, "t_bg2", "Verlauf-Endfarbe:")
        self.f_color(f, "t_accent", "Akzent (Button / Glow):")
        self.f_color(f, "t_border", "Rahmenfarbe:")
        self.f_spin(f, "t_border_w", "Rahmendicke:", 0, 14, " px")
        self.f_spin(f, "t_radius", "Rundung:", 0, 40, " px")
        v.addWidget(c)

        c = self.card("Größe & Button")
        f = QFormLayout(c)
        self.f_spin(f, "t_w", "Breite:", 200, 1400, " px")
        self.f_check(f, "t_auto_h", "Höhe automatisch an den Text anpassen")
        self.f_spin(f, "t_h", "Feste Höhe:", 120, 1000, " px")
        self.f_check(f, "t_button", "Aktions-Button anzeigen")
        self.f_line(f, "t_button_text", "Standard-Beschriftung:")
        v.addWidget(c)

        c = self.card("Effekte – beliebig kombinierbar")
        g = QGridLayout(c)
        fx = [("fx_neon", "Neon-Glow"), ("fx_glitch", "Glitch"), ("fx_blink", "Blinkende Überschrift"),
              ("fx_shake", "Fenster wackelt"), ("fx_type", "Schreibmaschine"), ("fx_rainbow", "Regenbogen-Text"),
              ("fx_pulse", "Pulsierender Rahmen"), ("fx_scan", "Scanlines")]
        for i, (k, t) in enumerate(fx):
            ch = QCheckBox(t)
            self.reg(k, ch)
            g.addWidget(ch, i // 3, i % 3)
        v.addWidget(c)

        c = self.card("Stil-Presets")
        h = QHBoxLayout(c)
        self.text_preset = QComboBox()
        self.text_preset.addItems(list(TEXT_PRESETS))
        b = QPushButton("Preset anwenden")
        b.clicked.connect(lambda: self.apply_preset(TEXT_PRESETS[self.text_preset.currentText()]))
        b2 = QPushButton("Vorschau")
        b2.clicked.connect(self.preview_text)
        h.addWidget(self.text_preset, 1)
        h.addWidget(b)
        h.addWidget(b2)
        v.addWidget(c)
        v.addStretch(1)
        return page

    def f_combo_font(self, form):
        fc = QFontComboBox()
        self.reg("t_font", fc)
        self._index(fc, "Schriftart")
        form.addRow("Schriftart:", fc)

    # ---------------- Seite: Bild/Video/Audio ----------------
    def page_av(self):
        page, v = self.vpage()
        self.head(v, "Bild · Video · Audio", "Feintuning pro Medientyp. Größen und Klickverhalten findest du unter „Größe & Verhalten“.")
        c = self.card("Bilder")
        f = QFormLayout(c)
        self.f_combo(f, "img_effect", "Effekt:", ["Keiner", "Graustufen", "Invertiert", "Sepia", "Rot-Stich", "Verpixelt", "Unscharf"])
        self.f_slider(f, "img_opacity", "Deckkraft:", 20, 100, " %")
        self.f_check(f, "img_flip", "Zufällig spiegeln")
        self.f_check(f, "img_shake", "Fenster wackelt")
        v.addWidget(c)
        c = self.card("Bild-Zensur für Popups – unabhängig von der Live-Zensur")
        f = QFormLayout(c)
        self.f_check(f, "img_censor", "Bilder VOR dem Anzeigen im Popup zensieren (NudeNet)",
                     "Läuft nur beim Erzeugen eines Bild-Popups. Hat nichts mit dem Ein/Aus der Live-Zensur zu tun.")
        self.f_combo(f, "ic_mode", "Einstellungen:", ["Eigene Einstellungen", "Wie Live-Zensur"],
                     tip="„Wie Live-Zensur“ übernimmt Gruppen, Effekte und Schwellen der Seite Live-Zensur.")
        from censor_engine import EFFECTS as _EFF
        self.f_combo(f, "ic_effect", "Effekt (eigene Einstellungen):", _EFF)
        self.f_slider(f, "ic_shift", "Empfindlichkeit verschieben:", -20, 20, " Pkt")
        self.ic_list = QListWidget()
        self.ic_list.setFixedHeight(190)
        from censor_engine import GROUP_DEFS as _GD
        for name, _cl, on, _t, _p in _GD:
            it = QListWidgetItem(name)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if on else Qt.Unchecked)
            self.ic_list.addItem(it)
        self.ic_list.itemChanged.connect(self.dirty)
        f.addRow("Was zensieren (eigene Einstellungen):", self.ic_list)
        hint = QLabel("Aussehen (Farbe, Text, eigenes PNG) und Modell werden von der Seite Live-Zensur übernommen.")
        hint.setObjectName("sub")
        hint.setWordWrap(True)
        f.addRow(hint)
        v.addWidget(c)
        c = self.card("Videos")
        f = QFormLayout(c)
        self.f_slider(f, "vid_volume", "Lautstärke:", 0, 100, " %")
        self.f_check(f, "vid_muted", "Stumm")
        self.f_slider(f, "vid_speed", "Tempo:", 25, 300, " %")
        self.f_check(f, "vid_loop", "Endlos wiederholen")
        self.f_check(f, "vid_random_start", "Zufällige Startposition")
        self.f_combo(f, "mm_backend", "Multimedia-Backend (nach Neustart):", ["Automatisch", "windows (WMF)", "ffmpeg"],
                     tip="Falls Videos viel Speicher fressen oder ruckeln: „windows (WMF)“ ausprobieren. Wirkt erst nach Neustart.")
        v.addWidget(c)
        c = self.card("Audio (MP3 & Co.)")
        f = QFormLayout(c)
        self.f_slider(f, "aud_vol_min", "Lautstärke min:", 0, 100, " %")
        self.f_slider(f, "aud_vol_max", "Lautstärke max:", 0, 100, " %")
        self.f_slider(f, "aud_speed", "Tempo:", 25, 300, " %")
        self.f_check(f, "aud_loop", "Endlos wiederholen")
        self.f_spin(f, "aud_max", "Gleichzeitig max.:", 1, 20, " Sounds")
        self.f_check(f, "aud_window", "Mini-Fenster mit eigenem X zeigen (sonst läuft der Ton unsichtbar)")
        v.addWidget(c)
        v.addStretch(1)
        return page

    # ---------------- Seite: Größe & Verhalten ----------------
    def page_behavior(self):
        page, v = self.vpage()
        self.head(v, "Größe & Verhalten", "Wie groß, wie oft, wie lange – und was beim Klicken passiert.")
        c = self.card("Größe")
        f = QFormLayout(c)
        self.f_combo(f, "size_mode", "Modus:", SIZE_MODES)
        self.f_combo(f, "size_cap", "Obergrenze (Bildschirmfläche):", list(CAP_CHOICES),
                     tip="1/4 = Fenster maximal halb so breit und halb so hoch wie der Bildschirm.")
        self.f_combo(f, "size_min_cap", "Untergrenze (nur Zufalls-Modus):", list(CAP_CHOICES))
        self.f_spin(f, "size_px", "Feste Breite (nur Pixel-Modus):", 100, 2000, " px")
        self.f_check(f, "upscale_small", "Kleine Bilder im Original-Modus hochskalieren")
        self.f_check(f, "all_monitors", "Alle Monitore benutzen")
        self.f_check(f, "offscreen_ok", "Fenster dürfen teilweise über den Rand ragen")
        v.addWidget(c)

        c = self.card("Zeitsteuerung")
        f = QFormLayout(c)
        self.f_combo(f, "spawn_mode", "Rhythmus:", ["Gleichmäßig", "Eskalierend", "Chaotisch"])
        self.f_spin(f, "interval", "Abstand:", 1, 120, " s")
        self.f_spin(f, "burst", "Popups pro Schub:", 1, 10)
        self.f_spin(f, "max_popups", "Gleichzeitig max.:", 1, HARD_POPUP_LIMIT,
                    tip="Harte Obergrenze für Fenster. Die Presets (Dashboard) ändern diesen Wert mit!")
        self.f_spin(f, "vid_max", "Videos gleichzeitig max.:", 1, 10, "", "Viele gleichzeitige Videos belasten Windows stark")
        self.f_spin(f, "escalation", "Eskalation (je Schub schneller):", 1, 30, " %")
        self.f_spin(f, "life_min", "Lebensdauer min:", 1, 600, " s")
        self.f_spin(f, "life_max", "Lebensdauer max:", 0, 600, " s", "0 = bleibt, bis man es schließt")
        v.addWidget(c)

        c = self.card("Klickverhalten")
        f = QFormLayout(c)
        info = QLabel("Klick aufs X  →  Popup schließt sich sauber.\nKlick irgendwo anders im Popup  →  Fehlklick-Strafe (falls aktiv).")
        info.setObjectName("sub")
        f.addRow(info)
        self.f_check(f, "penalty_button", "Auch der Aktions-Button der Text-Popups zählt als Fehlklick")
        self.f_spin(f, "penalty_min", "Neue Popups pro Fehlklick, min:", 1, 10)
        self.f_spin(f, "penalty_max", "Neue Popups pro Fehlklick, max:", 1, 10)
        self.f_slider(f, "penalty_chance", "Wahrscheinlichkeit:", 0, 100, " %")
        self.f_spin(f, "penalty_delay", "Verzögerung zwischen den neuen Popups:", 0, 2000, " ms")
        self.f_check(f, "penalty_ignore_max", "Strafe darf das Maximum überschreiten (Hard-Limit bleibt)")
        v.addWidget(c)

        c = self.card("Popup-Vielfalt (Bild & Video)")
        f = QFormLayout(c)
        note = QLabel("Mischt zu den normalen Fenstern Anzeigen-Stile dazu: Banner am unteren Rand, Skyscraper an der Seite, "
                      "Karten wie Werbung auf Nachrichtenseiten und rahmenlose Anzeigen. Texte kommen aus den Text-Vorlagen. "
                      "Die Presets Adware und Kompletter Albtraum schalten das ein, Leicht nervig aus.")
        note.setObjectName("sub")
        note.setWordWrap(True)
        f.addRow(note)
        self.f_check(f, "var_on", "Verschiedene Popup-Arten verwenden")
        self.f_slider(f, "var_pct", "Anteil mit Anzeigen-Stil:", 5, 100, " %")
        row = QHBoxLayout()
        for key, text in [("var_banner", "Banner"), ("var_sky", "Skyscraper"), ("var_card", "Karte"), ("var_frameless", "Rahmenlos")]:
            ch = QCheckBox(text)
            self.reg(key, ch)
            row.addWidget(ch)
        row.addStretch(1)
        f.addRow("Arten:", row)
        v.addWidget(c)

        c = self.card("Fiese Schließknöpfe (Bild & Video)")
        f = QFormLayout(c)
        note = QLabel("Wie bei aufdringlicher Werbung: winzige, blasse Schließknöpfe mit versetzter unsichtbarer Trefferfläche, "
                      "falsche X, die mehr öffnen, X die manchmal nicht schließen oder erst nach einigen Sekunden gehen. "
                      "Der Not-Aus (rote Leiste, Strg+Alt+F12) bleibt immer erreichbar.")
        note.setObjectName("sub")
        note.setWordWrap(True)
        f.addRow(note)
        self.f_check(f, "tc_on", "Fiese Schließknöpfe verwenden")
        self.f_slider(f, "tc_pct", "Anteil der Popups:", 5, 100, " %")
        grid = QGridLayout()
        for i, (key, text) in enumerate([("tc_tiny", "Winzig + versetzte Trefferfläche"), ("tc_fake", "Falsches X (öffnet mehr)"),
                                         ("tc_flaky", "Schließt nur manchmal"), ("tc_delay", "Erst nach Countdown"),
                                         ("tc_far", "In anderer Ecke, winzig")]):
            ch = QCheckBox(text)
            self.reg(key, ch)
            grid.addWidget(ch, i // 2, i % 2)
        f.addRow("Arten:", grid)
        self.f_slider(f, "tc_flaky_pct", "„Schließt nur manchmal“: Fehlerquote:", 10, 95, " %")
        self.f_spin(f, "tc_glyph", "Sichtbares X (winzige Arten):", 8, 24, " px")
        self.f_spin(f, "tc_hit", "Echte Trefferfläche:", 4, 20, " px", "Kleiner als das sichtbare X = Klick aufs X verfehlt oft")
        self.f_spin(f, "tc_delay_s", "Countdown:", 1, 15, " s")
        v.addWidget(c)

        c = self.card("Fenster-Optik")
        f = QFormLayout(c)
        self.f_spin(f, "x_size", "Größe des X:", 14, 48, " px", "Kleineres X = leichter zu verfehlen")
        self.f_color(f, "x_color", "Farbe des X:")
        self.f_check(f, "fake_titlebar", "Fake-Titelleiste mit Fenstername anzeigen")
        v.addWidget(c)
        v.addStretch(1)
        return page

    # ---------------- Seite: Zensur ----------------
    def page_censor(self):
        from censor_engine import GROUP_DEFS, EFFECTS, STICKER_MODES, ACCURACY, MODEL_CHOICES
        page, v = self.vpage()
        self.head(v, "Live-Zensur", "Erkennt Nacktheit mit einem lokalen KI-Modell (NudeNet) und verdeckt sie live über ALLEN Fenstern – Chrome, Firefox, Videos, auch die Popups. Nichts verlässt deinen PC.")

        c = self.card("Steuerung")
        g = QGridLayout(c)
        self.censor_status = QLabel("Zensur aus")
        self.censor_status.setObjectName("status")
        g.addWidget(self.censor_status, 0, 0, 1, 3)
        self.censor_detail = QLabel("")
        self.censor_detail.setObjectName("sub")
        self.censor_detail.setWordWrap(True)
        g.addWidget(self.censor_detail, 1, 0, 1, 3)
        self.censor_btn = QPushButton("▶  ZENSUR STARTEN")
        self.censor_btn.setObjectName("primary")
        self.censor_btn.clicked.connect(self.toggle_censor)
        bench = QPushButton("Geschwindigkeit testen")
        bench.clicked.connect(lambda: self.run_tool("--benchmark", "Geschwindigkeitstest"))
        diag = QPushButton("Diagnose")
        diag.setToolTip("Prüft Pakete, Modell, GPU und Bildschirmaufnahme und zeigt, woran es hakt.")
        diag.clicked.connect(lambda: self.run_tool("--diagnose", "Diagnose"))
        g.addWidget(self.censor_btn, 2, 0)
        g.addWidget(bench, 2, 1)
        g.addWidget(diag, 2, 2)
        hint = QLabel("Hotkeys: Strg+Alt+F11 = Pause/Weiter · Strg+Alt+F10 = Zensur beenden")
        hint.setObjectName("sub")
        g.addWidget(hint, 3, 0, 1, 3)
        self.dep_label = QLabel("")
        self.dep_label.setObjectName("warn")
        self.dep_label.setWordWrap(True)
        g.addWidget(self.dep_label, 4, 0, 1, 3)
        v.addWidget(c)

        c = self.card("Was wird zensiert? (je Gruppe an/aus, Effekt, Mindest-Sicherheit, Rand)")
        g = QGridLayout(c)
        for col, text in enumerate(["Zensieren", "Effekt", "Mind.-Sicherheit", "Rand"]):
            hl = QLabel(text)
            hl.setObjectName("statcap")
            g.addWidget(hl, 0, col)
        for r, (name, _cl, on, thr, pad) in enumerate(GROUP_DEFS, start=1):
            chk = QCheckBox(name)
            chk.setChecked(on)
            chk.toggled.connect(self.dirty_censor)
            cb = QComboBox()
            cb.addItems(["Standard"] + EFFECTS)
            cb.currentTextChanged.connect(self.dirty_censor)
            ts = QSpinBox()
            ts.setRange(5, 95)
            ts.setSuffix(" %")
            ts.setValue(thr)
            ts.setToolTip("Niedriger = zensiert früher (mehr Fehlalarme). Genitalien stehen bewusst niedrig.")
            ts.valueChanged.connect(self.dirty_censor)
            ps = QSpinBox()
            ps.setRange(0, 150)
            ps.setSuffix(" %")
            ps.setValue(pad)
            ps.setToolTip("Wie weit die Zensur über die erkannte Stelle hinausragt.")
            ps.valueChanged.connect(self.dirty_censor)
            self.group_w[name] = (chk, cb, ts, ps)
            g.addWidget(chk, r, 0)
            g.addWidget(cb, r, 1)
            g.addWidget(ts, r, 2)
            g.addWidget(ps, r, 3)
        g.setColumnStretch(0, 1)
        note = QLabel("Männer: nur Genitalien. Das Modell trennt das Geschlecht nur bei Brust, Gesicht und Genitalien – "
                      "Gesäß, After, Bauch, Achseln und Füße werden bei allen Personen erkannt.")
        note.setObjectName("sub")
        note.setWordWrap(True)
        g.addWidget(note, len(GROUP_DEFS) + 1, 0, 1, 4)
        v.addWidget(c)

        c = self.card("Effekt-Look")
        f = QFormLayout(c)
        self.f_combo(f, "effect", "Standard-Effekt:", EFFECTS, censor=True)
        self.f_spin(f, "pixel_block", "Pixel-Blockgröße:", 4, 80, " px", censor=True)
        self.f_spin(f, "blur_radius", "Weichzeichner-Stärke:", 4, 120, censor=True)
        self.f_color(f, "color", "Farbfläche:", censor=True)
        self.f_line(f, "text", "Text-Zensur:", censor=True)
        self.f_color(f, "text_color", "Textfarbe:", censor=True)
        self.f_line(f, "font", "Schriftart (Text-Zensur):", censor=True)
        self.f_line(f, "emoji", "Emoji:", censor=True)
        self.f_combo(f, "sticker_mode", "„Eigenes Bild“ – Darstellung:", STICKER_MODES, censor=True,
                     tip="Füllen: Box wird ausgefüllt (Bild wird gestreckt). Einpassen: Seitenverhältnis bleibt, Rest in Farbfläche. "
                         "Zuschneiden: Box voll, Überstand wird abgeschnitten.")
        self.f_check(f, "sticker_backdrop", "Farbfläche hinter dem PNG (verdeckt durchsichtige Stellen; Farbe = „Farbfläche“)", censor=True)
        self.sticker_list = QListWidget()
        self.sticker_list.setViewMode(QListWidget.IconMode)
        self.sticker_list.setIconSize(QSize(56, 56))
        self.sticker_list.setGridSize(QSize(72, 72))
        self.sticker_list.setFixedHeight(96)
        self.sticker_list.setMovement(QListWidget.Static)
        self.sticker_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        srow = QVBoxLayout()
        srow.addWidget(self.sticker_list)
        sb = QHBoxLayout()
        b1 = QPushButton("PNG hinzufügen …")
        b1.clicked.connect(self.add_stickers)
        b2 = QPushButton("Entfernen")
        b2.clicked.connect(self.remove_stickers)
        sb.addWidget(b1)
        sb.addWidget(b2)
        sb.addStretch(1)
        srow.addLayout(sb)
        f.addRow("Eigene Bilder (PNG):", srow)
        hint = QLabel("Wähle bei einer Gruppe oder als Standard den Effekt „Eigenes Bild“. Bei mehreren PNGs bekommt jeder Treffer eins davon.")
        hint.setObjectName("sub")
        hint.setWordWrap(True)
        f.addRow(hint)
        self.f_check(f, "border", "Dünner heller Rand um die Zensur", censor=True)
        self.f_check(f, "show_badge", "Kleine Statusanzeige „Zensur aktiv“ oben links", censor=True)
        v.addWidget(c)

        c = self.card("Genauigkeit & Tempo")
        f = QFormLayout(c)
        self.f_combo(f, "accuracy", "Genauigkeit:", ACCURACY, censor=True,
                     tip="Schnell: 1 Durchlauf. Standard: zusätzlich höhere Auflösung. Genau: plus 2 Kacheln. "
                         "Maximal: plus 4 Kacheln – am gründlichsten, am langsamsten.")
        self.f_combo(f, "model", "Modell:", MODEL_CHOICES, censor=True,
                     tip="640m ist deutlich genauer, aber schwerer. Es muss einmalig heruntergeladen werden.")
        mrow = QHBoxLayout()
        self.dl_btn = QPushButton("640m herunterladen (~100 MB)")
        self.dl_btn.clicked.connect(self.download_640m)
        self.dl_label = QLabel("")
        self.dl_label.setObjectName("sub")
        mrow.addWidget(self.dl_btn)
        mrow.addWidget(self.dl_label, 1)
        f.addRow("", mrow)
        self.f_slider(f, "thr_shift", "Empfindlichkeit verschieben:", -20, 20, " Pkt", censor=True,
                      tip="Verschiebt ALLE Mindest-Sicherheiten. Negativ = zensiert mehr (auch Fehlalarme), positiv = weniger.")
        self.f_slider(f, "hold_ms", "Zensur bleibt nach Treffer:", 0, 2000, " ms", censor=True,
                      tip="Verhindert Flackern, wenn die Erkennung einzelne Bilder verpasst. Kürzer = Zensur verschwindet schneller.")
        self.f_slider(f, "smoothing", "Glättung der Bewegung:", 0, 90, " %", censor=True)
        self.f_spin(f, "confirm_hits", "Treffer nötig bis Anzeige:", 1, 4, censor=True,
                    tip="1 = sofort (sicherer), 2 = weniger Fehlalarme, aber später.")
        self.f_spin(f, "max_fps", "Erkennungen pro Sekunde (max.):", 2, 120, censor=True)
        self.f_check(f, "window_bind", "Zensur nur im betroffenen Fenster (verschwindet mit Minimieren, liegt nicht über anderen Fenstern)", censor=True)
        self.f_check(f, "use_gpu", "Grafikkarte nutzen, falls möglich (DirectML)", censor=True)
        self.f_check(f, "skip_static", "Bei unverändertem Bild nicht neu erkennen (spart Leistung)", censor=True)
        self.f_spin(f, "monitor", "Monitor (0 = Hauptmonitor):", 0, 5, censor=True)
        row = QHBoxLayout()
        self.model_edit = QLineEdit()
        self.model_edit.setPlaceholderText("leer = oben gewähltes Modell")
        self.cw["model_path"] = self.model_edit
        self.model_edit.textChanged.connect(self.dirty_censor)
        bb = QPushButton("…")
        bb.setFixedWidth(40)
        bb.clicked.connect(self.pick_model)
        row.addWidget(self.model_edit, 1)
        row.addWidget(bb)
        f.addRow("Eigenes Modell (.onnx):", row)
        v.addWidget(c)

        c = self.card("Pro App")
        f = QFormLayout(c)
        self.f_combo(f, "apps_mode", "Aktiv:", ["Überall", "Nur in diesen Apps", "Überall außer in diesen"], censor=True,
                     tip="Gilt für das Programm im Vordergrund (aktives Fenster).")
        self.f_line(f, "apps_list", "Programme (Komma-getrennt):", censor=True)
        v.addWidget(c)

        c = self.card("Notfall-Modus")
        f = QFormLayout(c)
        self.f_check(f, "panic_full_screen", "Ganzen Bildschirm verpixeln, wenn viele Treffer gleichzeitig", censor=True)
        self.f_spin(f, "panic_min_boxes", "…ab Treffern:", 2, 20, censor=True)
        v.addWidget(c)
        v.addStretch(1)
        self.update_dep_label()
        return page

    # ---------------- Seite: Hilfe ----------------
    def page_help(self):
        page, v = self.vpage()
        self.head(v, "Sicherheit & Hilfe", "So bleibst du jederzeit Herr über deinen Desktop.")
        c = self.card("Wächter & Notbremse")
        f = QFormLayout(c)
        note = QLabel("Ein winziger eigener Prozess hält einen kleinen roten STOP-Knopf in einer Bildschirmecke ganz oben "
                      "(solange Popups laufen). Er funktioniert auch, wenn Popup Studio hängt oder abstürzt, beendet es sofort "
                      "(wie Task-Manager) und löst eine Notbremse aus, wenn das Programm nicht mehr reagiert, viel zu viele "
                      "Fenster offen sind oder zu viel Speicher belegt wird. Hotkey: Strg+Alt+Umschalt+F12.")
        note.setObjectName("sub")
        note.setWordWrap(True)
        f.addRow(note)
        self.f_check(f, "guard_on", "Wächter mit Not-Aus-Knopf aktivieren (dringend empfohlen)")
        self.f_combo(f, "guard_corner", "Ecke des Knopfs:", list(guardian.CORNERS))
        self.f_spin(f, "guard_hang_s", "Beenden, wenn das Programm hängt nach:", 0, 120, " s", "0 = nie")
        self.f_spin(f, "mem_brake_mb", "Video-Speicherbremse ab:", 0, 16000, " MB",
                    "Überschreitet das Programm diesen Speicher, werden alle Videos geschlossen und 20 s gesperrt (0 = aus)")
        self.f_spin(f, "guard_mem_mb", "Notbremse (Wächter beendet alles) über:", 0, 16000, " MB", "0 = aus")
        v.addWidget(c)
        txt = QLabel(
            "<b>Not-Aus (3 Wege)</b><br>"
            "0. Winziger roter STOP-Knopf des Wächters in der Bildschirmecke – beendet Popup Studio hart, auch bei Absturz<br>"
            "1. Rote Leiste „POPUPS STOPPEN“ am unteren Bildschirmrand (liegt immer über den Popups)<br>"
            "2. Globaler Hotkey <b>Strg + Alt + F12</b> (funktioniert auch, wenn ein Popup den Fokus hat)<br>"
            "3. Tray-Symbol neben der Uhr → „Popups stoppen“<br><br>"
            "<b>Klickregeln</b><br>"
            "• Aufs X klicken schließt das Popup ohne Folgen.<br>"
            "• Irgendwo sonst ins Popup klicken (Bild, Video, Text, Button) löst – falls aktiviert – neue Popups aus.<br><br>"
            "<b>Taskleiste</b><br>"
            "Jedes Popup bekommt eine eigene Windows-AppID und damit einen eigenen Taskleisten-Eintrag. "
            "Falls Windows sie trotzdem gruppiert: Einstellungen → Personalisierung → Taskleiste → "
            "„Schaltflächen der Taskleiste kombinieren“ auf „Nie“ stellen.<br><br>"
            "<b>Zensur</b><br>"
            "Läuft als eigener Prozess und bremst die Popups nicht aus. Das Overlay ist für die Bildschirmaufnahme unsichtbar "
            "(Windows 10 ab Version 2004 / Windows 11). Die KI ist nie 100 % zuverlässig – sie kann etwas übersehen oder "
            "Harmloses markieren. Der erste Frame eines neu auftauchenden Bildes kann kurz unzensiert sein.<br><br>"
            "<b>Dateien</b><br>"
            f"Einstellungen: {SETTINGS_FILE}<br>Zensur-Konfiguration: {CENSOR_FILE}")
        txt.setWordWrap(True)
        txt.setTextFormat(Qt.RichText)
        txt.setTextInteractionFlags(Qt.TextSelectableByMouse)
        c = self.card("Info")
        l = QVBoxLayout(c)
        l.addWidget(txt)
        v.addWidget(c)
        v.addStretch(1)
        return page

    # ---------------- Einstellungen laden/speichern ----------------
    def current_settings(self):
        S = dict(DEFAULTS)
        for k, w in self.w.items():
            S[k] = widget_get(w)
        return S

    def ic_groups(self):
        return [self.ic_list.item(i).text() for i in range(self.ic_list.count())
                if self.ic_list.item(i).checkState() == Qt.Checked]

    def image_cfg(self, cfg):
        """Konfiguration für die Bildzensur in Popups (eigene Gruppen/Effekt/Empfindlichkeit oder wie live)."""
        S = self.current_settings()
        if S["ic_mode"] == "Eigene Einstellungen":
            import censor_engine as ce
            on = set(self.ic_groups())
            cfg["groups"] = {n: {"on": n in on, "effect": "Standard", "thr": ce.DEFAULT_CONFIG["groups"][n]["thr"],
                                 "pad": ce.DEFAULT_CONFIG["groups"][n]["pad"]} for n in ce.GROUPS}
            cfg["effect"], cfg["thr_shift"] = S["ic_effect"], S["ic_shift"]
        return cfg

    def censor_config(self):
        cfg = {k: widget_get(w) for k, w in self.cw.items()}
        cfg["groups"] = {n: {"on": c.isChecked(), "effect": cb.currentText(), "thr": ts.value(), "pad": ps.value()}
                         for n, (c, cb, ts, ps) in self.group_w.items()}
        cfg["stickers"] = list(self.sticker_paths)
        return cfg

    def dirty(self, *a):
        if not self._loading:
            self.save_timer.start(700)

    def dirty_censor(self, *a):
        if not self._loading:
            self.save_timer.start(300)

    def save_all(self):
        try:
            data = {"settings": self.current_settings(), "assets": self.assets, "templates": self.templates,
                    "ic_groups": self.ic_groups()}
            SETTINGS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
            CENSOR_FILE.write_text(json.dumps(self.censor_config(), ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception as e:
            self.log(f"Speichern fehlgeschlagen: {e}")

    def apply_state(self, data, ccfg):
        """Setzt ALLES aus data (Popup-Einstellungen, Medien, Text-Vorlagen, Bild-Zensur) und ccfg (Zensur) –
        fehlende Werte werden zu Standardwerten."""
        import censor_engine as ce
        st = data.get("settings", {})
        for k, w in self.w.items():
            widget_set(w, st.get(k, DEFAULTS[k]))
        if "assets" in data:
            self.assets = [[p, bool(a)] for p, a in data["assets"] if os.path.isfile(p)]
        tpls = data.get("templates")
        self.templates = [dict(t) for t in tpls] if tpls else [dict(t, on=True) for t in DEFAULT_TEMPLATES]
        names = set(data["ic_groups"]) if "ic_groups" in data else {n for n, _c, on, _t, _p in ce.GROUP_DEFS if on}
        for i in range(self.ic_list.count()):
            self.ic_list.item(i).setCheckState(Qt.Checked if self.ic_list.item(i).text() in names else Qt.Unchecked)
        cfg = ce.merge_config(ccfg or {})
        for k, w in self.cw.items():
            if k in cfg:
                widget_set(w, cfg[k])
        self.sticker_paths = [q for q in cfg.get("stickers", []) if os.path.isfile(q)]
        for n, (c, cb, ts, ps) in self.group_w.items():
            g = cfg["groups"].get(n, {})
            c.setChecked(bool(g.get("on")))
            cb.setCurrentIndex(max(0, cb.findText(g.get("effect", "Standard"))))
            ts.setValue(int(g.get("thr", ts.value())))
            ps.setValue(int(g.get("pad", ps.value())))

    def load_all(self):
        data, ccfg = {}, {}
        try:
            data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
        try:
            ccfg = json.loads(CENSOR_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
        try:
            self.apply_state(data, ccfg)
        except Exception as e:
            self.templates = [dict(t, on=True) for t in DEFAULT_TEMPLATES]
            print("Einstellungen konnten nicht vollständig geladen werden:", e)

    # ---------------- Profile / Standard ----------------
    def profile_names(self):
        return sorted(p.stem for p in PROFILES_DIR.glob("*.json"))

    def refresh_profiles(self, select=None):
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        self.profile_combo.addItems(self.profile_names())
        if select:
            self.profile_combo.setCurrentIndex(max(0, self.profile_combo.findText(select)))
        self.profile_combo.blockSignals(False)

    def profile_data(self):
        return {"version": 1, "settings": self.current_settings(), "assets": self.assets,
                "templates": self.templates, "ic_groups": self.ic_groups(), "censor": self.censor_config()}

    def apply_profile(self, data):
        """Wendet ein Profil komplett an (alle Seiten) und sichert es als aktuellen Stand."""
        self._loading = True
        try:
            self.apply_state(data, data.get("censor"))
            self.refresh_templates_list()
            self.refresh_assets_list()
            self.refresh_stickers()
        finally:
            self._loading = False
        self.save_all()

    def save_profile(self):
        name, ok = QInputDialog.getText(self, "Profil speichern", "Name des Profils:",
                                        text=self.profile_combo.currentText() or "Mein Profil")
        name = re.sub(r"[^\w\- äöüÄÖÜß]", "", name or "").strip()
        if not ok or not name:
            return
        (PROFILES_DIR / f"{name}.json").write_text(json.dumps(self.profile_data(), ensure_ascii=False, indent=1), encoding="utf-8")
        self.refresh_profiles(name)
        self.log(f"Profil „{name}“ gespeichert (alle Einstellungen, Text-Vorlagen, Medienliste, Zensur).")

    def load_profile(self):
        name = self.profile_combo.currentText()
        if not name:
            return
        try:
            self.apply_profile(json.loads((PROFILES_DIR / f"{name}.json").read_text(encoding="utf-8")))
            self.log(f"Profil „{name}“ geladen.")
        except Exception as e:
            QMessageBox.warning(self, "Profil", f"Konnte nicht laden: {e}")

    def delete_profile(self):
        name = self.profile_combo.currentText()
        if name and QMessageBox.question(self, "Profil löschen", f"Profil „{name}“ wirklich löschen?") == QMessageBox.Yes:
            (PROFILES_DIR / f"{name}.json").unlink(missing_ok=True)
            self.refresh_profiles()
            self.log(f"Profil „{name}“ gelöscht.")

    def export_settings(self):
        f, _ = QFileDialog.getSaveFileName(self, "Einstellungen exportieren", "popup_studio_einstellungen.json", "JSON (*.json)")
        if f:
            Path(f).write_text(json.dumps(self.profile_data(), ensure_ascii=False, indent=1), encoding="utf-8")
            self.log("Einstellungen exportiert: " + f)

    def import_settings(self):
        f, _ = QFileDialog.getOpenFileName(self, "Einstellungen importieren", "", "JSON (*.json)")
        if f:
            try:
                self.apply_profile(json.loads(Path(f).read_text(encoding="utf-8")))
                self.log("Einstellungen importiert: " + f)
            except Exception as e:
                QMessageBox.warning(self, "Import", f"Konnte nicht laden: {e}")

    def reset_defaults(self):
        box = QMessageBox(self)
        box.setWindowTitle("Auf Standard zurücksetzen")
        box.setText("Wirklich ALLES auf Standard zurücksetzen?\n\nPopup-Einstellungen, Text-Vorlagen, Zensur-Einstellungen, "
                    "Zensur-PNGs und die Bild-Zensur der Popups gehen auf die Ausgangswerte. Gespeicherte Profile bleiben erhalten.")
        keep = box.addButton("Zurücksetzen (Medien behalten)", QMessageBox.AcceptRole)
        wipe = box.addButton("Zurücksetzen + Medienbibliothek leeren", QMessageBox.DestructiveRole)
        box.addButton("Abbrechen", QMessageBox.RejectRole)
        box.exec()
        clicked = box.clickedButton()
        if clicked not in (keep, wipe):
            return
        self.engine.stop_all()
        self.panic.dismiss()
        data = {"settings": {}, "templates": None}
        if clicked is wipe:
            data["assets"] = []
        self.apply_profile(data)
        self.log("Alles auf Standard zurückgesetzt.")

    def log(self, text):
        self.log_box.appendPlainText(time.strftime("[%H:%M:%S] ") + text)

    # ---------------- Medienbibliothek ----------------
    def refresh_assets_list(self):
        self.media_list.blockSignals(True)
        self.media_list.clear()
        for path, on in self.assets:
            it = QListWidgetItem(media_icon(path), Path(path).name)
            it.setToolTip(path)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if on else Qt.Unchecked)
            self.media_list.addItem(it)
        self.media_list.blockSignals(False)
        ni = sum(1 for p, _ in self.assets if Path(p).suffix.lower() in IMAGE_EXTS)
        nv = sum(1 for p, _ in self.assets if Path(p).suffix.lower() in VIDEO_EXTS)
        na = sum(1 for p, _ in self.assets if Path(p).suffix.lower() in AUDIO_EXTS)
        self.media_count.setText(f"{ni} Bilder · {nv} Videos · {na} Audio-Dateien")

    def media_item_changed(self, item):
        row = self.media_list.row(item)
        if 0 <= row < len(self.assets):
            self.assets[row][1] = item.checkState() == Qt.Checked
            self.dirty()

    def _add_paths(self, paths):
        known = {p for p, _ in self.assets}
        for p in paths:
            if p not in known and Path(p).suffix.lower() in MEDIA_EXTS:
                self.assets.append([p, True])
                known.add(p)
        self.refresh_assets_list()
        self.dirty()

    def add_files(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Medien wählen", "", MEDIA_FILTER)
        self._add_paths(files)

    def add_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Ordner wählen")
        if d:
            found = []
            for root, _, files in os.walk(d):
                for f in files:
                    if Path(f).suffix.lower() in MEDIA_EXTS:
                        found.append(os.path.join(root, f))
                if len(found) > 3000:
                    break
            self._add_paths(found)

    def remove_selected(self):
        rows = sorted((self.media_list.row(i) for i in self.media_list.selectedItems()), reverse=True)
        for r in rows:
            del self.assets[r]
        self.refresh_assets_list()
        self.dirty()

    def clear_assets(self):
        self.assets.clear()
        self.refresh_assets_list()
        self.dirty()

    def set_all(self, state):
        for a in self.assets:
            a[1] = state
        self.refresh_assets_list()
        self.dirty()

    # ---------------- Text-Vorlagen ----------------
    def refresh_templates_list(self, select=0):
        self.tpl_list.blockSignals(True)
        self.tpl_list.clear()
        for t in self.templates:
            it = QListWidgetItem(t.get("headline") or t.get("title") or "(leer)")
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if t.get("on", True) else Qt.Unchecked)
            self.tpl_list.addItem(it)
        self.tpl_list.blockSignals(False)
        if self.templates:
            self.tpl_list.setCurrentRow(min(select, len(self.templates) - 1))
        self.tpl_select(self.tpl_list.currentRow())

    def tpl_select(self, row):
        widgets = (self.tpl_title, self.tpl_head, self.tpl_button, self.tpl_body)
        for w in widgets:
            w.blockSignals(True)
        if 0 <= row < len(self.templates):
            t = self.templates[row]
            self.tpl_title.setText(t.get("title", ""))
            self.tpl_head.setText(t.get("headline", ""))
            self.tpl_button.setText(t.get("button", ""))
            self.tpl_body.setPlainText(t.get("body", ""))
        else:
            for w in widgets:
                w.clear()
        for w in widgets:
            w.blockSignals(False)

    def tpl_edit(self, *a):
        row = self.tpl_list.currentRow()
        if 0 <= row < len(self.templates):
            t = self.templates[row]
            t["title"], t["headline"] = self.tpl_title.text(), self.tpl_head.text()
            t["button"], t["body"] = self.tpl_button.text(), self.tpl_body.toPlainText()
            self.tpl_list.item(row).setText(t["headline"] or t["title"] or "(leer)")
            self.dirty()

    def tpl_item_checked(self, item):
        row = self.tpl_list.row(item)
        if 0 <= row < len(self.templates):
            self.templates[row]["on"] = item.checkState() == Qt.Checked
            self.dirty()

    def tpl_new(self):
        self.templates.append({"title": "Neue Vorlage", "headline": "NEUE ÜBERSCHRIFT", "body": "Dein Text …",
                               "button": "OK", "on": True})
        self.refresh_templates_list(len(self.templates) - 1)
        self.dirty()

    def tpl_dup(self):
        row = self.tpl_list.currentRow()
        if 0 <= row < len(self.templates):
            self.templates.insert(row + 1, dict(self.templates[row]))
            self.refresh_templates_list(row + 1)
            self.dirty()

    def tpl_del(self):
        row = self.tpl_list.currentRow()
        if 0 <= row < len(self.templates):
            del self.templates[row]
            self.refresh_templates_list(max(0, row - 1))
            self.dirty()

    def apply_preset(self, preset):
        for k, v in preset.items():
            if k in self.w:
                widget_set(self.w[k], v)
        self.log(f"Preset angewendet (max. gleichzeitig jetzt: {self.w['max_popups'].value()}).")

    # ---------------- Start / Stop ----------------
    def start_popups(self):
        self.save_all()
        if not self.engine.start():
            QMessageBox.information(self, "Nichts zu spielen",
                                    "Aktiviere mindestens ein Modul, für das es Inhalt gibt: Medien hinzufügen "
                                    "oder eine Text-Vorlage anhaken.")
            return
        self.log("Popups gestartet.  Not-Aus: Strg+Alt+F12 oder rote Leiste.")

    def stop_everything(self):
        self.engine.stop_all()
        self.panic.dismiss()
        self.log("Alle Popups gestoppt.")

    def preview_text(self):
        S = self.current_settings()
        S["life_min"] = S["life_max"] = 20
        row = self.tpl_list.currentRow()
        tpl = self.templates[row] if 0 <= row < len(self.templates) else DEFAULT_TEMPLATES[0]
        S = self.engine._prep(S)
        self.engine._open(TextPopup(S, tpl, self.engine._next()))

    def refresh_status(self):
        e = self.engine
        self.stat_active.setText(f"{len(e.popups)} / {e.limit(self.current_settings())}")
        self.stat_total.setText(str(e.spawned))
        self.stat_pen.setText(str(e.penalties))
        if e.running:
            self.status_lbl.setText("● LÄUFT")
            self.status_lbl.setStyleSheet("color:#ff2e63;")
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            if self.current_settings()["panic_bar"] and not self.panic.isVisible():
                self.panic.present()
        else:
            self.status_lbl.setText("BEREIT")
            self.status_lbl.setStyleSheet("color:#6bd0a0;")
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(len(e.popups) > 0)
            if self.panic.isVisible():
                self.panic.dismiss()

    # ---------------- Zensur-Prozess ----------------
    def update_dep_label(self):
        import importlib.util as iu
        missing = [m for m in ("onnxruntime", "cv2", "numpy") if iu.find_spec(m) is None]
        if iu.find_spec("nudenet") is None and not getattr(sys, "frozen", False):
            missing.append("nudenet (Modell)")
        info = []
        if missing:
            info.append("Fehlt: " + ", ".join(missing) + " → START_POPUP_STUDIO.bat erneut ausführen.")
        info.append("Aufnahme: " + ("dxcam (schnell)" if iu.find_spec("dxcam") else "mss (langsamer – dxcam fehlt)"))
        self.dep_label.setText("   ".join(info))

    def download_640m(self):
        import threading
        import censor_engine as ce
        if ce.model_640m_path():
            self.dl_label.setText("640m ist bereits vorhanden.")
            return
        self.dl_btn.setEnabled(False)
        self.dl_label.setText("Lade herunter …")
        result = {}

        def work():
            try:
                result["path"] = ce.download_model(progress=lambda got, tot: result.__setitem__("p", (got, tot)))
            except Exception as e:
                result["err"] = f"{type(e).__name__}: {e}"

        t = threading.Thread(target=work, daemon=True)
        t.start()
        timer = QTimer(self)

        def poll():
            if t.is_alive():
                got, tot = result.get("p", (0, 0))
                self.dl_label.setText(f"Lade herunter … {got // 1048576} / {tot // 1048576 if tot else '?'} MB")
                return
            timer.stop()
            self.dl_btn.setEnabled(True)
            if "path" in result:
                self.dl_label.setText("Fertig. Modell „640m (genauer)“ wählen und Zensur neu starten.")
                self.log("640m-Modell heruntergeladen.")
            else:
                self.dl_label.setText("Download fehlgeschlagen – Details im Protokoll (Dashboard). Alternativ manuell laden, siehe README.")
                self.log("640m-Download fehlgeschlagen: " + result.get("err", "?"))
                self.log("-> Manuell: 640m.onnx (104 MB) laden, in %APPDATA%\\PopupStudio\\models ablegen oder unter "
                         "„Eigenes Modell“ auswählen. Quellen siehe README.")
        timer.timeout.connect(poll)
        timer.start(400)

    def pick_model(self):
        f, _ = QFileDialog.getOpenFileName(self, "ONNX-Modell wählen", "", "ONNX (*.onnx)")
        if f:
            self.model_edit.setText(f)

    def censor_running(self):
        return self.censor_proc is not None and self.censor_proc.poll() is None

    def toggle_censor(self):
        if self.censor_running():
            self.stop_censor()
        else:
            self.start_censor()

    def start_censor(self):
        self.save_all()
        import censor_engine as _ce
        if str(self.cw["model"].currentText()).startswith("640m") and not self.model_edit.text().strip() and not _ce.model_640m_path():
            QMessageBox.information(self, "Modell 640m fehlt",
                                    "Das genauere Modell 640m ist noch nicht installiert – es läuft vorerst das schnelle 320n.\n"
                                    "Lade es unter „Genauigkeit & Tempo“ herunter.")
        try:
            CENSOR_STATUS.unlink(missing_ok=True)
        except Exception:
            pass
        if getattr(sys, "frozen", False):
            cmd = [sys.executable, "--censor", str(CENSOR_FILE)]
        else:
            cmd = [sys.executable, str(Path(__file__).resolve()), "--censor", str(CENSOR_FILE)]
        try:
            logf = open(DATA_DIR / "censor.log", "w", encoding="utf-8")
            self.censor_proc = subprocess.Popen(cmd, stdout=logf, stderr=logf,
                                                creationflags=0x08000000 if winutil.IS_WIN else 0)
            self.censor_btn.setText("■  ZENSUR BEENDEN")
            self.censor_status.setText("Zensur startet …")
            self.log("Zensur-Prozess gestartet.")
        except Exception as e:
            QMessageBox.warning(self, "Zensur", f"Konnte nicht starten: {e}")

    def stop_censor(self):
        if self.censor_proc is not None:
            try:
                self.censor_proc.terminate()
                self.censor_proc.wait(timeout=3)
            except Exception:
                try:
                    self.censor_proc.kill()
                except Exception:
                    pass
        self.censor_proc = None
        self.censor_btn.setText("▶  ZENSUR STARTEN")
        self.censor_status.setText("Zensur aus")
        self.censor_status.setStyleSheet("")
        self.censor_detail.setText("")
        self.log("Zensur beendet.")

    def poll_censor(self):
        if self.censor_proc is None:
            return
        if not self.censor_running():
            code = self.censor_proc.returncode
            tail = ""
            try:
                tail = (DATA_DIR / "censor.log").read_text(encoding="utf-8")[-600:].strip()
            except Exception:
                pass
            self.censor_proc = None
            self.censor_btn.setText("▶  ZENSUR STARTEN")
            self.censor_status.setText("Zensur aus" if code == 0 else "Zensur abgestürzt")
            self.censor_status.setStyleSheet("" if code == 0 else "color:#ff6b6b;")
            self.censor_detail.setText(tail if code else "")
            return
        try:
            st = json.loads(CENSOR_STATUS.read_text(encoding="utf-8"))
            if st.get("error"):
                self.censor_status.setText("Zensur: Fehler")
                self.censor_status.setStyleSheet("color:#ff6b6b;")
                self.censor_detail.setText(st["error"])
                return
            self.censor_status.setText("● ZENSUR AKTIV" if not st.get("paused") else "❚❚ ZENSUR PAUSIERT")
            self.censor_status.setStyleSheet("color:#6bd0a0;")
            self.censor_detail.setText(
                f"Modell {st.get('model', '?')} · {st.get('fps', 0)} Zyklen/s · Erkennung {st.get('detect_ms', 0)} ms · {st.get('provider')} · "
                f"Aufnahme: {st.get('capture')} · Treffer: {st.get('boxes', 0)}"
                + ("" if st.get("excluded", True) else "  ⚠ Overlay nicht aus Aufnahme ausgeschlossen (Windows zu alt?)")
                + (f"\n⚠ {st['note']}" if st.get("note") else ""))
        except Exception:
            pass

    def refresh_stickers(self):
        self.sticker_list.clear()
        for q in self.sticker_paths:
            it = QListWidgetItem(media_icon(q), Path(q).stem[:10])
            it.setToolTip(q)
            self.sticker_list.addItem(it)

    def add_stickers(self):
        files, _ = QFileDialog.getOpenFileNames(self, "PNG für die Zensur wählen", "",
                                                "Bilder (*.png *.webp *.jpg *.jpeg *.gif *.bmp)")
        for f in files:
            if f not in self.sticker_paths:
                self.sticker_paths.append(f)
        self.refresh_stickers()
        self.dirty_censor()

    def remove_stickers(self):
        for r in sorted((self.sticker_list.row(i) for i in self.sticker_list.selectedItems()), reverse=True):
            del self.sticker_paths[r]
        self.refresh_stickers()
        self.dirty_censor()

    def run_tool(self, flag, title):
        """Startet Benchmark/Diagnose als Hilfsprozess; Ausgabe kommt über eine Datei (pythonw hat keine Konsole)."""
        self.save_all()
        out = DATA_DIR / f"tool{flag.strip('-')}.txt"
        try:
            out.unlink(missing_ok=True)
        except Exception:
            pass
        proc = QProcess(self)
        args = [flag, str(out)] if getattr(sys, "frozen", False) else [str(Path(__file__).resolve()), flag, str(out)]

        def done(*_):
            try:
                text = out.read_text(encoding="utf-8")
            except Exception:
                text = "Keine Ausgabe – das Programm ist abgestürzt, bevor es etwas schreiben konnte."
            from PySide6.QtWidgets import QDialog, QDialogButtonBox
            dlg = QDialog(self)
            dlg.setWindowTitle(title)
            dlg.resize(760, 520)
            lay = QVBoxLayout(dlg)
            box = QPlainTextEdit(text)
            box.setReadOnly(True)
            box.setStyleSheet("font-family:Consolas,monospace;")
            lay.addWidget(box)
            bb = QDialogButtonBox(QDialogButtonBox.Close)
            bb.rejected.connect(dlg.reject)
            lay.addWidget(bb)
            dlg.show()
            self._dlg = dlg
            self.log(f"{title} fertig.")

        proc.finished.connect(done)
        proc.start(sys.executable, args)
        self._tool_proc = proc
        self.log(f"{title} läuft (kann bis zu 30 s dauern) – das Ergebnis erscheint als Fenster.")

    # ---------------- Tray ----------------
    def setup_tray(self):
        self.tray = QSystemTrayIcon(make_app_icon(), self)
        menu = QMenu()
        a1 = QAction("Fenster öffnen", self)
        a1.triggered.connect(lambda: (self.showNormal(), self.raise_(), self.activateWindow()))
        a2 = QAction("Popups stoppen", self)
        a2.triggered.connect(self.stop_everything)
        a3 = QAction("Zensur beenden", self)
        a3.triggered.connect(self.stop_censor)
        a4 = QAction("Programm beenden", self)
        a4.triggered.connect(self.close)
        for a in (a1, a2, a3, a4):
            menu.addAction(a)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda r: self.showNormal() if r == QSystemTrayIcon.Trigger else None)
        self.tray.setToolTip(APP_NAME)
        self.tray.show()

    # ---------------- Wächter (eigener Prozess mit Not-Aus-Knopf) ----------------
    def memory_governor(self, S):
        """Speicherbremse im Programm selbst – greift VOR der Notbremse des Wächters."""
        mb = winutil.memory_mb(os.getpid())
        self.stat_mem.setText(f"{int(mb)} MB" if mb else "–")
        lim = S["mem_brake_mb"]
        if lim > 0 and mb > lim and (self.engine.video_block_until < time.time() or
                                     any(isinstance(p, VideoPopup) for p in self.engine.popups)):
            self.engine.close_videos()
            self.log(f"Speicherbremse: {int(mb)} MB > {lim} MB – Videos geschlossen und 20 s gesperrt.")

    def write_guard_state(self):
        S = self.current_settings()
        self.memory_governor(S)
        e = self.engine
        state = {"ts": time.time(), "active": bool(e.running or e.popups or e.voices), "limit": e.limit(S, penalty=True),
                 "hang_s": S["guard_hang_s"], "mem_mb": S["guard_mem_mb"], "win_extra": 12,
                 "corner": guardian.CORNERS.get(S["guard_corner"], "tl")}
        try:
            tmp = self.guard_state.with_suffix(".tmp")
            tmp.write_text(json.dumps(state), encoding="utf-8")
            os.replace(tmp, self.guard_state)
        except Exception:
            pass
        fh = globals().get("CRASH_FH")
        if fh is not None:                            # hängt die Oberfläche, steht danach im Absturzbericht, WO
            try:
                import faulthandler
                faulthandler.cancel_dump_traceback_later()
                faulthandler.dump_traceback_later(max(3, (S["guard_hang_s"] or 15) - 3), file=fh)
            except Exception:
                pass

    def start_guard(self):
        if self.guard_proc is not None and self.guard_proc.poll() is None:
            return
        if getattr(sys, "frozen", False):
            cmd = [sys.executable, "--guard", str(os.getpid()), str(self.guard_state)]
        else:
            cmd = [sys.executable, str(Path(__file__).resolve()), "--guard", str(os.getpid()), str(self.guard_state)]
        try:
            logf = open(DATA_DIR / "guard.log", "w", encoding="utf-8")
            self.guard_proc = subprocess.Popen(cmd, stdout=logf, stderr=logf, close_fds=True,
                                               creationflags=0x00000208 if winutil.IS_WIN else 0)   # losgelöst vom Hauptprozess
            self.log("Wächter gestartet: Not-Aus-Knopf erscheint in der Bildschirmecke, solange Popups laufen.")
        except Exception as e:
            self.log(f"Wächter konnte nicht starten: {e}")

    def stop_guard(self):
        if self.guard_proc is not None:
            try:
                self.guard_proc.terminate()
            except Exception:
                pass
            self.guard_proc = None

    def on_guard_toggle(self, on):
        if on:
            self.write_guard_state()
            self.start_guard()
        else:
            self.stop_guard()
            self.log("Wächter aus – ohne ihn gibt es keinen Not-Aus, wenn das Programm hängt!")

    def report_crashes(self):
        for name in ("crash.log", "crash_native.log"):
            f = DATA_DIR / name
            try:
                if f.exists() and f.stat().st_size > 0:
                    self.log(f"Absturzbericht vorhanden: {f}  (bitte schicken, wenn es wieder hakt)")
            except Exception:
                pass

    def closeEvent(self, e):
        self.hb_timer.stop()
        self.stop_guard()
        try:
            self.guard_state.unlink(missing_ok=True)
        except Exception:
            pass
        self.engine.stop_all()
        self.panic.dismiss()
        self.stop_censor()
        self.save_all()
        e.accept()
        QApplication.quit()


CRASH_FH = None


def main():
    global CRASH_FH
    import faulthandler
    import threading
    import traceback
    try:
        CRASH_FH = open(DATA_DIR / "crash_native.log", "a", buffering=1, encoding="utf-8")
        faulthandler.enable(CRASH_FH)                    # harte Abstürze (Segfault) hinterlassen eine Spur

        def hook(t, v, tb):
            try:
                with open(DATA_DIR / "crash.log", "a", encoding="utf-8") as f:
                    f.write(time.strftime("\n[%Y-%m-%d %H:%M:%S]\n") + "".join(traceback.format_exception(t, v, tb)))
            except Exception:
                pass
        sys.excepthook = hook
        threading.excepthook = lambda a: hook(a.exc_type, a.exc_value, a.exc_traceback)
    except Exception:
        pass
    try:                                                  # Multimedia-Backend muss VOR der QApplication feststehen
        _mm = json.loads(SETTINGS_FILE.read_text(encoding="utf-8")).get("settings", {}).get("mm_backend", "Automatisch")
        if _mm.startswith("windows"):
            os.environ["QT_MEDIA_BACKEND"] = "windows"
        elif _mm == "ffmpeg":
            os.environ["QT_MEDIA_BACKEND"] = "ffmpeg"
    except Exception:
        pass
    app = QApplication(sys.argv)
    if not winutil.single_instance("PopupStudio_v4_main"):
        QMessageBox.warning(None, APP_NAME, "Popup Studio läuft bereits (zwei Instanzen würden doppelt so viele Popups erzeugen).\n\n"
                            "Hängt die andere? Dann den roten STOP-Knopf in der Bildschirmecke benutzen oder den Task-Manager.")
        sys.exit(0)
    winutil.set_priority(below=True)                      # hält Windows und den Task-Manager auch unter Last flüssig
    app.setStyle("Fusion")
    app.setStyleSheet(QSS)
    app.setFont(QFont("Segoe UI", 10))
    win = MainWindow()
    hk = winutil.make_hotkey_filter()
    if hk is not None:
        app.installNativeEventFilter(hk)
        ok = hk.register(10, winutil.MOD_CONTROL | winutil.MOD_ALT, winutil.VK_F12, win.stop_everything)
        if not ok:
            win.log("Hotkey Strg+Alt+F12 konnte nicht registriert werden (von anderem Programm belegt?).")
        win._hk = hk
    win.show()
    code = app.exec()
    if hk is not None:
        hk.unregister_all()
    sys.exit(code)


if __name__ == "__main__":
    main()
