"""Wächter: ein winziger, EIGENER Prozess mit Not-Aus-Knopf.

Warum ein eigener Prozess? Hängt oder stürzt Popup Studio ab, bleiben seine Fenster als nicht mehr
bedienbare Geister oben liegen – und mit ihnen jeder Not-Aus-Knopf, der im selben Prozess steckt. Der Wächter
läuft getrennt, bleibt dadurch bedienbar, hält sein Fenster ständig ganz oben und beendet Popup Studio
sofort, wenn du klickst (wie 'Task beenden') oder wenn er eine Notbremse erkennt:
  - Programm reagiert nicht mehr (Herzschlag bleibt aus)
  - viel mehr Fenster als erlaubt
  - zu viel Arbeitsspeicher
Start:  popup_studio.py --guard <pid> <state.json>
"""
import sys
import json
import time
from types import SimpleNamespace

import winutil

CORNERS = {"oben links": "tl", "oben rechts": "tr", "unten links": "bl", "unten rechts": "br"}
GUARD_W, GUARD_H = 56, 18


class GuardLogic:
    """Entscheidungslogik ohne Oberfläche (damit testbar)."""

    def __init__(self, pid, state_path, io=None):
        self.pid, self.state_path = pid, state_path
        self.io = io or SimpleNamespace(alive=winutil.process_alive, kill=winutil.kill_process,
                                        windows=winutil.count_windows, mem=winutil.memory_mb, now=time.time)
        self.t0 = self.io.now()
        self.state = {}
        self.last_heavy = -1e9
        self.win_count, self.mem_now = 0, 0.0

    def read_state(self):
        try:
            with open(self.state_path, "r", encoding="utf-8") as f:
                self.state = json.load(f)
        except Exception:
            pass                                          # halb geschriebene Datei -> alten Stand behalten
        return self.state

    def poll(self):
        now = self.io.now()
        if not self.io.alive(self.pid):
            return {"exit": True}
        st = self.read_state()
        stale = now - float(st.get("ts", self.t0))
        active = bool(st.get("active"))
        reason = None
        hang_s = float(st.get("hang_s", 10))
        if active and hang_s > 0 and stale > hang_s:
            reason = f"Programm reagiert seit {int(stale)} s nicht"
        if active and now - self.last_heavy > 0.5:
            self.last_heavy = now
            self.win_count, self.mem_now = self.io.windows(self.pid), self.io.mem(self.pid)
        limit, extra = int(st.get("limit", 40)), int(st.get("win_extra", 12))
        if reason is None and active and self.win_count > limit + extra:
            reason = f"{self.win_count} Fenster offen (erlaubt: {limit})"
        mem_cap = float(st.get("mem_mb", 3000))
        if reason is None and mem_cap > 0 and self.mem_now > mem_cap:
            reason = f"{int(self.mem_now)} MB Arbeitsspeicher belegt"
        return {"exit": False, "visible": active or stale > 3, "hung": stale > 3, "stale": stale,
                "reason": reason, "corner": st.get("corner", "tl"), "windows": self.win_count}

    def kill(self):
        return self.io.kill(self.pid)


def run_guard(pid, state_path):
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtGui import QGuiApplication
    from PySide6.QtWidgets import QApplication, QPushButton, QWidget, QHBoxLayout

    winutil.set_priority(above=True)                      # bleibt auch bei Last bedienbar
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    logic = GuardLogic(pid, state_path)

    class Guard(QWidget):
        def __init__(self):
            super().__init__(None, Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.WindowDoesNotAcceptFocus)
            self.setAttribute(Qt.WA_ShowWithoutActivating, True)
            lay = QHBoxLayout(self)
            lay.setContentsMargins(0, 0, 0, 0)
            self.btn = QPushButton("■ STOP")
            self.btn.setCursor(Qt.PointingHandCursor)
            self.btn.setToolTip("NOT-AUS: beendet Popup Studio sofort (wie Task-Manager → Task beenden)")
            self.btn.clicked.connect(lambda: self.do_kill("Not-Aus-Knopf"))
            lay.addWidget(self.btn)
            self.dead = False
            self.corner = "tl"
            self.style_normal()
            self.resize(GUARD_W, GUARD_H)

        def style_normal(self, hung=False):
            self.btn.setStyleSheet("QPushButton{background:%s;color:white;border:1px solid white;"
                                   "font:bold 8px 'Segoe UI';padding:0;}QPushButton:hover{background:#ff3347;}"
                                   % ("#ff8c00" if hung else "#c4001a"))
            self.btn.setText("■ HÄNGT" if hung else "■ STOP")

        def place(self, corner):
            g = QGuiApplication.primaryScreen().geometry()
            w, h = self.width(), self.height()
            x = g.left() if corner in ("tl", "bl") else g.right() - w + 1
            y = g.top() if corner in ("tl", "tr") else g.bottom() - h + 1
            self.move(x, y)
            self.corner = corner

        def do_kill(self, reason):
            if self.dead:
                return
            self.dead = True
            ok = logic.kill()
            self.btn.setStyleSheet("QPushButton{background:#222;color:#fff;border:1px solid #888;font:bold 9px 'Segoe UI';}")
            self.btn.setText(f"Popup Studio beendet ({reason})" if ok else "Beenden fehlgeschlagen – Task-Manager nutzen")
            self.resize(330, 20)
            self.place(self.corner)
            QTimer.singleShot(5000, app.quit)

    g = Guard()

    def tick():
        if g.dead:
            return
        res = logic.poll()
        if res.get("exit"):
            app.quit()
            return
        if res["reason"]:
            g.do_kill("Notbremse: " + res["reason"])
            return
        if res["visible"]:
            if g.corner != res["corner"] or not g.isVisible():
                g.place(res["corner"])
            g.style_normal(res["hung"])
            if not g.isVisible():
                g.show()
            winutil.bring_topmost(int(g.winId()))        # ständig wieder ganz nach oben
        elif g.isVisible():
            g.hide()

    hk = winutil.make_hotkey_filter()
    if hk is not None:
        app.installNativeEventFilter(hk)
        hk.register(21, winutil.MOD_CONTROL | winutil.MOD_ALT | winutil.MOD_SHIFT, winutil.VK_F12,
                    lambda: g.do_kill("Hotkey Strg+Alt+Umschalt+F12"))
    t = QTimer()
    t.timeout.connect(tick)
    t.start(100)
    code = app.exec()
    if hk is not None:
        hk.unregister_all()
    return code
